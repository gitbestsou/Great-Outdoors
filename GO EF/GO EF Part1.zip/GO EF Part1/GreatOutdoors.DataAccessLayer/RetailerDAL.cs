﻿using System;
using System.Collections.Generic;
using System.Linq;
using Capgemini.GreatOutdoors.Contracts.DALContracts;
using GreatOutdoors.Entities;
using Capgemini.GreatOutdoors.Exceptions;


namespace Capgemini.GreatOutdoors.DataAccessLayer
{
    /// <summary>
    /// Contains data access layer methods for inserting, updating, deleting retailers from Retailers collection.
    /// </summary>
    public class RetailerDAL : RetailerDALBase, IDisposable
    {

        TeamAEntities entities = new TeamAEntities();
        /// <summary>
        /// Adds new retailer to Retailers collection.
        /// </summary>
        /// <param name="newRetailer">Contains the retailer details to be added.</param>
        /// <returns>Determinates whether the new retailer is added.</returns>
        public override (bool, Guid) AddRetailerDAL(Retailer newRetailer)
        {
            bool retailerAdded = false;
            DateTime creationDateTime = DateTime.Now;
            DateTime modifiedDateTime = DateTime.Now;
            try
            {


                if (newRetailer != null)
                {
                    newRetailer.RetailerID = Guid.NewGuid();
                    newRetailer.CreationDateTime = DateTime.Now;
                    newRetailer.ModifiedDateTime = DateTime.Now;
                    entities.AddRetailer(newRetailer.RetailerID, newRetailer.RetailerName, newRetailer.RetailerMobile, newRetailer.Email, newRetailer.RetailerPassword, newRetailer.CreationDateTime, newRetailer.ModifiedDateTime);
                    retailerAdded = true;
                }
            }
            catch (GreatOutdoorsException ex)
            {
                throw new GreatOutdoorsException(ex.Message);
            }


            return (retailerAdded, newRetailer.RetailerID);
        }

        /// <summary>
        /// Gets all retailers from the collection.
        /// </summary>
        /// <returns>Returns list of all retailers.</returns>
        public override List<Retailer> GetAllRetailersDAL()
        {
            List<Retailer> retailers = new List<Retailer>();
            try
            {
                retailers = entities.GetAllRetailers().ToList();
            }
            catch (GreatOutdoorsException ex)
            {
                throw new GreatOutdoorsException(ex.Message);
            }

            return retailers;


        }

        /// <summary>
        /// Gets retailer based on RetailerID.
        /// </summary>
        /// <param name="searchRetailerID">Represents RetailerID to search.</param>
        /// <returns>Returns Retailer object.</returns>
        public override Retailer GetRetailerByRetailerIDDAL(Guid searchRetailerID)
        {
            Retailer matchingRetailer = null;
            try
            {
                //Find Retailer based on searchRetailerID
                matchingRetailer = entities.GetRetailerByRetailerID(searchRetailerID).ToList()[0];
            }
            catch (GreatOutdoorsException ex)
            {
                throw new GreatOutdoorsException(ex.Message);
            }
            return matchingRetailer;



        }

        /// <summary>
        /// Gets retailer based on RetailerName.
        /// </summary>
        /// <param name="retailerName">Represents RetailerName to search.</param>
        /// <returns>Returns Retailer object.</returns>
        public override List<Retailer> GetRetailersByNameDAL(string retailerName)
        {
            List<Retailer> matchingRetailers = new List<Retailer>();
            try
            {
                //Find Retailer based on searchRetailerID
                matchingRetailers = entities.GetRetailerByName(retailerName).ToList();
            }
            catch (GreatOutdoorsException ex)
            {
                throw new GreatOutdoorsException(ex.Message);
            }
            return matchingRetailers;
        }

        /// <summary>
        /// Gets retailer based on email.
        /// </summary>
        /// <param name="email">Represents Retailer's Email Address.</param>
        /// <returns>Returns Retailer object.</returns>
        public override Retailer GetRetailerByEmailDAL(string email)
        {
            Retailer matchingRetailer = null;
            try
            {
                //Find Retailer based on Email and Password
                matchingRetailer = entities.GetRetailerByEmail(email).ToList()[0];

            }
            catch (GreatOutdoorsException ex)
            {
                throw new GreatOutdoorsException(ex.Message); ;
            }
            return matchingRetailer;
        }

        /// <summary>
        /// Gets retailer based on Email and Password.
        /// </summary>
        /// <param name="email">Represents Retailer's Email Address.</param>
        /// <param name="password">Represents Retailer's Password.</param>
        /// <returns>Returns Retailer object.</returns>
        public override Retailer GetRetailerByEmailAndPasswordDAL(string email, string password)
        {
            Retailer matchingRetailer = null;
            try
            {
                //Find Retailer based on Email and Password
                matchingRetailer = entities.GetRetailerByEmailAndPassword(email, password).ToList()[0];
            }
            catch (GreatOutdoorsException)
            {
                throw;
            }
            return matchingRetailer;
        }

        /// <summary>
        /// Updates retailer based on RetailerID.
        /// </summary>
        /// <param name="updateRetailer">Represents Retailer details including RetailerID, RetailerName etc.</param>
        /// <returns>Determinates whether the existing retailer is updated.</returns>
        public override (bool, Guid) UpdateRetailerDAL(Retailer updateRetailer)
        {
            bool retailerUpdated = false;
            try
            {
                //Find Retailer based on RetailerID
                // Retailer matchingRetailer = GetRetailerByRetailerIDDAL(updateRetailer.RetailerID);

                if (updateRetailer != null)
                {
                    //Update retailer details
                    updateRetailer.ModifiedDateTime = DateTime.Now;
                    entities.UpdateRetailer(updateRetailer.RetailerID, updateRetailer.RetailerName, updateRetailer.RetailerMobile, updateRetailer.Email, updateRetailer.ModifiedDateTime);


                    retailerUpdated = true;
                }
            }
            catch (GreatOutdoorsException ex)
            {
                throw new GreatOutdoorsException(ex.Message); ;
            }
            return (retailerUpdated, updateRetailer.RetailerID);

        }

        /// <summary>
        /// Deletes retailer based on RetailerID.
        /// </summary>
        /// <param name="deleteRetailerID">Represents RetailerID to delete.</param>
        /// <returns>Determinates whether the existing retailer is updated.</returns>
        public override bool DeleteRetailerDAL(Guid deleteRetailerID)
        {
            bool retailerDeleted = false;
            try
            {


                if (deleteRetailerID != null)
                {
                    //Delete Retailer from the collection

                    entities.DeleteRetailer(deleteRetailerID);
                    entities.SaveChanges();
                    retailerDeleted = true;
                }
            }
            catch (GreatOutdoorsException ex)
            {
                throw new GreatOutdoorsException(ex.Message); ;
            }
            return retailerDeleted;


        }

        /// <summary>
        /// Updates retailer's password based on RetailerID.
        /// </summary>
        /// <param name="updateRetailer">Represents Retailer details including RetailerID, Password.</param>
        /// <returns>Determinates whether the existing retailer's password is updated.</returns>
        public override bool UpdateRetailerPasswordDAL(Retailer updateRetailer)
        {
            bool passwordUpdated = false;
            try
            {
                //Find Retailer based on RetailerID
                //Retailer matchingRetailer = GetRetailerByRetailerIDDAL(updateRetailer.RetailerID);

                if (updateRetailer.RetailerID != null)
                {
                    //Update retailer details
                    //ReflectionHelpers.CopyProperties(updateRetailer, matchingRetailer, new List<string>() { "Password" });
                    updateRetailer.ModifiedDateTime = DateTime.Now;
                    entities.UpdateRetailerPassword(updateRetailer.RetailerID, updateRetailer.RetailerPassword, updateRetailer.ModifiedDateTime);

                    passwordUpdated = true;
                }
            }
            catch (GreatOutdoorsException ex)
            {
                throw new GreatOutdoorsException(ex.Message);
            }
            return passwordUpdated;
        }

        /// <summary>
        /// Clears unmanaged resources such as db connections or file streams.
        /// </summary>
        public void Dispose()
        {
            //No unmanaged resources currently
        }
    }
}



