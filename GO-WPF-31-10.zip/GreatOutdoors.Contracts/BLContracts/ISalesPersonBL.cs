﻿using GreatOutdoors.Entities;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Capgemini.GreatOutdoors.Contracts.BLContracts
{
    public interface ISalesPersonBL : IDisposable
    {
        Task<bool> AddSalesPersonBL(SalesPerson newSalesPerson);
        Task<List<SalesPerson>> GetAllSalesPersonsBL();
        Task<SalesPerson> GetSalesPersonBySalesPersonIDBL(Guid searchSalesPersonID);
        Task<List<SalesPerson>> GetSalesPersonsByNameBL(string salesPersonName);
        Task<SalesPerson> GetSalesPersonByEmailBL(string email);
        Task<SalesPerson> GetSalesPersonByEmailAndPasswordBL(string email, string password);
        Task<bool> UpdateSalesPersonBL(SalesPerson updateSalesPerson);
        Task<bool> UpdateSalesPersonDetailsBL(SalesPerson updateSalesPerson);
        Task<bool> UpdateSalesPersonPasswordBL(SalesPerson updateSalesPerson);
        Task<bool> DeleteSalesPersonBL(Guid deleteSalesPersonID);

    }
}


