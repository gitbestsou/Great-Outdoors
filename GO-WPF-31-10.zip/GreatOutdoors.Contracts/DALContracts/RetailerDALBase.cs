﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Newtonsoft.Json;
using GreatOutdoors.Entities;

namespace Capgemini.GreatOutdoors.Contracts.DALContracts
{
    /// <summary>
    /// This abstract class acts as a base for RetailerDAL class
    /// </summary>
    public abstract class RetailerDALBase
    {

        //Collection of Retailers
        protected static List<Retailer> retailerList = new List<Retailer>(){};
        private static string fileName = "retailers.json";

        //Methods for CRUD operations
        public abstract (bool,Guid) AddRetailerDAL(Retailer newRetailer);
        public abstract List<Retailer> GetAllRetailersDAL();
        public abstract Retailer GetRetailerByRetailerIDDAL(Guid searchRetailerID);
        public abstract List<Retailer> GetRetailersByNameDAL(string retailerName);
        public abstract Retailer GetRetailerByEmailDAL(string email);
        public abstract Retailer GetRetailerByEmailAndPasswordDAL(string email, string password);
        public abstract (bool ,Guid) UpdateRetailerDAL(Retailer updateRetailer);
        public abstract bool UpdateRetailerPasswordDAL(Retailer updateRetailer);
        public abstract bool DeleteRetailerDAL(Guid deleteRetailerID);

       
    }
}


