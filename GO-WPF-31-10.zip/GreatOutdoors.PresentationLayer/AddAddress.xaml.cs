﻿using Capgemini.GreatOutdoors.BusinessLayer;
using GreatOutdoors.Entities;
using GreatOutdoors.PresentationLayer;
using System.Text.RegularExpressions;
using System.Windows;

namespace Capgemini.GreatOutdoors.PresentationLayer
{
    /// <summary>
    /// Interaction logic for AddAddress.xaml
    /// </summary>
    public partial class AddAddress : Window
    {
        //Constructor
        public AddAddress()
        {
            InitializeComponent();
        }

        //Event function to add address
        private async void Button_Click_AddAddress(object sender, RoutedEventArgs e)
        {
            if (txtLine1.Text.Length == 0)
            {

                MessageBox.Show("Enter Line1.");

                txtLine1.Focus();
            }
            else if (txtLine2.Text.Length == 0)
            {

                MessageBox.Show("Enter Line2.");

                txtLine2.Focus();
            }
            else if (!Regex.IsMatch(txtCity.Text, "^[A-Za-z ]*$"))
            {

                MessageBox.Show("Enter a valid City.");
                txtCity.Select(0, txtCity.Text.Length);
                txtCity.Focus();
            }
            else if(!Regex.IsMatch(txtPincode.Text, "^([0-9]{6})$"))
            {
                MessageBox.Show("Enter Valid Pincode");
                txtPincode.Select(0, txtPincode.Text.Length);
                txtPincode.Focus();
            }
            else if(!Regex.IsMatch(txtState.Text, "^[A-Za-z]*$"))
            {
                MessageBox.Show("Enter Valid State Name");
                txtState.Select(0, txtState.Text.Length);
                txtState.Focus();
            }
            else if(!Regex.IsMatch(txtMobileNo.Text, "^([9876]{1})([234789]{1})([0-9]{8})$"))
            {
                MessageBox.Show("Enter Valid Mobile No.");
                txtMobileNo.Select(0, txtMobileNo.Text.Length);
                txtMobileNo.Focus();
            }
            else
            {
                Address address = new Address();
                Retailer retailer = new Retailer();
                RetailerBL retailerBL = new RetailerBL();
                retailer = await retailerBL.GetRetailerByEmailAndPasswordBL(UserType.Email, UserType.Password);
                address.RetailerID = retailer.RetailerID;
                address.Line1 = txtLine1.Text;
                address.Line2 = txtLine2.Text;
                address.City = txtCity.Text;
                address.Pincode = txtPincode.Text;
                address.State = txtState.Text;
                address.MobileNo = txtMobileNo.Text;

                AddressBL addressBL = new AddressBL();
                bool x = await addressBL.AddAddressBL(address);

                if (x == true)
                {
                    MessageBox.Show("Address Added Successfully");

                    //Calling the Address Home Page after the address addition is succesful
                    AddressHome addressHome = new AddressHome();
                    addressHome.Show();
                    this.Close();
                }

                if (x == false)
                {
                    MessageBox.Show("Address not added. Please re-enter the address");
                }
            }
        }
    }
}
