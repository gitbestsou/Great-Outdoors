﻿using Capgemini.GreatOutdoors.BusinessLayer;
using Capgemini.GreatOutdoors.PresentationLayer;
using GreatOutdoors.Entities;
using System;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;

namespace GreatOutdoors.PresentationLayer
{
    /// <summary>
    /// Interaction logic for AddProduct.xaml
    /// </summary>
    public partial class AddProduct : Window
    {
        ProductBL productBL = new ProductBL();
        public AddProduct()
        {
            InitializeComponent();
        }

        private async void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            if(txtName.Text.Length <2 || txtName.Text.Length > 40)
            {
                MessageBox.Show("Name should be between 2 and 40 characters");
            }
            else if(!Regex.IsMatch(txtName.Text, "^[A-Za-z ]*$"))
            {
                MessageBox.Show("Name should contain only alphabets");
            }
            else if (!Regex.IsMatch(txtStock.Text, "^[0-9]*$"))
            {
                MessageBox.Show("Please enter only integers");
            }

            else if(!Regex.IsMatch(txtCostPrice.Text, "^[0-9.]*$"))
            {
                MessageBox.Show("Please enter only decimal values");
            }

            else if (!Regex.IsMatch(txtSellingPrice.Text, "^[0-9.]*$"))
            {
                MessageBox.Show("Please enter only decimal values");
            }

            else if (!Regex.IsMatch(txtDiscountPercentage.Text, "^[0-9.]*$"))
            {
                MessageBox.Show("Please enter only decimal values");
            }

            else
            {
                Product product = new Product();
                product.Name = txtName.Text;
                product.Category = cmbCategory.Text;
                product.Colour = txtColour.Text;
                product.Size = txtSize.Text;
                product.Stock = Convert.ToInt32(txtStock.Text);
                product.CostPrice = Convert.ToDecimal(txtCostPrice.Text);
                product.SellingPrice = Convert.ToDecimal(txtSellingPrice.Text);
                product.DiscountPercentage = Convert.ToDecimal(txtDiscountPercentage.Text);
                product.TechnicalSpecifications = txtTechSpecs.Text;
                bool isAdded = await productBL.AddProductBL(product);
                if (isAdded)
                {
                    MessageBox.Show("Product added successfully!");
                    Window window = new Products();
                    window.Show();
                    this.Close();
                }
            }
            
               
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            Window window = new Products();
            window.Show();
            this.Close();
        }


        private void MenuItem_Click_Product(object sender, RoutedEventArgs e)
        {
            Window window = new Products();
            window.Show();
            this.Close();
        }

        private void MenuItem_Click_SalesPerson(object sender, RoutedEventArgs e)
        {
            Window window = new AddSalesPerson();
            window.Show();
            this.Close();
        }

        private void MenuItem_Click_AdminHome(object sender, RoutedEventArgs e)
        {
            AdminHome adminHomeWindow = new AdminHome();
            adminHomeWindow.Show();
            this.Close();
        }

        private void MenuItem_Click_Logout(object sender, RoutedEventArgs e)
        {
            MainWindow login = new MainWindow();
            login.Show();
            this.Close();
        }

    }
}
