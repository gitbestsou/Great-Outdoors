﻿using System;
using System.Text.RegularExpressions;
using System.Windows;
using Capgemini.GreatOutdoors.BusinessLayer;
using GreatOutdoors.Entities;
using GreatOutdoors.PresentationLayer;

namespace Capgemini.GreatOutdoors.PresentationLayer
{
    /// <summary>
    /// Interaction logic for AddSalesPerson.xaml
    /// </summary>
    public partial class AddSalesPerson : Window
    {
        SalesPersonBL salesPersonBL = new SalesPersonBL();
        public AddSalesPerson()
        {
            InitializeComponent();
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            Window window = new SalesPersons();
            window.Show();
            this.Close();
        }

        private async void BtnSave_Click(object sender, RoutedEventArgs e)
        {

            if(txtName.Text.Length < 2 || txtName.Text.Length > 40)
            {
                MessageBox.Show("Name should be between 2 and 40 characters");
            }

            else if (!Regex.IsMatch(txtName.Text, "^[A-Za-z ]*$"))
            {
                MessageBox.Show("Name should contain only alphabets");
            }
            else if (!Regex.IsMatch(txtEmail.Text, @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$"))
            {
                MessageBox.Show("Enter valid email!");
            }

            else if (txtMobile.Text.Length != 10)
            {
                MessageBox.Show("Please Enter 10 digit mobile number!");

            }

            else if (!Regex.IsMatch(txtMobile.Text, "^([9]{1})([234789]{1})([0-9]{8})$"))
            {
                MessageBox.Show("Please enter valid mobile number!");

            }

            else if (!Regex.IsMatch(txtSalary.Text, "^[0-9.]*$"))
            {
                MessageBox.Show("Please enter only decimal values");
            }
            else if (!Regex.IsMatch(txtBonus.Text, "^[0-9.]*$"))
            {
                MessageBox.Show("Please enter only decimal values");
            }
            else if (!Regex.IsMatch(txtTarget.Text, "^[0-9.]*$"))
            {
                MessageBox.Show("Please enter only decimal values");
            }

            else if (!Regex.IsMatch(txtCity.Text, "^[A-Za-z ]*$"))
            {
                MessageBox.Show("City should contain only alphabets");
            }

            else if (!Regex.IsMatch(txtState.Text, "^[A-Za-z ]*$"))
            {
                MessageBox.Show("State should contain only alphabets");
            }

            else if (!Regex.IsMatch(txtPincode.Text, "^[0-9]*$"))
            {
                MessageBox.Show("Pincode should contain only numbers");
            }

            else
            {
                SalesPerson salesPerson = new SalesPerson();

                salesPerson.Name = txtName.Text;
                salesPerson.Mobile = txtMobile.Text;
                salesPerson.Email = txtEmail.Text;
                salesPerson.Password = txtPassword.Text;
                salesPerson.Pincode = txtPincode.Text;
                salesPerson.Salary = Convert.ToDecimal(txtSalary.Text);
                salesPerson.Target = Convert.ToDecimal(txtTarget.Text);
                salesPerson.Bonus = Convert.ToDecimal(txtBonus.Text);
                salesPerson.City = txtCity.Text;
                salesPerson.State = txtState.Text;
                salesPerson.AddressLine1 = txtAddressL1.Text;
                salesPerson.AddressLine2 = txtAddressL2.Text;
                salesPerson.Birthdate = Convert.ToDateTime(txtBirthDate.Text);
                salesPerson.JoiningDate = Convert.ToDateTime(txtJoiningDate.Text);

                bool isAdded = await salesPersonBL.AddSalesPersonBL(salesPerson);

                if (isAdded)
                    MessageBox.Show("Sales person added successfully!");

                Window window = new SalesPersons();
                window.Show();
                this.Close();


            }

        }


        private void MenuItem_Click_Product(object sender, RoutedEventArgs e)
        {
            Window window = new Products();
            window.Show();
            this.Close();
        }

        private void MenuItem_Click_SalesPerson(object sender, RoutedEventArgs e)
        {
            Window window = new AddSalesPerson();
            window.Show();
            this.Close();
        }

        private void MenuItem_Click_AdminHome(object sender, RoutedEventArgs e)
        {
            AdminHome adminHomeWindow = new AdminHome();
            adminHomeWindow.Show();
            this.Close();
        }

        private void MenuItem_Click_Logout(object sender, RoutedEventArgs e)
        {
            MainWindow login = new MainWindow();
            login.Show();
            this.Close();
        }
    }
}