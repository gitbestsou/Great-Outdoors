﻿
using System.Text.RegularExpressions;
using System.Windows;
using Capgemini.GreatOutdoors.BusinessLayer;

namespace Capgemini.GreatOutdoors.PresentationLayer
{
    /// <summary>
    /// Interaction logic for EditSalesPerson.xaml
    /// </summary>
    public partial class EditSalesPerson : Window
    {
        public EditSalesPerson()
        {
            InitializeComponent();
        }

        private async void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            if(txtMobile.Text.Length != 10  )
            {
                MessageBox.Show("Please Enter 10 digit mobile number!");

            }

            else if (!Regex.IsMatch(txtMobile.Text, "^([9]{1})([234789]{1})([0-9]{8})$"))
            {
                MessageBox.Show("Please enter valid mobile number!");

            }
            else if (!Regex.IsMatch(txtEmail.Text, @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$"))
            {
                MessageBox.Show("Enter valid email!");
            }

            else if (!Regex.IsMatch(txtName.Text, "^[A-Za-z ]*$"))
            {
                MessageBox.Show("Name should contain only alphabets");
            }
            else
            {
                SalesPersonHome.currentSalesPerson.Name = txtName.Text;
                SalesPersonHome.currentSalesPerson.Email = txtEmail.Text;
                SalesPersonHome.currentSalesPerson.Mobile = txtMobile.Text;
                SalesPersonBL salesPersonBL = new SalesPersonBL();
                bool updated = await salesPersonBL.UpdateSalesPersonBL(SalesPersonHome.currentSalesPerson);
                bool password = await salesPersonBL.UpdateSalesPersonPasswordBL(SalesPersonHome.currentSalesPerson);

                if (updated && password)
                    MessageBox.Show("Details updated successfully!");

                Window window = new SalesPersonHome();
                window.Show();
                this.Close();
            }
           
            

        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            Window window = new SalesPersonHome();
            window.Show();
            this.Close();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            txtName.Text = SalesPersonHome.currentSalesPerson.Name;
            txtEmail.Text = SalesPersonHome.currentSalesPerson.Email;
            txtMobile.Text = SalesPersonHome.currentSalesPerson.Mobile;
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            Window window = new SalesPersonHome();
            window.Show();
            this.Close();
        }

        private void MenuItem_Click_Logout(object sender, RoutedEventArgs e)
        {
            MainWindow login = new MainWindow();
            login.Show();
            this.Close();
        }

        private void BtnHistory_Click(object sender, RoutedEventArgs e)
        {
            Window window = new ViewSalesHistory();
            window.Show();
            this.Close();
        }
    }
}
