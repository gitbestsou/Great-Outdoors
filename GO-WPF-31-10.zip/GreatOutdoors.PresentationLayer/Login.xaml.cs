﻿using GreatOutdoors.Entities;
using Capgemini.GreatOutdoors.BusinessLayer;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using GreatOutdoors.PresentationLayer;
using Capgemini.GreatOutdoors.Exceptions;


namespace Capgemini.GreatOutdoors.PresentationLayer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private async void Login_Click(object sender, RoutedEventArgs e)
        {
            //if(tbxEmail.Text)
            try
            {

                ComboBoxItem typeItem = (ComboBoxItem)cbxUser.SelectedItem;
                string value = typeItem.Content.ToString();

                if (value == "Admin")
                {
                    AdminBL adminBL = new AdminBL();
                    Admin admin = new Admin();
                    admin = await adminBL.GetAdminByEmailAndPasswordBL(tbxEmail.Text, tbxPassword.Password);

                    if (admin != null)
                    {
                        UserType.Email = admin.Email;
                        UserType.Password = admin.Password;
                        Window window = new AdminHome();
                        window.Show();
                        this.Close();
                    }

                    if (admin == null)
                    {
                        MessageBox.Show("Invalid Email and Password");
                        this.Show();
                    }
                }

                if (value == "Sales Person")
                {
                    SalesPersonBL salesPersonBL = new SalesPersonBL();
                    SalesPerson salesPerson = await salesPersonBL.GetSalesPersonByEmailAndPasswordBL(tbxEmail.Text, tbxPassword.Password);

                    if (salesPerson != null)
                    {
                        UserType.Email = salesPerson.Email;
                        UserType.Password = salesPerson.Password;
                        Window window = new SalesPersonHome();
                        window.Show();
                        this.Close();
                    }

                    if (salesPerson == null)
                    {
                        MessageBox.Show("Invalid Email and Password");
                        this.Show();
                    }
                }

                if (value == "Retailer")
                {
                    Retailer retailer = new Retailer();
                    RetailerBL retailerBL = new RetailerBL();
                    retailer = await retailerBL.GetRetailerByEmailAndPasswordBL(tbxEmail.Text, tbxPassword.Password);

                    if (retailer != null)
                    {
                        UserType.Email = retailer.Email;
                        UserType.Password = retailer.RetailerPassword;
                        Window window = new RetailerHome();
                        window.Show();
                        this.Close();
                    }



                    if (retailer == null)
                    {
                        MessageBox.Show("Invalid Email and Password");
                        this.Show();
                    }
                }
            } catch (GreatOutdoorsException)
            {
                MessageBox.Show("Please select a User Type");
                this.Show();
            }
            }

        private void Register_Click(object sender, RoutedEventArgs e)
        {
            Window window = new Registration();
            window.Show();
            this.Close();
        }
    }
}
