﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;
using GreatOutdoors.Entities;
using Capgemini.GreatOutdoors.BusinessLayer;
using Capgemini.GreatOutdoors.Contracts.BLContracts;
using Capgemini.GreatOutdoors.PresentationLayer;

namespace GreatOutdoors.PresentationLayer
{
    /// <summary>
    /// Interaction logic for OrderHistory.xaml
    /// </summary>
    public partial class OrderHistory : Window
    {
        public OrderHistory()
        {
            InitializeComponent();
            FillData();
        }

        /*private void ShowDetails(object sender, RoutedEventArgs e)
      {


      }*/
        Guid ID;
        private void clickOrder(object sender, SelectionChangedEventArgs e)
        {

            int rowindex = OrdersHistory.SelectedIndex;
            if (rowindex < 0) { return; }
            ID = Guid.Parse(getCellData(OrdersHistory, rowindex, 0));
            //rough.Text = ID.ToString();
            //this.Visibility = Visibility.Collapsed;
            Window nt = new ViewOrderDetails(ID);
            nt.Show();
            this.Close();
            //this.Visibility = Visibility.Visible;
        }
        private string getCellData(DataGrid dg, int rowindex, int cellindex)
        {
            DataGridRow drow = dg.ItemContainerGenerator.ContainerFromIndex(rowindex) as DataGridRow;
            var cellContent = dg.Columns[cellindex].GetCellContent(drow) as TextBlock;
            return cellContent.Text;

        }

        private async void FillData()
        {
            List<Order> OH = new List<Order>();
            using (IOrdersBL orderAccess = new OrderBL())
            {

                OH = await orderAccess.GetOrderByRetailerIDBL(RetailerHome.currentRetailer.RetailerID);

            }

            OrdersHistory.ItemsSource = OH;
            OrdersHistory.Columns[0].MaxWidth = 0;

            //SqlConnection sqlConnection = new SqlConnection(Properties.Settings.Default.dbConn);
            //SqlCommand sqlcmd = new SqlCommand("select TotalQuantity,TotalAmount, from TeamA.Orders", sqlConnection);
            //sqlConnection.Open();
            //SqlDataAdapter adapter = new SqlDataAdapter(sqlcmd);
            //DataTable dataTable = new DataTable();
            //adapter.Fill(dataTable);
            //OrderHistory.ItemsSource = dataTable.DefaultView;
            //sqlConnection.Close();
            //OrderHistory.Columns[0].Header = "Action";



        }

        private void ViewRH(object sender, RoutedEventArgs e)
        {
            Window nt = new ViewReturnHistory();
            nt.Show();
            this.Close();
        }


        private void MenuItem_Click_RetailerHome(object sender, RoutedEventArgs e)
        {
            RetailerHome retailerHome = new RetailerHome();
            retailerHome.Show();
            this.Close();
        }

        private void MenuItem_Click_PlaceOrder(object sender, RoutedEventArgs e)
        {
            Window window = new OrderWindow();
            window.Show();
            this.Close();
        }

        private void MenuItem_Click_AddressHome(object sender, RoutedEventArgs e)
        {
            AddressHome addressHome = new AddressHome();
            addressHome.Show();
            this.Close();
        }

        private void MenuItem_Click_ReturnCancelOrder(object sender, RoutedEventArgs e)
        {
            Window window = new OrderHistory();
            window.Show();
            this.Close();
        }

        private void MenuItem_Click_Logout(object sender, RoutedEventArgs e)
        {
            MainWindow login = new MainWindow();
            login.Show();
            this.Close();
        }


    }
}
