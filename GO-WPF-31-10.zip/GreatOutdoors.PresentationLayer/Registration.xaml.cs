﻿using System;
using System.Windows;
using Capgemini.GreatOutdoors.Contracts.BLContracts;
using GreatOutdoors.Entities;
using Capgemini.GreatOutdoors.BusinessLayer;
using System.Text.RegularExpressions;

namespace Capgemini.GreatOutdoors.PresentationLayer
{
    /// <summary>
    /// Interaction logic for Registration.xaml
    /// </summary>
    public partial class Registration : Window
    {
        public Registration()
        {
            InitializeComponent();
            Reset();
        }
        private void Reset_Click(object sender, RoutedEventArgs e)
        {
            Reset();
        }
        public void Reset()
        {
            textBoxRetailerName.Text = "";
            textBoxRetailerMobile.Text = "";
            textBoxEmail.Text = "";
            textBoxRetailerPassword.Text = "";

        }


        private void Login_Click(object sender, RoutedEventArgs e)
        {
            Window login = new MainWindow();
            login.Show();
            Close();
        }
        public async void RetailerRegistration(object sender, RoutedEventArgs e)
        {
            if (textBoxRetailerName.Text.Length == 0)
            {

                MessageBox.Show("Enter Name.");

                textBoxEmail.Focus();
            }
            else if (!Regex.IsMatch(textBoxRetailerName.Text, "^[A-Za-z ]*$"))
            {

                MessageBox.Show("Enter a valid Name.");
                textBoxRetailerName.Select(0, textBoxRetailerName.Text.Length);
                textBoxRetailerName.Focus();
            }

            else if (!Regex.IsMatch(textBoxRetailerMobile.Text, "^([9]{1})([234789]{1})([0-9]{8})$"))
            {

                MessageBox.Show("Enter a valid Mobile number.");
                textBoxRetailerName.Select(0, textBoxRetailerMobile.Text.Length);
                textBoxRetailerName.Focus();
            }

            else if (textBoxEmail.Text.Length == 0)
            {

                MessageBox.Show("Enter an email.");

                textBoxEmail.Focus();
            }
            else if (!Regex.IsMatch(textBoxEmail.Text, @"^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$"))
            {

                MessageBox.Show("Enter a valid email.");
                textBoxEmail.Select(0, textBoxEmail.Text.Length);
                textBoxEmail.Focus();
            }
            else
            {
                try
                {
                    //Read inputs
                    Retailer retailer = new Retailer();

                    retailer.RetailerName = textBoxRetailerName.Text;

                    retailer.RetailerMobile = textBoxRetailerMobile.Text.ToString();

                    retailer.Email = textBoxEmail.Text.ToString();

                    retailer.RetailerPassword = textBoxRetailerPassword.Text.ToString();



                    using (IRetailerBL retailerBL = new RetailerBL())
                    {
                        bool isAdded = await retailerBL.AddRetailerBL(retailer);
                        if (isAdded)
                        {

                            MessageBox.Show("Retailer Added");

                        }
                    }
                }
                catch (Exception ex)
                {

                    MessageBox.Show(ex.Message);
                }
            }


            


        }


    }
}
