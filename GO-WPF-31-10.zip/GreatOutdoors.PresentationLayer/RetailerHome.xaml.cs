﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using GreatOutdoors.Entities;
using Capgemini.GreatOutdoors.BusinessLayer;
using GreatOutdoors.PresentationLayer;

namespace Capgemini.GreatOutdoors.PresentationLayer
{
    /// <summary>
    /// Interaction logic for RetailerHome.xaml
    /// </summary>
    public partial class RetailerHome : Window
    {
        public static Retailer currentRetailer = new Retailer();

        public RetailerHome()
        {
            InitializeComponent();
        }


        private async void Window_Loaded(object sender, RoutedEventArgs e)
        {


           
            RetailerBL retailerBL = new RetailerBL();

            currentRetailer = await retailerBL.GetRetailerByEmailAndPasswordBL(UserType.Email, UserType.Password);

            textBoxRetailerName2.Text = currentRetailer.RetailerName;

            textBoxRetailerMobile2.Text = currentRetailer.RetailerMobile;

            textBoxEmail2.Text = currentRetailer.Email;



        }

        private async void UpdateDetails(object sender, RoutedEventArgs e)
        {

           
            RetailerBL updateRetailerBL = new RetailerBL();


            currentRetailer.RetailerName = textBoxRetailerName2.Text;

            currentRetailer.RetailerMobile = textBoxRetailerMobile2.Text;

            currentRetailer.Email = textBoxEmail2.Text;

            await updateRetailerBL.UpdateRetailerBL(currentRetailer);

            MessageBox.Show("Details updated successfully!");

        }

        private void MenuItem_Click_RetailerHome(object sender, RoutedEventArgs e)
        {
            RetailerHome retailerHome = new RetailerHome();
            retailerHome.Show();
            this.Close();
        }

        private void MenuItem_Click_PlaceOrder(object sender, RoutedEventArgs e)
        {
            Window window = new OrderWindow();
            window.Show();
            this.Close();
        }

        private void MenuItem_Click_AddressHome(object sender, RoutedEventArgs e)
        {
            AddressHome addressHome = new AddressHome();
            addressHome.Show();
            this.Close();
        } 
        
        private void MenuItem_Click_ReturnCancelOrder(object sender, RoutedEventArgs e)
        {
            Window window = new OrderHistory();
            window.Show();
            this.Close();
        }

        private void MenuItem_Click_Logout(object sender, RoutedEventArgs e)
        {
            MainWindow login = new MainWindow();
            login.Show();
            this.Close();
        }
    }
}
