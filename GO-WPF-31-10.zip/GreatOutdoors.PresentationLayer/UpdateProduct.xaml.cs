﻿using Capgemini.GreatOutdoors.BusinessLayer;
using Capgemini.GreatOutdoors.PresentationLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GreatOutdoors.PresentationLayer
{
    /// <summary>
    /// Interaction logic for UpdateProduct.xaml
    /// </summary>
    public partial class UpdateProduct : Window
    {
        Products window = new Products();
        public UpdateProduct()
        {
            InitializeComponent();
        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

            txtStock.Text = (Products.updtProduct.Stock).ToString();
            txtTechSpecs.Text = Products.updtProduct.TechnicalSpecifications;
            txtCostPrice.Text = (Products.updtProduct.CostPrice).ToString();
            txtSellingPrice.Text = (Products.updtProduct.SellingPrice).ToString();
            txtDiscountPercentage.Text = (Products.updtProduct.DiscountPercentage).ToString();
        }

        private async void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            Products.updtProduct.Stock = Convert.ToInt32(txtStock.Text);
            Products.updtProduct.TechnicalSpecifications = txtTechSpecs.Text;
            Products.updtProduct.SellingPrice = Convert.ToDecimal(txtSellingPrice.Text);
            Products.updtProduct.CostPrice = Convert.ToDecimal(txtCostPrice.Text);
            Products.updtProduct.DiscountPercentage = Convert.ToDecimal(txtDiscountPercentage.Text);

            ProductBL productBL = new ProductBL();
            bool updated = await productBL.UpdateProductDetailsBL(Products.updtProduct);
            bool stock = await productBL.UpdateProductStockBL(Products.updtProduct);
            bool discount = await productBL.UpdateProductDiscountBL(Products.updtProduct);

            if (updated && stock && discount)
                MessageBox.Show("Product Updated successfully!");

            window.Show();
            this.Close();
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void MenuItem_Click_Product(object sender, RoutedEventArgs e)
        {
            Window window = new Products();
            window.Show();
            this.Close();
        }

        private void MenuItem_Click_SalesPerson(object sender, RoutedEventArgs e)
        {
            Window window = new AddSalesPerson();
            window.Show();
            this.Close();
        }

        private void MenuItem_Click_AdminHome(object sender, RoutedEventArgs e)
        {
            AdminHome adminHomeWindow = new AdminHome();
            adminHomeWindow.Show();
            this.Close();
        }
        private void MenuItem_Click_Logout(object sender, RoutedEventArgs e)
        {
            MainWindow login = new MainWindow();
            login.Show();
            this.Close();
        }
    }
}
