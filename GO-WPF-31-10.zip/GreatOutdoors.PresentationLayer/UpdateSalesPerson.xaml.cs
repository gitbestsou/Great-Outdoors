﻿using System;
using System.Windows;
using Capgemini.GreatOutdoors.BusinessLayer;
using GreatOutdoors.PresentationLayer;

namespace Capgemini.GreatOutdoors.PresentationLayer
{
    /// <summary>
    /// Interaction logic for UpdateSalesPerson.xaml
    /// </summary>
    public partial class UpdateSalesPerson : Window
    {
        SalesPersonBL salesPersonBL = new SalesPersonBL();
        public UpdateSalesPerson()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            txtBonus.Text = Convert.ToString(SalesPersons.salesPerson.Bonus);
            txtSalary.Text = Convert.ToString(SalesPersons.salesPerson.Salary);
            txtTarget.Text = Convert.ToString(SalesPersons.salesPerson.Target);
        }

        private async void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            SalesPersons.salesPerson.Bonus = Convert.ToDecimal(txtBonus.Text);
            SalesPersons.salesPerson.Salary = Convert.ToDecimal(txtSalary.Text);
            SalesPersons.salesPerson.Target = Convert.ToDecimal(txtTarget.Text);

            bool isUpdated = await salesPersonBL.UpdateSalesPersonDetailsBL(SalesPersons.salesPerson);
            if (isUpdated)
                MessageBox.Show("Sales person updated successfully!");
            Window window = new SalesPersons();
            window.Show();
            this.Close();

        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            Window window = new SalesPersons();
            window.Show();
            this.Close();
        }

        private void MenuItem_Click_Product(object sender, RoutedEventArgs e)
        {
            Window window = new Products();
            window.Show();
            this.Close();
        }

        private void MenuItem_Click_SalesPerson(object sender, RoutedEventArgs e)
        {
            Window window = new AddSalesPerson();
            window.Show();
            this.Close();
        }

        private void MenuItem_Click_AdminHome(object sender, RoutedEventArgs e)
        {
            AdminHome adminHomeWindow = new AdminHome();
            adminHomeWindow.Show();
            this.Close();
        }
        private void MenuItem_Click_Logout(object sender, RoutedEventArgs e)
        {
            MainWindow login = new MainWindow();
            login.Show();
            this.Close();
        }
    }
}