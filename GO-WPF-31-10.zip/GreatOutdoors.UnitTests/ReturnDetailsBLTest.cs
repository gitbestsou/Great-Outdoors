﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Capgemini.GreatOutdoors.BusinessLayer;
using Capgemini.GreatOutdoors.Entities;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Capgemini.GreatOutdoors.UnitTests
{
    [TestClass]
    public class AddReturnDetailsBLTest
    {
        [TestMethod]
        public async Task AddValidReturnDetails()
        {
            ReturnDetailsBL returnDetailsBL = new ReturnDetailsBL();
            ReturnDetails returnDetails = new ReturnDetails() { ReturnID = default(Guid), ProductID = default(Guid), Quantity = 5, ReasonOfReturn = ReturnReasons.Incomplete, UnitPrice = 800, TotalPrice = 4000, AddressID = default(Guid) };
            bool isAdded = false;
            string errorMessage = null;
            ReturnBL returnBL = new ReturnBL();
            bool returnAdded;
            Guid returnIDFromReturnClass;
            Return returnObj = new Return();
            (returnAdded, returnIDFromReturnClass) = await returnBL.AddReturnBL(returnObj);
            returnDetails.ReturnID = returnIDFromReturnClass;

            try
            {

                (isAdded) = await returnDetailsBL.AddReturnDetailsBL(returnDetails);
            }
            catch (Exception ex)
            {
                isAdded = false;

                errorMessage = ex.Message;
            }
            finally
            {
                Assert.IsTrue(isAdded, errorMessage);
            }
        }

    }   //

    [TestClass]
    public class GetReturnDetailsBL
    {
        
        public async Task ValidGetReturnDetailsByReturnIDBL()
        {
            ReturnDetailsBL returnDetailsBL = new ReturnDetailsBL();
            ReturnDetails returnDetails = new ReturnDetails() { ReturnID = default(Guid), ProductID = default(Guid), Quantity = 5, ReasonOfReturn = ReturnReasons.Incomplete, UnitPrice = 800, TotalPrice = 4000, AddressID = default(Guid) };
            bool isAdded = false;
            bool isFetched = false;
            string errorMessage = null;
            ReturnBL returnBL = new ReturnBL();
            bool returnAdded;
            Guid returnIDFromReturnClass;
            Return returnObj = new Return();
            (returnAdded, returnIDFromReturnClass) = await returnBL.AddReturnBL(returnObj);
            returnDetails.ReturnID = returnIDFromReturnClass;
            isAdded = await returnDetailsBL.AddReturnDetailsBL(returnDetails);
            try
            {
                if(returnDetails.Equals(await returnDetailsBL.GetReturnDetailsByReturnIDBL(returnDetails.ReturnID)))
                    {
                    isFetched = true;
                    }
            }
            catch (Exception ex)
            {
                isFetched = false;
                errorMessage = ex.Message;

            }
            finally
            {
                Assert.IsTrue(isFetched, errorMessage);
            }


        }
        [TestMethod]
        public async Task InvalidGetReturnDetailsByReturnIDBL()
        {
            ReturnDetailsBL returnDetailsBL = new ReturnDetailsBL();
            ReturnDetails returnDetails = new ReturnDetails() { ReturnID = default(Guid), ProductID = default(Guid), Quantity = 5, ReasonOfReturn = ReturnReasons.Incomplete, UnitPrice = 800, TotalPrice = 4000, AddressID = default(Guid) };
            bool isAdded = false;
            bool isFetched = false;
            string errorMessage = null;
            ReturnBL returnBL = new ReturnBL();
            bool returnAdded;
            Guid returnIDFromReturnClass;
            Return returnObj = new Return();
            (returnAdded, returnIDFromReturnClass) = await returnBL.AddReturnBL(returnObj);
            returnDetails.ReturnID = returnIDFromReturnClass;
            isAdded = await returnDetailsBL.AddReturnDetailsBL(returnDetails);
            Guid Id = new Guid();
            try
            {
                List<ReturnDetails> returnDetailsList = new List<ReturnDetails>();
                if ((returnDetailsList=(await returnDetailsBL.GetReturnDetailsByReturnIDBL(Id)))==null)
                {
                    isFetched = false;
                }
            }
            catch (Exception ex)
            {
                isFetched = true;
                errorMessage = ex.Message;

            }
            finally
            {
                Assert.IsTrue(isFetched, errorMessage);
            }


        }




        public async Task ValidGetReturnDetailsByProductIDBL()
        {
            ReturnDetailsBL returnDetailsBL = new ReturnDetailsBL();
            ReturnDetails returnDetails = new ReturnDetails() { ReturnID = default(Guid), ProductID = default(Guid), Quantity = 5, ReasonOfReturn = ReturnReasons.Incomplete, UnitPrice = 800, TotalPrice = 4000, AddressID = default(Guid) };
            bool isAdded = false;
            bool isFetched = false;
            string errorMessage = null;
            ReturnBL returnBL = new ReturnBL();
            bool returnAdded;
            Guid returnIDFromReturnClass;
            Return returnObj = new Return();
            (returnAdded, returnIDFromReturnClass) = await returnBL.AddReturnBL(returnObj);
            returnDetails.ReturnID = returnIDFromReturnClass;
            isAdded = await returnDetailsBL.AddReturnDetailsBL(returnDetails);
            try
            {
                if (returnDetails.Equals(await returnDetailsBL.GetReturnDetailsByReturnIDBL(returnDetails.ProductID)))
                {
                    isFetched = true;
                }
            }
            catch (Exception ex)
            {
                isFetched = false;
                errorMessage = ex.Message;

            }
            finally
            {
                Assert.IsTrue(isFetched, errorMessage);
            }


        }
        [TestMethod]
        public async Task InvalidGetReturnDetailsByProductIDBL()
        {
            ReturnDetailsBL returnDetailsBL = new ReturnDetailsBL();
            ReturnDetails returnDetails = new ReturnDetails() { ReturnID = default(Guid), ProductID = default(Guid), Quantity = 5, ReasonOfReturn = ReturnReasons.Incomplete, UnitPrice = 800, TotalPrice = 4000, AddressID = default(Guid) };
            bool isAdded = false;
            bool isFetched = false;
            string errorMessage = null;
            ReturnBL returnBL = new ReturnBL();
            bool returnAdded;
            Guid returnIDFromReturnClass;
            Return returnObj = new Return();
            (returnAdded, returnIDFromReturnClass) = await returnBL.AddReturnBL(returnObj);
            returnDetails.ReturnID = returnIDFromReturnClass;
            isAdded = await returnDetailsBL.AddReturnDetailsBL(returnDetails);
            Guid Id = new Guid();
            try
            {
                List<ReturnDetails> returnDetailsList = new List<ReturnDetails>();
                if ((returnDetailsList = (await returnDetailsBL.GetReturnDetailsByProductIDBL(Id))) == null)
                {
                    isFetched = false;
                }
            }
            catch (Exception ex)
            {
                isFetched = true;
                errorMessage = ex.Message;

            }
            finally
            {
                Assert.IsTrue(isFetched, errorMessage);
            }


        }



    }


    [TestClass]
    public class DeleteReturnDetailsBLTest
    {
        [TestMethod]
        public async Task ValidDeleteReturnDetailsBLTest()
        {
            /*Guid ReturnDetailID 
            Guid ReturnID 
            Guid ProductID 
            int Quantity 
            ReturnReasons ReasonOfReturn 
            double UnitPrice 
            Guid AddressID 
            double TotalPrice*/
            ReturnDetailsBL returnDetailsBL = new ReturnDetailsBL();
            ReturnDetails returnDetails = new ReturnDetails() { ReturnID = default(Guid),ProductID= default(Guid),Quantity = 5,ReasonOfReturn= ReturnReasons.Incomplete,UnitPrice = 800,TotalPrice = 4000,AddressID = default(Guid)};
            bool isDeleted = false;
            string errorMessage = null;
            ReturnBL returnBL = new ReturnBL();
            bool returnAdded;
            Guid returnIDFromReturnClass;
            Return returnObj = new Return(); 
            (returnAdded, returnIDFromReturnClass) = await returnBL.AddReturnBL(returnObj);
            returnDetails.ReturnID = returnIDFromReturnClass;

            try
            {
                isDeleted = await returnDetailsBL.DeleteReturnDetailsBL(returnDetails.ReturnDetailID,returnDetails.ProductID);
            }
            catch (Exception ex)
            {
                isDeleted = false;
                errorMessage = ex.Message;
            }
            finally
            {
                Assert.IsTrue(isDeleted, errorMessage);
            }

        }

        [TestMethod]
        public async Task InValidDeleteReturnDetailsBLTest()
        {
            ReturnDetailsBL returnDetailsBL = new ReturnDetailsBL();
            ReturnDetails returnDetails = new ReturnDetails() { ReturnID = default(Guid), ProductID = default(Guid), Quantity = 5, ReasonOfReturn = ReturnReasons.Incomplete, UnitPrice = 800, TotalPrice = 4000, AddressID = default(Guid) };
            bool isDeleted = false;
            string errorMessage = null;
            ReturnBL returnBL = new ReturnBL();
            bool returnAdded;
            Guid returnIDFromReturnClass;
            Return returnObj = new Return();
            (returnAdded, returnIDFromReturnClass) = await returnBL.AddReturnBL(returnObj);
            returnDetails.ReturnID = returnIDFromReturnClass;
            Guid Id = Guid.NewGuid();
            try
            {
                isDeleted = await returnDetailsBL.DeleteReturnDetailsBL(Id, returnDetails.ProductID);
            }
            catch (Exception ex)
            {
                isDeleted = true;
                errorMessage = ex.Message;
            }
            finally
            {
                Assert.IsTrue(isDeleted, errorMessage);
            }


        }

    }


}
