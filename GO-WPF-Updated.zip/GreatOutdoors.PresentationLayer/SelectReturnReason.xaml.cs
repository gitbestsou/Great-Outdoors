﻿using System;
using System.Windows;
using GreatOutdoors.Entities;
using Capgemini.GreatOutdoors.BusinessLayer;
using Capgemini.GreatOutdoors.Contracts.BLContracts;


namespace GreatOutdoors.PresentationLayer
{
    /// <summary>
    /// Interaction logic for SelectReturnReason.xaml
    /// </summary>
    public partial class SelectReturnReason : Window
    {
        Guid OrderID_toPass;

        public SelectReturnReason(Guid OrderID_toWork, Guid OrderDetailID_toWork)
        {
            InitializeComponent();
            OrderID_toPass = OrderID_toWork;
            Work(OrderDetailID_toWork);
        }

        OrderDetail ordtl = new OrderDetail();
        private async void Work(Guid OrderDetailID_toWork)
        {
            using (IOrderDetailsBL orderDetailAccess = new OrderDetailsBL())
            {
                ordtl = await orderDetailAccess.GetOrderDetailByOrderDetailIDBL(OrderDetailID_toWork);
            }

        }

        private async void ConfirmReturn(object sender, RoutedEventArgs e)
        {
            //ordtl.CurrentStatus = "Returned";

            if (ordtl.CurrentStatus == "Returned")
            {
                MessageBox.Show("Product already returned");

            }
            else if (ordtl.CurrentStatus == "Cancelled")
            {
                MessageBox.Show("Product already cancelled");
            }
            else
            {
                using (IOrderDetailsBL orderDetailsBL = new OrderDetailsBL())
                {
                    orderDetailsBL.UpdateOrderDetailForReturn(ordtl.OrderDetailID, "Returned");
                }
                MessageBox.Show("Order returned");

                Return returnObj = new Return();
                returnObj.ReturnID = Guid.NewGuid();
                returnObj.OrderID = OrderID_toPass;
                returnObj.ReturnDateTime = DateTime.Now;
                returnObj.LastModifiedDateTime = DateTime.Now;

                Order order = new Order();
                using (IOrdersBL ordersBL = new OrderBL())
                {
                    order = await ordersBL.GetOrderByOrderIDBL(OrderID_toPass);
                }
                returnObj.ChannelOfReturn = order.ChannelOfSale;
                returnObj.ReturnAmount = order.TotalAmount;

                ReturnDetail returnDetail = new ReturnDetail();
                returnDetail.ReturnDetailID = Guid.NewGuid();
                returnDetail.ReturnID = returnObj.ReturnID;
                returnDetail.ProductID = ordtl.ProductID;
                returnDetail.UnitPrice = ordtl.DiscountedUnitPrice;
                returnDetail.TotalPrice = ordtl.TotalPrice;
                returnDetail.Quantity = ordtl.Quantity;
                returnDetail.AddressID = ordtl.AddressID;

                if (rbWrong.IsChecked == true)
                {
                    returnDetail.ReasonOfReturn = "Wrong";
                }
                else
                {
                    returnDetail.ReasonOfReturn = "Incomplete";
                }
                using (IReturnBL returnBL = new ReturnBL())
                {
                    (bool isAdded, Guid Id) = await returnBL.AddReturnBL(returnObj);


                    using (IReturnDetailsBL returnDetailsBL = new ReturnDetailsBL())
                    {
                        bool isAdded1 = await returnDetailsBL.AddReturnDetailsBL(returnDetail);
                        if (isAdded == true)
                        {
                            feedBackBox.Text = returnDetail.ReasonOfReturn;
                        }
                    }
                }
            }

            Window nt = new ViewOrderDetails(OrderID_toPass);
            nt.Show();
            this.Close();
            //feedBackBox.Text = ordtl.CurrentStatus;
        }
    }
}