﻿using Capgemini.GreatOutdoors.BusinessLayer;
using GreatOutdoors.Entities;
using GreatOutdoors.PresentationLayer;
using System.Threading.Tasks;
using System.Windows;
using System.Linq;

namespace Capgemini.GreatOutdoors.PresentationLayer
{
    /// <summary>
    /// Interaction logic for UpdateAdmin.xaml
    /// </summary>
    public partial class UpdateAdmin : Window
    {
        public UpdateAdmin()
        {
            InitializeComponent();
            GetData();
        }

        private async void GetData()
        {
            Admin admin = new Admin();
            AdminBL adminBL = new AdminBL();
            admin = await adminBL.GetAdminByEmailAndPasswordBL(UserType.Email, UserType.Password);
            tbxAdminName.Text = UserType.Email;
            tbxEmail.Text = UserType.Email;
        }

        private async void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            Admin admin = new Admin();
            AdminBL adminBL = new AdminBL();
            admin = await adminBL.GetAdminByEmailAndPasswordBL(UserType.Email, UserType.Password);
            Task<bool> adminCheck;
            if (admin.Email == UserType.Email)
            {
                admin.AdminName = tbxAdminName.Text;
                admin.Email = tbxEmail.Text;
                adminCheck = adminBL.UpdateAdminBL(admin);

                if (adminCheck.Equals(true))
                {
                    UserType.Email = admin.Email;
                    UserType.Password = admin.Password;
                    MessageBox.Show("Updated Succusfully!!");

                    Window window = new AdminHome();
                    window.Show();
                    this.Close();
                }

                if (adminCheck.Equals(false))
                {
                    MessageBox.Show("Details not updated");

                    Window window = new AdminHome();
                    window.Show();
                    this.Close();
                }
            }
        }
    }
}
