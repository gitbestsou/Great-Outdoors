﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using Capgemini.GreatOutdoors.BusinessLayer;
using GreatOutdoors.Entities;
using GreatOutdoors.PresentationLayer;

namespace Capgemini.GreatOutdoors.PresentationLayer
{
    /// <summary>
    /// Interaction logic for ViewSalesHistory.xaml
    /// </summary>
    public partial class ViewSalesHistory : Window
    {
        OrderBL orderBL = new OrderBL();
        List<Order> orders = new List<Order>();
        public static Order selectedOrder = new Order();
        public ViewSalesHistory()
        {
            InitializeComponent();
        }

        private async void Window_Loaded(object sender, RoutedEventArgs e)
        {
            orders = await orderBL.GetOrderBySalesPersonIDBL(SalesPersonHome.currentSalesPerson.SalespersonID);
            dgSalesHistory.ItemsSource = orders;
            dgSalesHistory.Columns[0].MaxWidth = 0;
            dgSalesHistory.Columns[1].MaxWidth = 0;
        }


        private string getCellData(DataGrid dgv, int rowindex, int cellindex)
        {
            DataGridRow drow =
                            dgv.ItemContainerGenerator.ContainerFromIndex(rowindex) as DataGridRow;

            var cellContent = dgv.Columns[cellindex].GetCellContent(drow) as TextBlock;

            return cellContent.Text;

        }

        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            Window window = new SalesPersonHome();
            window.Show();
            this.Close();
        }

        private void DgSalesHistory_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int rowindex = dgSalesHistory.SelectedIndex;
            if (rowindex < 0)
            {
                return;
            }

            selectedOrder.OrderID = Guid.Parse(getCellData(dgSalesHistory, rowindex, 0));
            selectedOrder.RetailerID = Guid.Parse(getCellData(dgSalesHistory, rowindex, 1));
            selectedOrder.SalespersonID = SalesPersonHome.currentSalesPerson.SalespersonID;
           

        }

        private void BtnViewDetails_Click_1(object sender, RoutedEventArgs e)
        {
            Window window = new ViewOrderDetails(selectedOrder.OrderID);
            window.Show();
            this.Close();
        }

        private void BtnHistory_Click(object sender, RoutedEventArgs e)
        {
            Window window = new ViewSalesHistory();
            window.Show();
            this.Close();
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            Window window = new SalesPersonHome();
            window.Show();
            this.Close();
        }

        private void MenuItem_Click_Logout(object sender, RoutedEventArgs e)
        {
            MainWindow login = new MainWindow();
            login.Show();
            this.Close();
        }
    }
}