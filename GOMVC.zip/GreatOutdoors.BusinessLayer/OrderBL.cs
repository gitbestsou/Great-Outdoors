﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Capgemini.GreatOutdoors.Exceptions;
using Capgemini.GreatOutdoors.Contracts.BLContracts;
using GreatOutdoors.Entities;
using Capgemini.GreatOutdoors.DataAccessLayer;

namespace Capgemini.GreatOutdoors.BusinessLayer
{
    /// <summary>
    /// Contains data access layer methods for inserting, updating, deleting admins from Admins collection.
    /// </summary>
    public class OrderBL : BLBase<Order>, IOrdersBL, IDisposable
    {
        //fields
        OrderDAL orderDAL;

        /// <summary>
        /// Constructor
        /// </summary>

        public OrderBL()
        {
            this.orderDAL = new OrderDAL();
        }

        /// <summary>
        /// Validations on data before adding or updating.
        /// </summary>
        /// <param name="entityObject">Represents object to be validated.</param>
        /// <returns>Returns a boolean value, that indicates whether the data is valid or not.</returns>
        protected async override Task<bool> Validate(Order entityObject)
        {
            //Create string builder
            StringBuilder sb = new StringBuilder();
            bool valid = await base.Validate(entityObject);

            //OrderID is Unique
            var existingObject = await GetOrderByOrderIDBL(entityObject.OrderID);
            if (existingObject != null && existingObject?.OrderID != entityObject.OrderID)
            {
                valid = false;
                sb.Append(Environment.NewLine + $"Order {entityObject.OrderID} already exists");
            }

            if (valid == false)
                throw new GreatOutdoorsException(sb.ToString());
            return valid;
        }


        /// <summary>
        /// Adds order to orderlist.
        /// </summary>
        /// <param name="newOrder">Represents order to be added.</param>
        /// <returns>Returns a boolean value, that indicates whether the data is valid or not and OrderID</returns>
        public async Task<(bool, Guid)> AddOrderBL(Order newOrder)
        {
            bool orderAdded = false;
            Guid orderID = default(Guid);
            try
            {

                await Task.Run(() =>
                {

                    (orderAdded, orderID) = orderDAL.AddOrderDAL(newOrder);
                    orderAdded = true;
                });


            }
            catch (GreatOutdoorsException ex)
            {
                throw;
            }
            return (orderAdded, orderID);
        }

        /// <summary>
        /// Get all the orders in orders list
        /// </summary>
        /// <returns>Returns a list of all orders</returns>
        public async Task<List<Order>> GetAllOrdersBL()
        {
            List<Order> orderList = null;
            try
            {
                await Task.Run(() =>
                {
                    orderList = orderDAL.GetAllOrdersDAL();
                });
            }
            catch (GreatOutdoorsException ex)
            {
                throw ex;
            }

            return orderList;
        }

        /// <summary>
        /// Returns an order based on given order ID.
        /// </summary>
        /// <param name="searchOrderID">Represents order ID to be searched.</param>
        /// <returns>Returns order found.</returns>

        public async Task<Order> GetOrderByOrderIDBL(Guid searchOrderID)
        {
            Order searchOrder = null;
            List<Order> searchOrderList = null;
            try
            {
                await Task.Run(() =>
                {
                    searchOrderList = orderDAL.GetOrderByOrderIDDAL(searchOrderID);
                });
                searchOrder = searchOrderList[0];
            }
            catch (GreatOutdoorsException ex)
            {
                throw ex;
            }

            return searchOrder;

        }


        /// <summary>
        /// Returns orders of a retailer based on given retailer ID.
        /// </summary>
        /// <param name="retailerID">Represents order ID to be searched.</param>
        /// <returns>Returns order found.</returns>

        public async Task<List<Order>> GetOrderByRetailerIDBL(Guid retailerID)
        {
            List<Order> searchOrder = null;
            try
            {
                await Task.Run(() => searchOrder = orderDAL.GetOrderByRetailerIDDAL(retailerID));

            }
            catch (GreatOutdoorsException ex)
            {
                throw ex;
            }

            return searchOrder;

        }


        /// <summary>
        /// Returns orders of a salesperson based on given salesperson ID.
        /// </summary>
        /// <param name="salesPersonID">Represents order ID to be searched.</param>
        /// <returns>Returns order found.</returns>
        public async Task<List<Order>> GetOrderBySalesPersonIDBL(Guid salesPersonID)
        {
            List<Order> searchOrder = null;
            try
            {
                await Task.Run(() => searchOrder = orderDAL.GetOrderBySalesPersonIDDAL(salesPersonID));


            }
            catch (GreatOutdoorsException ex)
            {
                throw ex;
            }

            return searchOrder;

        }


        /// <summary>
        /// Returns orders for offline sale through.
        /// </summary>
        /// <returns>Returns orders found.</returns>
        //public async Task<List<Order>> GetOrderForOfflineSaleBL()
        //{
        //    List<Order> searchOrder = null;
        //    try
        //    {
        //        await Task.Run(() =>
        //        {
        //            searchOrder = orderDAL.GetOrderOfflineSaleDAL();
        //        });
        //    }
        //    catch (GreatOutdoorsException ex)
        //    {
        //        throw ex;
        //    }

        //    return searchOrder;

        //}

        /// <summary>
        /// Returns orders placed online.
        /// </summary>
        /// <returns>Returns orders found.</returns>
        public async Task<List<Order>> GetOrderOnlineBL()
        {
            List<Order> searchOrder = null;
            try
            {
                await Task.Run(() =>
                {
                    searchOrder = orderDAL.GetOrderOnlineDAL();
                });

            }
            catch (GreatOutdoorsException ex)
            {
                throw ex;
            }

            return searchOrder;

        }

        /// <summary>
        /// Returns orders of a retailer based on required status.
        /// </summary>
        /// <param name="currentStatus">Represents order ID to be searched.</param>
        /// <returns>Returns orders found.</returns>
        //public async Task<List<Order>> GetOrderByStatusBL(Status currentStatus)
        //{
        //    List<Order> searchOrder = null;
        //    try
        //    {
        //        await Task.Run(() =>
        //        {
        //            searchOrder = orderDAL.GetOrderByStatusDAL(currentStatus);
        //        });
        //    }
        //    catch (GreatOutdoorsException ex)
        //    {
        //        throw ex;
        //    }

        //    return searchOrder;

        //}

        /// <summary>
        /// Updates order
        /// </summary>
        /// <param name="updateOrder">Represents order ID to be searched.</param>
        /// <returns>Returns boolean which represents if order is updated.</returns>
        public async Task<bool> UpdateOrderBL(Order updateOrder)
        {
            bool orderUpdated = false;
            try
            {
                if ((await Validate(updateOrder)) && (await GetOrderByOrderIDBL(updateOrder.OrderID)) != null)
                {
                    this.orderDAL.UpdateOrderDAL(updateOrder);
                    orderUpdated = true;
                   
                }

            }
            catch (GreatOutdoorsException ex)
            {
                throw ex;
            }


            return orderUpdated;
        }


        /// <summary>
        ///Updates order status.
        /// </summary>
        /// <param name="updateOrder">Represents order who's status is to be updated.</param>
        /// <returns>Returns order found.</returns>
        public async Task<bool> UpdateOrderStatusBL(Order updateOrder)
        {
            bool statusUpdated = false;
            try
            {
                if ((await Validate(updateOrder)) && (await GetOrderByOrderIDBL(updateOrder.OrderID)) != null)
                {
                    this.orderDAL.UpdateOrderDAL(updateOrder);
                    statusUpdated = true;
                   
                }

            }
            catch (GreatOutdoorsException ex)
            {
                throw ex;
            }


            return statusUpdated;
        }

        public async Task<bool> DeleteOrderByOrderID(Guid orderID)
        {

            bool orderDeleted = false;
            try
            {
                await Task.Run(() =>
                {
                    orderDeleted = orderDAL.DeleteOrderByOrderIDDAL(orderID);
                });
            }
            catch (GreatOutdoorsException)
            {
                throw;
            }
            return orderDeleted;
        }
        /// <summary>
        /// Disposes DAL object(s).
        /// </summary>
        public void Dispose()
        {
            orderDAL.Dispose();
        }

    }
}
