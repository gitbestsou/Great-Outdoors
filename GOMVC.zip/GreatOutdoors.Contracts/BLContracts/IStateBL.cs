﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capgemini.GreatOutdoors.Contracts.BLContracts
{
    public interface IStateBL
    {
        Task<bool> AddStateBL(String newState);
        Task<List<String>> GetAllStateBL();
        Task<bool> DeleteStateBL(string deleteState);
    }
}
