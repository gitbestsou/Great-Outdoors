﻿using System;
using System.Collections.Generic;
using System.IO;
using GreatOutdoors.Entities;

using Newtonsoft.Json;

namespace Capgemini.GreatOutdoors.Contracts.DALContracts
{
    /// <summary>
    /// This abstract class acts as a base for ProductDAL class
    /// </summary>
    public abstract class ProductDALBase
    {
        //Collection of Products
        protected static List<Product> productList = new List<Product>(){};
        private static string fileName = "products.json";

        //Methods for CRUD operations
        public abstract bool AddProductDAL(Product newProduct);
        public abstract List<Product> GetAllProductsDAL();
        public abstract Product GetProductByProductIDDAL(Guid searchProductID);
        public abstract List<Product> GetProductsByNameDAL(string ProductName);
        public abstract List<Product> GetProductsByCategoryDAL(string categoryName);
        public abstract bool UpdateProductDAL(Product updateProduct);
        public abstract bool UpdateProductStockDAL(Product updateProduct);
        public abstract bool DeleteProductDAL(Guid deleteProductID);






        
    }
}


