﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GreatOutdoors.MVC.Models
{
    public class AdminViewModel
    {
        public Guid AdminID { get; set; }
        public string AdminName { get; set; }
        public string Email { get; set; }
    }
}