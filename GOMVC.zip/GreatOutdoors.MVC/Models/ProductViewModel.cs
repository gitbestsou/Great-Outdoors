﻿using System;
using System.Web;
using System.ComponentModel.DataAnnotations;


/*Products ViewModel which contains properties of Products like - Name, category,size,colour etc.
Project name : Great Outdoors
Developer name: Madhuri Vemulapaty
Use case : Products
Creation date : 25/10/2019
Last modified : 29/10/2019
 */
namespace GreatOutdoors.MVC.Models
{
    public class ProductViewModel
    {
        public Guid ProductID { get; set; }


        [Required(ErrorMessage = "Name can't be blank")]
        [RegularExpression("^[A-Za-z ]*$", ErrorMessage = "Name should contain only alphabets")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Category should be selected")]
        public string Category { get; set; }

        [RegularExpression("^[0-9]*$", ErrorMessage = "Please enter only integers")]
        public Nullable<int> Stock { get; set; }


        public string Size { get; set; }
        [Required(ErrorMessage = "Colour can't be blank")]
        public string Colour { get; set; }

        [Display(Name = "Specifications")]
        [Required(ErrorMessage = "Technical specifications can't be blank")]
        public string TechnicalSpecifications { get; set; }
        [Display(Name = "Cost Price")]
        [RegularExpression("^[0-9.]*$", ErrorMessage = "Please enter only decimal values")]
        public Nullable<decimal> CostPrice { get; set; }
        [Display(Name = "Selling Price")]
        [RegularExpression("^[0-9.]*$", ErrorMessage = "Please enter only decimal values")]
        public Nullable<decimal> SellingPrice { get; set; }
        [Display(Name = "Discount")]
        [RegularExpression("^[0-9.]*$", ErrorMessage = "Please enter only decimal values")]
        public Nullable<decimal> DiscountPercentage { get; set; }

    }
}