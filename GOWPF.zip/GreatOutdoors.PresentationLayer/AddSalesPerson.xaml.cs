﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Capgemini.GreatOutdoors.BusinessLayer;
using GreatOutdoors.Entities;

namespace Capgemini.GreatOutdoors.PresentationLayer
{
    /// <summary>
    /// Interaction logic for AddSalesPerson.xaml
    /// </summary>
    public partial class AddSalesPerson : Window
    {
        SalesPersonBL salesPersonBL = new SalesPersonBL();
        public AddSalesPerson()
        {
            InitializeComponent();
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            Window window = new SalesPersons();
            window.Show();
            this.Close();
        }

        private async void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            SalesPerson salesPerson = new SalesPerson();

            salesPerson.Name = txtName.Text;
            salesPerson.Mobile = txtMobile.Text;
            salesPerson.Email = txtEmail.Text;
            salesPerson.Password = txtPassword.Text;
            salesPerson.Pincode = txtPincode.Text;
            salesPerson.Salary = Convert.ToDecimal(txtSalary.Text);
            salesPerson.Target = Convert.ToDecimal(txtTarget.Text);
            salesPerson.Bonus = Convert.ToDecimal(txtBonus.Text);
            salesPerson.City = txtCity.Text;
            salesPerson.State = txtState.Text;
            salesPerson.AddressLine1 = txtAddressL1.Text;
            salesPerson.AddressLine2 = txtAddressL2.Text;
            salesPerson.Birthdate = Convert.ToDateTime(txtBirthDate.Text);
            salesPerson.JoiningDate = Convert.ToDateTime(txtJoiningDate.Text);

            bool isAdded = await salesPersonBL.AddSalesPersonBL(salesPerson);

            if (isAdded)
                MessageBox.Show("Sales person added successfully!");

            Window window = new SalesPersons();
            window.Show();
            this.Close();


        }
    }
}