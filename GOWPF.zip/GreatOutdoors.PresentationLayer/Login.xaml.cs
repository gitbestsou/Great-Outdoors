﻿using GreatOutdoors.Entities;
using Capgemini.GreatOutdoors.BusinessLayer;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using GreatOutdoors.PresentationLayer;

namespace Capgemini.GreatOutdoors.PresentationLayer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private async void Login_Click(object sender, RoutedEventArgs e)
        {
            
            ComboBoxItem typeItem = (ComboBoxItem)cbxUser.SelectedItem;
            string value = typeItem.Content.ToString();
            if (value == "Admin")
            {
                AdminBL adminBL = new AdminBL();
                Admin admin = new Admin();
                admin= await adminBL.GetAdminByEmailAndPasswordBL(tbxEmail.Text, tbxPassword.Text);
                
                if (admin != null)
                {
                    UserType.Email = admin.Email;
                    UserType.Password = admin.Password;
                    Window window = new AdminHome();
                    window.Show();
                    this.Close();
                }

                if (admin == null)
                {
                    MessageBox.Show("Invalid Email and Password");
                    this.Show();
                }
            }

            if (value == "Sales Person")
            {
                SalesPersonBL salesPersonBL = new SalesPersonBL();
                SalesPerson salesPerson = await salesPersonBL.GetSalesPersonByEmailAndPasswordBL(tbxEmail.Text, tbxPassword.Text);

                if (salesPerson != null)
                {
                    UserType.Email = salesPerson.Email;
                    UserType.Password = salesPerson.Password;
                    Window window = new SalesPersonHome();
                    window.Show();
                    this.Close();
                }

                if (salesPerson == null)
                {
                    MessageBox.Show("Invalid Email and Password");
                    this.Show();
                }
            }

            if (value == "Retailer")
            {
                Retailer retailer = new Retailer();
                RetailerBL retailerBL = new RetailerBL();
                retailer = await retailerBL.GetRetailerByEmailAndPasswordBL(tbxEmail.Text, tbxPassword.Text);

                if (retailer != null)
                {
                    UserType.Email = retailer.Email;
                    UserType.Password = retailer.RetailerPassword;
                    Window window = new RetailerHome();
                    window.Show();
                    this.Close();
                }

                if (retailer == null)
                {
                    MessageBox.Show("Invalid Email and Password");
                    this.Show();
                }
            }

        }

        private void Register_Click(object sender, RoutedEventArgs e)
        {
            Window window = new Registration();
            window.Show();
            this.Close();
        }
    }
}
