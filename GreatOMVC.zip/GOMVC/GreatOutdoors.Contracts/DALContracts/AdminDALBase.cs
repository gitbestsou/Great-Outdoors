﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GreatOutdoors.Entities;
using Newtonsoft.Json;

namespace Capgemini.GreatOutdoors.Contracts.DALContracts
{
    /// <summary>
    /// This abstract class acts as a base for AdminDAL class
    /// </summary>
    public abstract class AdminDALBase
    {

        //Collection of Admins
        protected static List<Admin> adminList = new List<Admin>()
        {
            new Admin() { AdminID = Guid.NewGuid(), Email = "admin@capgemini.com", AdminName = "Admin", Password = "manager", CreationDateTime = DateTime.Now, LastModifiedDateTime = DateTime.Now }
        };
        private static string fileName = "admins.json";

        //Methods
        public abstract (Guid,bool) AddAdminDAL(Admin addAdmin);
        public abstract Admin GetAdminByAdminIDDAL(Guid searchAdminID);
        public abstract Admin GetAdminByEmailAndPasswordDAL(string email, string password);
        public abstract (Guid,bool) UpdateAdminDAL(Admin updateAdmin);
        public abstract (Guid,bool) UpdateAdminPasswordDAL(Admin updateAdmin);

        
    }
}
