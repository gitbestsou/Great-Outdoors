﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GreatOutdoors.Entities;
using Newtonsoft.Json;

namespace Capgemini.GreatOutdoors.Contracts.DALContracts
{
    public abstract class ReturnDALBase
    {
        protected static List<Return> returnList = new List<Return>();
        private static string fileName = "return.json";

        public abstract (bool, Guid) AddReturnDAL(Return newReturn);
        public abstract List<Return> GetAllReturnsDAL();
        public abstract Return GetReturnByReturnIDDAL(Guid searchReturnID);
        public abstract List<Return> GetReturnByOrderIDDAL(Guid OrderID);
        /*public abstract List<Return> GetReturnByRetailerIDDAL(Guid RetailerID);*/
        public abstract bool UpdateReturnDAL(Return updateReturn);
        public abstract bool DeleteReturnDAL(Guid deleteReturnID);

    }
}