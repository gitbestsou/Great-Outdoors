﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Web.Mvc;
using Capgemini.GreatOutdoors.BusinessLayer;
using GreatOutdoors.Entities;
using GreatOutdoors.MVC.Models;

/*Address Controller which contains methods to perform Create, Edit, Delete and Display Address
Project name : Great Outdoors
Developer name: Shreyash Pandey
Use case : Address
Creation date : 25/10/2019
Last modified : 29/10/2019
 */

namespace GreatOutdoors.MVC.Controllers
{
    public class AddressController : Controller
    {
        // URL:Address/Create
        /// <summary>
        /// Method to display and take the values of Add New Product form
        /// </summary>
        /// <returns> Returns view of add product form</returns>
        public ActionResult Create()
        {
            //Creating ViewModel object
            AddressViewModel addressViewModel = new AddressViewModel();

            //Calling View and passing ViewModel object to view
            return View(addressViewModel);
        }

        /// <summary>
        /// Method to Add new address to database
        /// </summary>
        /// <param name="addressViewModel"></param>
        /// <returns>returns view of index of address if product is added successfully or displays error message</returns>
        [HttpPost]
        public async Task<ActionResult> Create(AddressViewModel addressViewModel)
        {
            bool isAdded = false;
            Address address = new Address();
            //Copying the values of the form to address entity
            address.AddressID = addressViewModel.AddressID;
            address.RetailerID = addressViewModel.RetailerID;
            address.Line1 = addressViewModel.Line1;
            address.Line2 = addressViewModel.Line2;
            address.Pincode = addressViewModel.Pincode;
            address.City = addressViewModel.City;
            address.State = addressViewModel.State;
            address.MobileNo = addressViewModel.MobileNo;

            AddressBL addressBL = new AddressBL();
            //Adding the new address to the Database
            isAdded = await addressBL.AddAddressBL(address);

            if (isAdded)
                //Redirecting to Index of Address if addition is successful
                return RedirectToAction("Index", "Address");
            else
                //Displaying error message if addition is unsuccessful
                return Content("Address couldn't be added");

        }


        // URL:Address/Edit
        /// <summary>
        /// Method to display the edit form of selected address
        /// </summary>
        /// <param name="id">Id of the selected address</param>
        /// <returns>Returns the view of edit form</returns>
        public async Task<ActionResult> Edit(Guid id)
        {
            //Creating ViewModel object
            AddressViewModel addressViewModel = new AddressViewModel();

            AddressBL addressBL = new AddressBL();
            //Retrieving the selected address and itś details by ID
            Address address = await addressBL.GetAddressByAddressIDBL(id);

            //Displaying the existing details 
            addressViewModel.AddressID = id;
            addressViewModel.Line1 = address.Line1;
            addressViewModel.Line2 = address.Line2;
            addressViewModel.Line2 = address.Line2;
            addressViewModel.Pincode = address.Pincode;
            addressViewModel.City = address.City;
            addressViewModel.State = address.State;
            addressViewModel.MobileNo = address.MobileNo;

            //Calling View and passing ViewModel object to view
            return View(addressViewModel);
        }

        /// <summary>
        /// Method to post the edit form data and store the updated details in the database
        /// </summary>
        /// <param name="addressViewModel"></param>
        /// <returns>Returns index view of address if edit is successful or displays error message</returns>

        [HttpPost]
        public async Task<ActionResult> Edit(AddressViewModel addressViewModel)
        {

            AddressBL addressBL = new AddressBL();
            Address address = await addressBL.GetAddressByAddressIDBL(addressViewModel.AddressID);
           
            //Updating the product details from the edit form
            address.Line1 = addressViewModel.Line1;
            address.Line2 = addressViewModel.Line2;
            address.Pincode = addressViewModel.Pincode;
            address.City = addressViewModel.City;
            address.State = addressViewModel.State;
            address.MobileNo = addressViewModel.MobileNo;

            //Calling methods to update details in the database
            bool isupdated = await addressBL.UpdateAddressBL(address);

            if (isupdated)
                //Redirecting to Index of Address if updation is successful
                return RedirectToAction("Index");
            else
                //Displaying error message if updation is unsuccessful
                return Content("Address couldn't be updated");

        }

        /// <summary>
        /// Method to display the list of addresses in the database
        /// </summary>
        /// <returns>Returns the view of addresses in the database</returns>
        // URL:Address/Index
        public async Task<ActionResult> Index()
        {
            //Creating ViewModel object
            List<AddressViewModel> addressViewModels = new List<AddressViewModel>();

            List<Address> addresses = new List<Address>();
            AddressBL addressBL = new AddressBL();

            Guid retailerID = (Guid)Session["ReatilerID"];

            //Getting all the addresses from the database
            addresses = await addressBL.GetAddressByRetailerIDBL(retailerID);

            foreach (var address in addresses)
            {
                //Copying details of each address to addressViewModel
                AddressViewModel addressViewModel = new AddressViewModel()
                {
                    AddressID = address.AddressID,
                    Line1 = address.Line1,
                    Line2 = address.Line2,
                    Pincode = address.Pincode,
                    City = address.City,
                    State = address.State,
                    MobileNo = address.MobileNo                                        
                };

                //Adding the addressViewModel to the list
                addressViewModels.Add(addressViewModel);
            }


            //Calling View and passing ViewModel object to view
            return View(addressViewModels);
        }

        /// <summary>
        /// Method to delete the selected address from database
        /// </summary>
        /// <param name="id">Id of the selected address</param>
        /// <returns>Returns index view of address if deletion is successful or displays error message</returns>
        public async Task<ActionResult> Delete(Guid id)
        {
            AddressBL addressBL = new AddressBL();
            //Deleting the address from the database using the given ID
            bool isDeleted = await addressBL.DeleteAddressBL(id);

            if (isDeleted)
                //Redirecting to Index of Address if deletion is successful
                return RedirectToAction("Index");
            else
                //Displaying error message if deletion is unsuccessful
                return Content("Address couldn't be deleted");
        }
    }
}