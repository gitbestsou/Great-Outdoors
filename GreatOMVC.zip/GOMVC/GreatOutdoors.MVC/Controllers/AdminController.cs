﻿using GreatOutdoors.Entities;
using Capgemini.GreatOutdoors.BusinessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Threading.Tasks;
using GreatOutdoors.MVC.Models;

namespace GreatOutdoors.MVC.Controllers
{
    public class AdminController : Controller
    {
        // GET: Admin
        public async Task<ActionResult> Home()
        {
            Admin admin = new Admin();
            AdminBL adminBL = new AdminBL();
            AdminViewModel adminViewModel = new AdminViewModel();

            admin.AdminID = Guid.Parse(Convert.ToString(Session["AdminID"]));

            admin = await adminBL.GetAdminByAdminIDBL(admin.AdminID);
            adminViewModel.AdminID = admin.AdminID;
            adminViewModel.AdminName = admin.AdminName;
            adminViewModel.Email = admin.Email;

            return View(adminViewModel);
        }

        public async Task<ActionResult> Edit()
        {
            Admin admin = new Admin();
            AdminBL adminBL = new AdminBL();
            AdminViewModel adminViewModel = new AdminViewModel();
            admin.AdminID = (Guid)Session["AdminID"];
            admin = await adminBL.GetAdminByAdminIDBL(admin.AdminID);
            adminViewModel.AdminID = admin.AdminID;
            adminViewModel.AdminName = admin.AdminName;
            adminViewModel.Email = admin.Email;

            return View(adminViewModel);
        }

        [HttpPost]
        public async Task<ActionResult> Edit(AdminViewModel adminViewModel)
        {
            Admin admin = new Admin();
            AdminBL adminBL = new AdminBL();
            admin = await adminBL.GetAdminByAdminIDBL(adminViewModel.AdminID);

            admin.AdminName = adminViewModel.AdminName;
            admin.Email = adminViewModel.Email;

            bool isupdate = await adminBL.UpdateAdminBL(admin);

            if (isupdate)
            {
                return RedirectToAction("Home");
            }
            else
                return Content("Admin can't be updated");
        }
    }
}