﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Capgemini.GreatOutdoors.Exceptions;
using System.Reflection;
using System.Text.RegularExpressions;
using Capgemini.GreatOutdoors.Contracts.BLContracts;
using Capgemini.GreatOutdoors.Contracts.DALContracts;
using Capgemini.GreatOutdoors.Helpers.ValidationAttributes;
using Capgemini.GreatOutdoors.BusinessLayer;
using Capgemini.GreatOutdoors.Entities;
using Capgemini.GreatOutdoors.DataAccessLayer;

namespace Capgemini.GreatOutdoors.BusinessLayer
{
    /// <summary>
    /// Contains data access layer methods for inserting, updating, deleting admins from Admins collection.
    /// </summary>
    public class OrderBL : BLBase<Order>, IOrdersBL, IDisposable
    {
        //fields
        OrderDAL orderDAL;

        /// <summary>
        /// Constructor
        /// </summary>
        
        public OrderBL()
        {
            this.orderDAL = new OrderDAL();
        }

        /// <summary>
        /// Validations on data before adding or updating.
        /// </summary>
        /// <param name="entityObject">Represents object to be validated.</param>
        /// <returns>Returns a boolean value, that indicates whether the data is valid or not.</returns>
        protected  async override Task<bool> Validate(Order entityObject)
        {
            //Create string builder
            StringBuilder sb = new StringBuilder();
            bool valid = await base.Validate(entityObject);

            //OrderID is Unique
            var existingObject = await GetOrderByOrderIDBL(entityObject.OrderID);
            if (existingObject != null && existingObject?.OrderID != entityObject.OrderID)
            {
                valid = false;
                sb.Append(Environment.NewLine + $"Order {entityObject.OrderID} already exists");
            }

            if (valid == false)
                throw new Exception(sb.ToString());
            return valid;
        }


     
        public async Task<bool> AddOrderBL(Order newOrder)
        {
            bool orderAdded = false;
            try
            {
                if (await Validate(newOrder))
                {
                    await Task.Run(() =>
                    {

                        orderDAL.AddOrderDAL(newOrder);
                        orderAdded = true;
                    });
                   
                }
            }
            catch (Exception ex)
            {
                throw;
            }
           return orderAdded;
        }

        public async Task<List<Order>> GetAllOrdersBL()
        {
            List<Order> orderList = null;
            try
            {
                await Task.Run(() =>
                {
                    orderList = orderDAL.GetAllOrdersDAL();
                });
            }
            catch (Exception ex)
            {
                throw ex;
            }
            
            return orderList;
        }

        public async  Task<Order> GetOrderByOrderIDBL(Guid searchOrderID)
        {
            Order searchOrder = null;
            try
            {
                await Task.Run(() =>
                {
                    searchOrder = orderDAL.GetOrderByOrderIDDAL(searchOrderID);
                });
               
            }
            catch (Exception ex)
            {
                throw ex;
            }
            
            return searchOrder;

        }

        public async  Task<List<Order>> GetOrderByRetailerIDBL(Guid retailerID)
        {
            List<Order> searchOrder = null;
            try
            {
                await Task.Run(() =>
                {
                    searchOrder = orderDAL.GetOrderByRetailerIDDAL(retailerID);
                });
            }
            catch (Exception ex)
            {
                throw ex;
            }
            
            return searchOrder;

        }

        public async Task<List<Order>> GetOrderByCategoryBL(Category categoryName)
        {
            List<Order> searchOrder = null;
            try
            {
                await Task.Run(() =>
                {
                    searchOrder = orderDAL.GetOrderByCategoryDAL(categoryName);
                });
            }
            catch (Exception ex)
            {
                throw ex;
            }
            
            return searchOrder;

        }

        public async Task<List<Order>> GetOrderBySalesPersonIDBL(Guid salesPersonID) 
        {
            List<Order> searchOrder = null;
            try
            {
                await Task.Run(() =>
                {
                    searchOrder = orderDAL.GetOrderBySalesPersonIDDAL(salesPersonID);
                });
            }
            catch (Exception ex)
            {
                throw ex;
            }
            
            return searchOrder;

        }

       
        public async Task<List<Order>> GetOrderForOfflineSaleBL()
        {
            List<Order> searchOrder = null;
            try
            {
                await Task.Run(() =>
                {
                    searchOrder = orderDAL.GetOrderForOfflineSaleDAL();
                });  
            }
            catch (Exception ex)
            {
                throw ex;
            }
           
            return searchOrder;

        }

        public async Task<List<Order>> GetOrderOnlineBL()
        {
            List<Order> searchOrder = null;
            try
            {
                await Task.Run(() =>
                {
                    searchOrder = orderDAL.GetOrderOnlineDAL();
                });
                
            }
            catch (Exception ex)
            {
                throw ex;
            }
            
            return searchOrder;

        }

        public async Task<List<Order>> GetOrderByStatusBL(Status currentStatus)
        {
            List<Order> searchOrder = null;
            try
            {
                await Task.Run(() =>
                {
                    searchOrder = orderDAL.GetOrderByStatusDAL(currentStatus);
                }); 
            }
            catch (Exception ex)
            {
                throw ex;
            }
            
            return searchOrder;

        }


        public async Task<bool> UpdateOrderBL(Order updateOrder)
        {
            bool orderUpdated = false;
            try
            {
                if ((await Validate(updateOrder)) && (await GetOrderByOrderIDBL(updateOrder.OrderID)) != null)
                {
                    this.orderDAL.UpdateOrderDAL(updateOrder);
                    orderUpdated = true;
                    Serialize();
                }
                
            }
            catch (Exception ex)
            {
                throw;
            }
            

            return orderUpdated;
        }

        public async Task<bool> UpdateOrderStatusBL(Order updateOrder)
        {
            bool statusUpdated = false;
            try
            {
                if ((await Validate(updateOrder)) && (await GetOrderByOrderIDBL(updateOrder.OrderID)) != null)
                {
                    this.orderDAL.UpdateOrderDAL(updateOrder);
                    statusUpdated = true;
                    Serialize();
                }

            }
            catch (Exception ex)
            {
                throw;
            }


            return statusUpdated;
        }

        /// <summary>
        /// Disposes DAL object(s).
        /// </summary>
        public void Dispose()
        {
            ((OrderDAL)orderDAL).Dispose();
        }

        /// <summary>
        /// Invokes Serialize method of DAL.
        /// </summary>
        public static void Serialize()
        {
            try
            {
                OrderDAL.Serialize();
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        ///Invokes Deserialize method of DAL.
        /// </summary>
        public static void Deserialize()
        {
            try
            {
                OrderDAL.Deserialize();
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}