﻿using Capgemini.GreatOutdoors.Entities;
using Capgemini.GreatOutdoors.BusinessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Capgemini.GreatOutdoors.Contracts.BLContracts;
using Capgemini.GreatOutdoors.Contracts.DALContracts;
using Capgemini.GreatOutdoors.DAL;

namespace Capgemini.GreatOutdoors.BusinessLayer
{
    /// <summary>
    /// Contains data access layer methods for inserting, updating, deleting OrderDetailss from OrderDetailss collection.
    /// </summary>
    public class OrderDetailsBL : BLBase<OrderDetails>, IOrderDetailsBL, IDisposable
    {
        //fields
        OrderDetailsDALBase OrderDetailsDAL;

        /// <summary>
        /// Constructor.
        /// </summary>
        public OrderDetailsBL()
        {
            this.OrderDetailsDAL = new OrderDetailsDAL();
        }

        

        /// <summary>
        /// Adds new OrderDetails to OrderDetailss collection.
        /// </summary>
        /// <param name="newOrderDetails">Contains the OrderDetails details to be added.</param>
        /// <returns>Determinates whether the new OrderDetails is added.</returns>
        public async Task<bool> AddOrderDetailsBL(OrderDetails newOrderDetails)
        {
            bool OrderDetailsAdded = false;
            try
            {
                if (await Validate(newOrderDetails))
                {
                    await Task.Run(() =>
                    {
                        this.OrderDetailsDAL.AddOrderDetailsDAL(newOrderDetails);
                        OrderDetailsAdded = true;
                    });
                }
            }
            catch (Exception)
            {
                throw;
            }
            return OrderDetailsAdded;
        }

        

        /// <summary>
        /// Gets OrderDetails based on OrderID.
        /// </summary>
        /// <param name="searchOrderID">Represents OrderID to search.</param>
        /// <returns>Returns OrderID object.</returns>
        public async Task<List<OrderDetails>> GetOrderDetailsByOrderIDBL(Guid searchOrderID)
        {
            List<OrderDetails> matchingOrderDetails = null;
            try
            {
                await Task.Run(() =>
                {
                    matchingOrderDetails = OrderDetailsDAL.GetOrderDetailsByOrderIDDAL(searchOrderID);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return matchingOrderDetails;
        }

        /// <summary>
        /// Gets OrderDetails based on OrderDetailsName.
        /// </summary>
        /// <param name="searchProductID">Represents OrderDetailsName to search.</param>
        /// <returns>Returns OrderDetails object.</returns>
        public async Task<List<OrderDetails>> GetOrderDetailsByProductIDBL(Guid searchProductID)
        {
            List<OrderDetails> matchingOrderDetailss = new List<OrderDetails>();
            try
            {
                await Task.Run(() =>
                {
                    matchingOrderDetailss = OrderDetailsDAL.GetOrderDetailsByProductIDDAL(searchProductID);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return matchingOrderDetailss;
        }


        /// <summary>
        /// Deletes OrderDetails based on OrderDetailsID.
        /// </summary>
        /// <param name="deleteOrderID">Represents OrderDetailsID to delete.</param>
        /// /// <param name="deleteProductID">Represents OrderDetailsID to delete.</param>
        /// <returns>Determinates whether the existing OrderDetails is updated.</returns>
        public async Task<bool> DeleteOrderDetailsBL(Guid deleteOrderID,Guid deleteProductID)
        {
            bool OrderDetailsDeleted = false;
            try
            {
                await Task.Run(() =>
                {
                    OrderDetailsDeleted = OrderDetailsDAL.DeleteOrderDetailsDAL(deleteOrderID,deleteProductID);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return OrderDetailsDeleted;
        }


        /// <summary>
        /// Calculates the unit price after product discount is applied.
        /// </summary>
        /// <param name="productID"></param>
        /// <returns> Returns the final unit price.</returns>
        public async Task<double> CalculateDiscountPriceBL(Guid productID)
        {
            ProductBL Access = new ProductBL();
            Product findProduct = await Access.GetProductByProductIDBL(productID);
            double DiscountedPrice = findProduct.CostPrice * (1 - (findProduct.ProductDiscount / 100));
            return DiscountedPrice;            
        }

        /// <summary>
        /// Calculate the total price of each product.
        /// </summary>
        /// <param name="orderDetail"></param>
        /// <returns>Returns Each product's total price.</returns>

        public double CalculateTotalPriceBL(OrderDetails orderDetail)
        {
            double TotalPrice = orderDetail.Quantity * orderDetail.UnitPrice;
            return TotalPrice;
        }


        /// <summary>
        /// Calculate Amount Payable.
        /// </summary>
        /// <param name="orderDetails"></param>
        /// <returns>Return total amount to be paid.</returns>
        public async Task<double> AmountPayable(List<OrderDetails> orderDetails)
        {
            double amountPayable = 0;
            await Task.Run(() =>
            {
                foreach (OrderDetails item in orderDetails)
                {
                    amountPayable = item.TotalPrice + amountPayable;
                }
            });

            return amountPayable;
        }

        /// <summary>
        /// Calculate total products that are going to be ordered..
        /// </summary>
        /// <param name="orderDetails"></param>
        /// <returns>Return total quantity that will be shipped.</returns>
        public async Task<int> TotalQuantity(List<OrderDetails> orderDetails)
        {
            int totalQuantity = 0;
            await Task.Run(() =>
            {
                foreach (OrderDetails item in orderDetails)
                {
                    totalQuantity = item.Quantity + totalQuantity;
                }
            });

            return totalQuantity;
        }


        /// <summary>
        /// Disposes DAL object(s).
        /// </summary>
        public void Dispose()
        {
            ((OrderDetailsDAL)OrderDetailsDAL).Dispose();
        }

        /// <summary>
        /// Invokes Serialize method of DAL.
        /// </summary>
        public static void Serialize()
        {
            try
            {
                //OrderDetailsDAL.Serialize();
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        ///Invokes Deserialize method of DAL.
        /// </summary>
        public static void Deserialize()
        {
            try
            {
               // OrderDetailsDAL.Deserialize();
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
