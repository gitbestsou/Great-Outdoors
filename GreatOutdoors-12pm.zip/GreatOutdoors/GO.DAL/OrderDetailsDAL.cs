﻿using Capgemini.GreatOutdoors.Contracts.DALContracts;
using Capgemini.GreatOutdoors.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capgemini.GreatOutdoors.DAL
{

    /// <summary>
    /// Contains data access layer methods for inserting, updating, deleting OrderDetailss from OrderDetailss collection.
    /// </summary>
    public class OrderDetailsDAL : OrderDetailsDALBase, IDisposable
    {
        /// <summary>
        /// Adds new OrderDetails to OrderDetails collection.
        /// </summary>
        /// <param name="newOrderDetails">Contains the OrderDetails details to be added.</param>
        /// <returns>Determinates whether the new OrderDetails is added.</returns>
        public override bool AddOrderDetailsDAL(OrderDetails newOrderDetails)
        {
            bool OrderDetailsAdded = false;
            try
            {
                newOrderDetails.OrderDetailID = Guid.NewGuid();

                OrderDetailsList.Add(newOrderDetails);
                OrderDetailsAdded = true;
            }
            catch (Exception)
            {
                throw;
            }
            return OrderDetailsAdded;
        }


        /// <summary>
        /// Gets OrderDetails based on OrderID.
        /// </summary>
        /// <param name="searchOrderID">Represents OrderDetailsID to search.</param>
        /// <returns>Returns List of OrderDetails object.</returns>
        public override List<OrderDetails> GetOrderDetailsByOrderIDDAL(Guid searchOrderID)
        {
            List<OrderDetails> matchingOrderDetails = null;
            try
            {
                //Find OrderDetails based on searchOrderDetailsID
                matchingOrderDetails = OrderDetailsList.FindAll(
                    (item) => { return item.OrderDetailID == searchOrderID; }
                );
            }
            catch (Exception)
            {
                throw;
            }
            return matchingOrderDetails;
        }

        /// <summary>
        /// Gets OrderDetails based on ProductID.
        /// </summary>
        /// <param name="searchProductID">Represents OrderDetailsID to search.</param>
        /// <returns>Returns OrderDetails object.</returns>
        public override List<OrderDetails> GetOrderDetailsByProductIDDAL(Guid searchProductID)
        {
            List<OrderDetails> matchingOrderDetails = null;
            try
            {
                //Find OrderDetails based on searchOrderDetailsID
                matchingOrderDetails = OrderDetailsList.FindAll(
                    (item) => { return item.OrderDetailID == searchProductID; }
                );
            }
            catch (Exception)
            {
                throw;
            }
            return matchingOrderDetails;
        }



        /// <summary>
        /// Deletes OrderDetails based on OrderID and ProductID.
        /// </summary>
        /// <param name="deleteOrderID">Represents OrderDetailsID to delete.</param>
        /// <param name="deleteProductID">Represents OrderDetailsID to delete.</param>
        /// <returns>Determinates whether the existing OrderDetails is updated.</returns>
        public override bool DeleteOrderDetailsDAL(Guid deleteOrderID, Guid deleteProductID)
        {
            bool orderDeleted = false;
            try
            {
                
                OrderDetails matchingOrderDetails = OrderDetailsList.Find(
                    (item) => { return item.OrderDetailID == deleteOrderID && item.ProductID == deleteProductID ; }
                );

                if (matchingOrderDetails != null)
                {
                    //Delete OrderDetails from the collection
                    OrderDetailsList.Remove(matchingOrderDetails);
                    orderDeleted = true;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return orderDeleted;
        }

       



        /// <summary>
        /// Clears unmanaged resources such as db connections or file streams.
        /// </summary>
        public void Dispose()
        {
            //No unmanaged resources currently
        }
    }
}

