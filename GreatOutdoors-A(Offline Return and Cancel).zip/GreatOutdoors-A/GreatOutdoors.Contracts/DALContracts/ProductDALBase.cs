﻿using System;
using System.Collections.Generic;
using System.IO;
using Capgemini.GreatOutdoors.Entities;
using GreatOutdoors.Entities;
using Newtonsoft.Json;

namespace Capgemini.GreatOutdoors.Contracts.DALContracts
{
    /// <summary>
    /// This abstract class acts as a base for ProductDAL class
    /// </summary>
    public abstract class ProductDALBase
    {
        //Collection of Products
        protected static List<Product> productList = new List<Product>()
        {
             new Product(){ ProductID = Guid.NewGuid(), ProductName = "Backpack               ", CategoryName = Category.Camping, ProductStock = 100, ProductSize = "Small ", ProductColour = "Red   ",           ProductTechSpecs = "Material - Polyester, Strap - Adjustable           ", CostPrice = 1000, SellingPrice = 1200, ProductDiscount = 10 },
             new Product(){ ProductID = Guid.NewGuid(), ProductName = "Trekking Shoes         ", CategoryName = Category.Camping,ProductStock = 100, ProductSize = "Medium", ProductColour = "Blue  ",            ProductTechSpecs = "Outer Material - Fabric, Upper Pattern - Monochrome", CostPrice = 1200, SellingPrice = 1400, ProductDiscount = 15 },
             new Product(){ ProductID = Guid.NewGuid(), ProductName = "Stick                  ", CategoryName = Category.Golf ,ProductStock = 100, ProductSize = "Large ", ProductColour = "White ",              ProductTechSpecs = "Hand Orientation - Right                             ", CostPrice = 500, SellingPrice = 700, ProductDiscount = 5 },
             new Product(){ ProductID = Guid.NewGuid(), ProductName = "Ball                   ", CategoryName = Category.Golf,ProductStock = 100, ProductSize = "Small ", ProductColour = "White ",               ProductTechSpecs = "Material Type-polypropylene, Weight - 170 grams     ", CostPrice = 300, SellingPrice = 400, ProductDiscount = 5 },
             new Product(){ ProductID = Guid.NewGuid(), ProductName = "Mountaineering Helmet  ", CategoryName = Category.Mountaineering ,ProductStock = 100, ProductSize = "Medium", ProductColour = "Yellow",    ProductTechSpecs = "Type - Full Face, Straps - Yes                       ", CostPrice = 1500, SellingPrice = 2000, ProductDiscount = 10 },
             new Product(){ ProductID = Guid.NewGuid(), ProductName = "Momentum Traction Spike", CategoryName = Category.Mountaineering,ProductStock = 100, ProductSize = "Medium", ProductColour = "Blue  ",     ProductTechSpecs = "Materials - Thermoplastic, Brand - Add Gear          ", CostPrice = 1800, SellingPrice = 2000, ProductDiscount = 10 },
             new Product(){ ProductID = Guid.NewGuid(), ProductName = "Gloves                 ", CategoryName = Category.OutdoorProtection ,ProductStock = 100, ProductSize = "Small ", ProductColour = "Black ", ProductTechSpecs = "Material - Suede, Sport Type - Riding                ", CostPrice = 200, SellingPrice = 300, ProductDiscount = 5 },
             new Product(){ ProductID = Guid.NewGuid(), ProductName = "Goggles                ", CategoryName = Category.OutdoorProtection,ProductStock = 100, ProductSize = "Medium ", ProductColour = "Green ", ProductTechSpecs = "Material - Polycarbonate, Foldable - No              ", CostPrice = 600, SellingPrice = 800, ProductDiscount = 5 },
             new Product(){ ProductID = Guid.NewGuid(), ProductName = "Wallet                 ", CategoryName = Category.PersonalAccessories ,ProductStock = 100, ProductSize = "Small ", ProductColour = "Black ", ProductTechSpecs = "Material - Aviation, Weight - 40g                  ", CostPrice = 300, SellingPrice = 400, ProductDiscount = 2 },
             new Product(){ ProductID = Guid.NewGuid(), ProductName = "Bag                    ", CategoryName = Category.PersonalAccessories,ProductStock = 100, ProductSize = "Medium ", ProductColour = "Pink  ", ProductTechSpecs = "Material - Polyester, Volume - 25 litre             ", CostPrice = 500, SellingPrice = 700, ProductDiscount = 5 }
        };
        private static string fileName = "products.json";

        //Methods for CRUD operations
        public abstract bool AddProductDAL(Product newProduct);
        public abstract List<Product> GetAllProductsDAL();
        public abstract Product GetProductByProductIDDAL(Guid searchProductID);
        public abstract List<Product> GetProductsByNameDAL(string ProductName);
        public abstract List<Product> GetProductsByCategoryDAL(Category categoryName);
        public abstract bool UpdateProductDAL(Product updateProduct);
        public abstract bool UpdateProductStockDAL(Product updateProduct);
        public abstract bool DeleteProductDAL(Guid deleteProductID);






        /// <summary>
        /// Writes collection to the file in JSON format.
        /// </summary>
        public static void Serialize()
        {
            string serializedJson = JsonConvert.SerializeObject(productList);
            using (StreamWriter streamWriter = new StreamWriter(fileName))
            {
                streamWriter.Write(serializedJson);
                streamWriter.Close();
            }
        }

        /// <summary>
        /// Reads collection from the file in JSON format.
        /// </summary>
        public static void Deserialize()
        {
            string fileContent = string.Empty;
            if (!File.Exists(fileName))
                File.Create(fileName).Close();

            using (StreamReader streamReader = new StreamReader(fileName))
            {
                fileContent = streamReader.ReadToEnd();
                streamReader.Close();
                var systemUserListFromFile = JsonConvert.DeserializeObject<List<Product>>(fileContent);
                if (systemUserListFromFile != null)
                {
                    productList = systemUserListFromFile;
                }
            }
        }

        /// <summary>
        /// Static Constructor.
        /// </summary>
        static ProductDALBase()
        {
            Deserialize();
        }
    }
}


