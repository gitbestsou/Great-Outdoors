﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Capgemini.GreatOutdoors.BusinessLayer;
using Capgemini.GreatOutdoors.Entities;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Capgemini.GreatOutdoors.UnitTests
{
    [TestClass]
    public class AddReturnBLTest
    {
        [TestMethod]
        public async Task AddValidReturn()
        {
            /*ReturnID = default(Guid);
            OrderID = default(Guid);
            ChannelOfReturn = ReturnChannel.Online;

            ReturnAmount = default(double);
            ReturnDateTime = default(DateTime);*/
            ReturnBL returnBL = new ReturnBL();
            Return returnObj = new Return() { ReturnID = default(Guid), OrderID = default(Guid), ChannelOfReturn = ReturnChannel.Offline, ReturnAmount = 1000, ReturnDateTime = DateTime.Now };
            bool isAdded = false;
            Guid Id = default(Guid);
            string errorMessage = null;
            try
            {
                //call AddOrder and get OrderID
                //assign the same to 
                OrderBL orderBL = new OrderBL();
                bool orderAdded;
                Guid orderIDFromOrderClass;
                Order order = new Order();
                (orderAdded, orderIDFromOrderClass) = await orderBL.AddOrderBL(order);
                returnObj.OrderID = orderIDFromOrderClass;
                (isAdded, Id) = await returnBL.AddReturnBL(returnObj);
            }
            catch (Exception ex)
            {
                isAdded = false;
                Id = default(Guid);
                errorMessage = ex.Message;
            }
            finally
            {
                Assert.IsTrue(isAdded, errorMessage);
            }
        }

        //




    }
}
