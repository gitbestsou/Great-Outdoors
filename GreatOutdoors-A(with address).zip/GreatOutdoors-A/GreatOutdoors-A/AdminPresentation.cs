﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using static System.Console;
using Capgemini.GreatOutdoors.BusinessLayer;
using Capgemini.GreatOutdoors.Entities;
using Capgemini.GreatOutdoors.Exceptions;
using Capgemini.GreatOutdoors.Contracts.BLContracts;

namespace Capgemini.GreatOutdoors.PresentationLayer
{
    public static class AdminPresentation
    {
        /// <summary>
        /// Menu for Admin User
        /// </summary>
        /// <returns></returns>
        public static async Task<int> AdminUserMenu()
        {
            int choice = -2;
            using (ISalesPersonBL salesPersonBL = new SalesPersonBL())
            {
                do
                {
                    //Get and display list of system users.
                    List<SalesPerson> salesPersons = await salesPersonBL.GetAllSalesPersonsBL();
                    WriteLine("\n***************ADMIN***********\n");
                    WriteLine("SALES PERSONS:");
                    if (salesPersons != null && salesPersons?.Count > 0)
                    {
                        WriteLine("#\tName\tEmail\tCreated\tModified");
                        int serial = 0;
                        foreach (var salesPerson in salesPersons)
                        {
                            serial++;
                            WriteLine($"{serial}\t{salesPerson.SalesPersonName}\t{salesPerson.Email}\t{salesPerson.CreationDateTime}\t{salesPerson.LastModifiedDateTime}");
                        }
                    }

                    //Menu
                    WriteLine("\n1. Add Sales Person ");
                    WriteLine("2. Delete Sales Person");
                    WriteLine("3. View Sales Report");
                    WriteLine("4. View Retailer Report");
                    WriteLine("5. View Overall Report");
                    WriteLine("6. Update Discount");
                    WriteLine("-----------------------");
                    WriteLine("7. Change Password");
                    WriteLine("0. Logout");
                    WriteLine("-1. Exit");
                    Write("Choice: ");

                    //Accept and check choice
                    bool isValidChoice = int.TryParse(ReadLine(), out choice);
                    if (isValidChoice)
                    {
                        switch (choice)
                        {
                            case 1: await AddSalesPerson(); break;
                            case 2: await DeleteSalesPerson(); break;
                            case 3: await ViewSalesReport(); break;
                            case 4: await ViewRetailerReport(); break;
                            case 5: await ViewOverAllReport(); break;
                            case 6: await UpdateDiscount(); break;

                            case 7: await ChangeAdminPassword(); break;
                            case 0: break;
                            case -1: break;
                            default: WriteLine("Invalid Choice"); break;
                        }
                    }
                    else
                    {
                        choice = -2;
                    }
                } while (choice != 0 && choice != -1);
            }
            return choice;
        }

        /// <summary>
        /// Adds Sales Person.
        /// </summary>
        /// <returns></returns>
        public static async Task AddSalesPerson()
        {
            try
            {
                //Read inputs
                SalesPerson salesPerson = new SalesPerson();
                Write("Name: ");
                salesPerson.SalesPersonName = ReadLine();
                Write("Email: ");
                salesPerson.Email = ReadLine();
                Write("Password: ");
                salesPerson.Password = ReadLine();
                Write("Mobile: ");
                salesPerson.SalesPersonMobile = ReadLine();
                salesPerson.SalesPersonSalary = 10000;
                salesPerson.SalesPersonBonus = 1000;
                salesPerson.CreationDateTime = DateTime.Now;
                salesPerson.LastModifiedDateTime = DateTime.Now;
                salesPerson.SalesPersonID = Guid.NewGuid();

                //Invoke AddSalesPersonBL method to add
                using (ISalesPersonBL salesPersonBL = new SalesPersonBL())
                {
                    bool isAdded = await salesPersonBL.AddSalesPersonBL(salesPerson);
                    if (isAdded)
                    {
                        WriteLine("Sales Person Added");
                    }
                }
            }
            catch (GreatOutdoorsException ex)
            {
                ExceptionLogger.LogException(ex);
                WriteLine(ex.Message);
            }
        }

       
        /// <summary>
        /// Delete System User.
        /// </summary>
        /// <returns></returns>
        public static async Task DeleteSalesPerson()
        {
            try
            {
                using (ISalesPersonBL salesPersonBL = new SalesPersonBL())
                {
                    //Read Sl.No
                    Write("System User #: ");
                    bool isNumberValid = int.TryParse(ReadLine(), out int serial);
                    if (isNumberValid)
                    {
                        serial--;
                        List<SalesPerson> salesPersons = await salesPersonBL.GetAllSalesPersonsBL();
                        if (serial <= salesPersons.Count - 1)
                        {
                            //Confirmation
                            SalesPerson salesPerson = salesPersons[serial];
                            Write("Are you sure? (Y/N): ");
                            string confirmation = ReadLine();

                            if (confirmation.Equals("Y", StringComparison.OrdinalIgnoreCase))
                            {
                                //Invoke DeleteSalesPersonBL method to delete
                                bool isDeleted = await salesPersonBL.DeleteSalesPersonBL(salesPerson.SalesPersonID);
                                if (isDeleted)
                                {
                                    WriteLine("System User Deleted");
                                }
                            }
                        }
                        else
                        {
                            WriteLine($"Invalid System User #.\nPlease enter a number between 1 to {salesPersons.Count}");
                        }
                    }
                    else
                    {
                        WriteLine($"Invalid number.");
                    }
                }
            }
            catch (GreatOutdoorsException ex)
            {
                ExceptionLogger.LogException(ex);
                WriteLine(ex.Message);
            }
        }

        /// <summary>
        /// Adds Sales Person.
        /// </summary>
        /// <returns></returns>
        public static async Task ViewSalesReport()
        {
            try
            {
                int sNo;
                OrderBL orderBL = new OrderBL();
                List<Order> orders = new List<Order>();
                Order order = new Order();
                SalesPersonBL salesPersonBL = new SalesPersonBL();
                List<SalesPerson> salesPeople = await salesPersonBL.GetAllSalesPersonsBL();
                WriteLine("Sales Persons:\n");
                WriteLine("S.No" + "\t" + "ID" + "\t\t" + "Name");
                for (int i = 0; i < salesPeople.Count; i++)
                {
                    WriteLine((i + 1) + "\t" + salesPeople[i].SalesPersonName);
                }
                Console.WriteLine("Select Sales Person serial no.:");
                sNo = int.Parse(ReadLine())-1;
                WriteLine("Sales Report:");
                orders = await orderBL.GetOrderBySalesPersonIDBL(salesPeople[sNo].SalesPersonID);
                WriteLine("Orders:\n");
                for (int i = 0; i < orders.Count; i++)
                {
                    WriteLine($"Order ID:{orders[i].OrderID}" + "\t" +
                        $"Total Amount:{orders[i].TotalAmount}");
                }
            }
            catch (GreatOutdoorsException ex)
            {
                ExceptionLogger.LogException(ex);
                WriteLine(ex.Message);
            }
        }

        public static async Task ViewRetailerReport()
        {
            try
            {
                int sNo;
                OrderBL orderBL = new OrderBL();
                List<Order> orders = new List<Order>();
                Order order = new Order();
                RetailerBL retailerBL = new RetailerBL();
                List<Retailer> retailers = await retailerBL.GetAllRetailersBL();
                WriteLine("Retailers:\n");
                WriteLine("S.No" + "\t" + "ID" + "\t\t" + "Name");
                for (int i = 0; i < retailers.Count; i++)
                {
                    WriteLine((i + 1) + "\t" + retailers[i].RetailerID + "\t" + retailers[i].RetailerName);
                }
                Console.WriteLine("Select Retailer serial no.:");
                sNo = int.Parse(ReadLine())-1;
                WriteLine("Retailer Report:\nRetailer Name:"+ retailers[sNo].RetailerName);
                orders = await orderBL.GetOrderByRetailerIDBL(retailers[sNo].RetailerID);
                WriteLine("\nOrders:\n");
                for (int i = 0; i < orders.Count; i++)
                {
                    WriteLine($"Order ID:{orders[i].OrderID}" + "\t" +
                        $"Total Amount:{orders[i].TotalAmount}");
                }


            }
            catch (GreatOutdoorsException ex)
            {
                ExceptionLogger.LogException(ex);
                WriteLine(ex.Message);
            }
        }

        public static async Task ViewOverAllReport()
        {
            try
            {
                double TotalSumAmount = 0;
                List<Order> orders = new List<Order>();
                OrderBL orderBL = new OrderBL();
                orders = await orderBL.GetAllOrdersBL();
                WriteLine("Overall Report:");
                WriteLine("Online Orders:");
                WriteLine("Order ID\t\t TotalAmount");
                foreach (var item in orders)
                {
                    if (item.ChannelOfSale == Channel.Online)
                    {
                        WriteLine($"{item.OrderID}\t" +
                            $"{item.TotalAmount}");
                        TotalSumAmount += item.TotalAmount;
                    }
                }
                WriteLine("Total Sum Amount:" + TotalSumAmount);
                WriteLine("\n\nOffline Orders:");
                WriteLine("Order ID\t\t SalesPerson ID\t\t TotalAmount");
                TotalSumAmount = 0;
                foreach (var item in orders)
                {
                    if (item.ChannelOfSale == Channel.Offline)
                    {
                        WriteLine($"{item.OrderID}\t" +
                            $"{item.SalesPersonID}\t" +
                            $"{item.TotalAmount}");
                        TotalSumAmount += item.TotalAmount;
                    }
                }
                WriteLine("Total Sum Amount:" + TotalSumAmount);
            }
            catch (GreatOutdoorsException ex)
            {
                ExceptionLogger.LogException(ex);
                WriteLine(ex.Message);
            }
        }

        public static async Task UpdateDiscount()
        {
            try
            {

            }
            catch (GreatOutdoorsException ex)
            {
                ExceptionLogger.LogException(ex);
                WriteLine(ex.Message);
            }
        }

        /// <summary>
        /// Updates Admin's Password.
        /// </summary>
        /// <returns></returns>
        public static async Task ChangeAdminPassword()
        {
            try
            {
                using (IAdminBL adminBL = new AdminBL())
                {
                    //Read Current Password
                    Write("Current Password: ");
                    string currentPassword = ReadLine();

                    Admin existingAdmin = await adminBL.GetAdminByEmailAndPasswordBL(CommonData.CurrentUser.Email, currentPassword);

                    if (existingAdmin != null)
                    {
                        //Read inputs
                        Write("New Password: ");
                        string newPassword = ReadLine();
                        Write("Confirm Password: ");
                        string confirmPassword = ReadLine();

                        if (newPassword.Equals(confirmPassword))
                        {
                            existingAdmin.Password = newPassword;

                            //Invoke UpdateSalesPersonBL method to update
                            bool isUpdated = await adminBL.UpdateAdminPasswordBL(existingAdmin);
                            if (isUpdated)
                            {
                                WriteLine("Admin Password Updated");
                            }
                        }
                        else
                        {
                            WriteLine($"New Password and Confirm Password doesn't match");
                        }
                    }
                    else
                    {
                        WriteLine($"Current Password doesn't match.");
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionLogger.LogException(ex);
                WriteLine(ex.Message);
            }
        }
    }
}


