﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GreatOutdoors.UnitTests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {

        }
    }
}
