﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Capgemini.GreatOutdoors.Contracts.BLContracts;
using Capgemini.GreatOutdoors.Contracts.DALContracts;
using Capgemini.GreatOutdoors.DAL;
using Capgemini.GreatOutdoors.Exceptions;

namespace Capgemini.GreatOutdoors.BusinessLayer
{
    /// <summary>
    /// Contains data access layer methods for inserting, updating, deleting Addresss from Addresss collection.
    /// </summary>
    public class StateBL : BLBase<string>, IStateBL, IDisposable
    {
        //fields
        StateDALBase stateDAL;

        /// <summary>
        /// Constructor.
        /// </summary>
        public StateBL()
        {
            this.stateDAL = new StateDAL();
        }

        /// <summary>
        /// Adds new state to State collection.
        /// </summary>
        /// <param name="newState">Contains the state details to be added.</param>
        /// <returns>Determinates whether the new state is added.</returns>
        public async Task<bool> AddStateBL(string newState)
        {
            bool stateAdded = false;
            try
            {
                if (await Validate(newState))
                {
                    await Task.Run(() =>
                    {
                        this.stateDAL.AddStateDAL(newState);
                        stateAdded = true;
                        //Serialize();
                    });
                }
            }
            catch (GreatOutdoorsException)
            {
                throw;
            }
            return stateAdded;
        }

        /// <summary>
        /// Gets all address from the collection.
        /// </summary>
        /// <returns>Returns list of all addresses.</returns>
        public async Task<List<string>> GetAllStateBL()
        {
            List<string> stateList = null;
            try
            {
                await Task.Run(() =>
                {
                    stateList = stateDAL.GetAllStateDAL();
                });
            }
            catch (GreatOutdoorsException)
            {
                throw;
            }
            return stateList;
        }

        /// <summary>
        /// Deletes state
        /// </summary>
        /// <param name="deleteState">Represents state to delete.</param>
        /// <returns>Determinates whether the existing State is updated.</returns>
        public async Task<bool> DeleteStateBL(string deleteState)
        {
            bool StateDeleted = false;
            try
            {
                await Task.Run(() =>
                {
                    StateDeleted = stateDAL.DeleteStateDAL(deleteState);
                    Serialize();
                });
            }
            catch (GreatOutdoorsException)
            {
                throw;
            }
            return StateDeleted;
        }



        /// <summary>
        /// Disposes DAL object(s).
        /// </summary>
        public void Dispose()
        {
            ((StateDAL)stateDAL).Dispose();
        }

        /// <summary>
        /// Invokes Serialize method of DAL.
        /// </summary>
        public static void Serialize()
        {
            try
            {
                StateDAL.Serialize();
            }
            catch (GreatOutdoorsException)
            {
                throw;
            }
        }

        /// <summary>
        ///Invokes Deserialize method of DAL.
        /// </summary>
        public static void Deserialize()
        {
            try
            {
                StateDAL.Deserialize();
            }
            catch (GreatOutdoorsException)
            {
                throw;
            }
        }
    }
}