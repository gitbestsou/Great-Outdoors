﻿using Capgemini.GreatOutdoors.Helpers.ValidationAttributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capgemini.GreatOutdoors.Entities
{
    /// <summary>
    /// Interface for Address Entity
    /// </summary>
    public interface IAddress
    {
        Guid AddressID { get; set; }
        Guid RetailerID { get; set; }

        string Line1 { get; set; }
        string Line2 { get; set; }
        string City { get; set; }
        int Pincode { get; set; }
        Guid StateID { get; set; }
        string MobileNo { get; set; }
        DateTime CreationDateTime { get; set; }
        DateTime LastModifiedDateTime { get; set; }
    }

    /// <summary>
    /// Represents Address
    /// </summary>
    public class Address : IAddress
    {
        /*Auto-Implemented properties*/
        [Required("RetailerID can't be blank.")]
        public Guid RetailerID { get; set; }

        [Required("AddressID can't be blank.")]
        public Guid AddressID { get; set; }

        [Required("Address Line1 can't be blank.")]
        public string Line1 { get; set; }

        [Required("Address Line2 can't be blank.")]
        public string Line2 { get; set; }

        [Required("City can't be blank.")]
        public string City { get; set; }

        [RegExp(@"^\d{5}$", "Pincode should contain 6 digits")]
        public int Pincode { get; set; }

        [Required("StateID can't be blank.")]
        public Guid StateID { get; set; }

        [RegExp(@"^[6789]\d{9}$", "Mobile number should contain 10 digits")]
        public string MobileNo { get; set; }

        public DateTime CreationDateTime { get; set; }
        public DateTime LastModifiedDateTime { get; set; }

        /*Constructor*/
        public Address()
        {
            AddressID = default(Guid);
            Line1 = null;
            Line2 = null;
            City = null;
            Pincode = default(int);
            StateID = default(Guid);
            MobileNo = null;
            CreationDateTime = default(DateTime);
            LastModifiedDateTime = default(DateTime);

        }
    }
}
