﻿using Capgemini.GreatOutdoors.BusinessLayer;
using Capgemini.GreatOutdoors.Contracts.BLContracts;
using Capgemini.GreatOutdoors.Entities;
using Capgemini.GreatOutdoors.Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capgemini.GreatOutdoors.PresentationLayer
{
    class MakeOrder
    {
        public static async Task ViewProducts()
        {
            try
            {
                using (IProductBL productBL = new ProductBL())
                {
                    //Get and display list of products
                    List<Product> products = await productBL.GetAllProductsBL();
                    Console.WriteLine("PRODUCTS : ");
                    Console.WriteLine("#\tProduct Name\tColour\tPrice\tSpecifications");
                    if (products != null && products?.Count > 0)
                    {
                        Console.WriteLine(".......................");
                        int serial = 0;
                        foreach (var product in products)
                        {
                            serial++;
                            Console.WriteLine($"{serial}\t{product.ProductName}\t{product.ProductColour}\t{product.SellingPrice}\t{product.ProductTechSpecs}");
                        }
                    }
                    using (IOrdersBL orderBL = new OrderBL())
                    {
                        // Create new order to get orderID
                        Order order = new Order();
                        (bool orderConfirmed, Guid Id) = await orderBL.AddOrderBL(order);


                        using (IOrderDetailsBL orderDetailsBL = new OrderDetailsBL())
                        {
                            bool replyValid = true;
                            int serial = 0;
                            do
                            {
                                // Add order details to each order
                                OrderDetail currentProduct = new OrderDetail();
                                currentProduct.OrderDetailID = Guid.NewGuid();
                                currentProduct.OrderID = Id;
                                Console.WriteLine("Select the product : ");
                                currentProduct.ProductID = products[int.Parse(Console.ReadLine()) - 1].ProductID;
                                Console.WriteLine("Enter Quantity : ");
                                currentProduct.Quantity = int.Parse(Console.ReadLine());
                                currentProduct.UnitPrice = await orderDetailsBL.CalculateDiscountPriceBL(currentProduct.ProductID);
                                currentProduct.TotalPrice = orderDetailsBL.CalculateTotalPriceBL(currentProduct);
                                bool isOrderAdded = await orderDetailsBL.AddOrderDetailsBL(currentProduct);
                                serial++;
                                Console.WriteLine("You want to add another Product(Y/N) : ");
                                string replyConsole = Console.ReadLine();
                                if ((replyConsole.ToLower()).Equals("y"))
                                    replyValid = true;
                                else if ((replyConsole.ToLower()).Equals("n"))
                                    replyValid = false;
                                else
                                    Console.WriteLine("Invalid choice");
                            } while (replyValid);


                            Order fetch = await orderBL.GetOrderByOrderIDBL(Id);
                            List<OrderDetail> confirm = await orderDetailsBL.GetOrderDetailsByOrderIDBL(Id);
                            fetch.TotalAmount = await orderDetailsBL.AmountPayable(confirm);

                            // Displaying total amount
                            Console.WriteLine($"Total Amount to be paid: {fetch.TotalAmount}");
                            //Checking for payment
                            Console.WriteLine("You want to make payment(Y/N) ?");
                            string makePayment = (Console.ReadLine()).ToLower();

                            // Confirming order on payment
                            if (makePayment == "y")
                            {

                                fetch.TotalQuantity = await orderDetailsBL.TotalQuantity(confirm);

                                fetch.TotalAmount = await orderDetailsBL.AmountPayable(confirm);

                                Console.WriteLine("Enter Shipping Address : ");
                                fetch.ShippingAddress = Console.ReadLine();

                                fetch.OrderDateTime = DateTime.Now;

                                fetch.ChannelOfSale = Channel.Online;

                                fetch.CurrentStatus = Status.UnderProcessing;

                                // fetching current retailer details
                                using (IRetailerBL currRetailerBL = new RetailerBL())
                                {
                                    Retailer ret = await currRetailerBL.GetRetailerByEmailAndPasswordBL(CommonData.CurrentUser.Email, CommonData.CurrentUser.Password);
                                    fetch.RetailerID = ret.RetailerID;
                                }

                                Console.WriteLine("Thank you for shopping with us.");


                            }


                            if (makePayment == "n")
                            {
                                // Delete order from list
                                List<OrderDetail> delete = await orderDetailsBL.GetOrderDetailsByOrderIDBL(Id);
                                int count = delete.Count();
                                while (serial > 0)
                                {
                                    count--;
                                    await orderDetailsBL.DeleteOrderDetailsBL(delete[count].OrderID, delete[count].ProductID);
                                    serial--;

                                }
                                Console.WriteLine("Thank you for shopping with us.");
                                await orderBL.DeleteOrderByOrderID(Id);

                            }
                        }
                    }
                }
            }
            catch (GreatOutdoorsException ex)
            {
                ExceptionLogger.LogException(ex);
                Console.WriteLine(ex.Message);
            }
        }

    }
}

