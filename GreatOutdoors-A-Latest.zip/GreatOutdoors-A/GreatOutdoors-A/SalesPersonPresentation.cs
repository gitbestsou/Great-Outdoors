﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using static System.Console;
using Capgemini.GreatOutdoors.BusinessLayer;
using Capgemini.GreatOutdoors.Entities;
using Capgemini.GreatOutdoors.Exceptions;
using Capgemini.GreatOutdoors.Contracts.BLContracts;

namespace Capgemini.GreatOutdoors.PresentationLayer
{
    public static class SalesPersonPresentation
    {
        /// <summary>
        /// Menu for SystemUser
        /// </summary>
        /// <returns></returns>
        public static async Task<int> SalesPersonMenu()
        {
            int choice = -2;

            do
            {
                //Menu
                WriteLine("\n***************Sales Person***********");
                WriteLine("1. View your profile");
                WriteLine("2. Update your profile");
                WriteLine("3. Upload order");
                WriteLine("4. View Sales History");
                WriteLine("5. Change Password");
                WriteLine("0. Logout");
                WriteLine("-1. Exit");
                Write("Choice: ");

                //Accept and check choice
                bool isValidChoice = int.TryParse(ReadLine(), out choice);
                if (isValidChoice)
                {
                    switch (choice)
                    {
                        case 1: await ViewProfile(); break;
                        case 2: await UpdateProfile(); break;
                        case 3: await UploadOfflineOrder(); break;
                        case 4: await ViewSalesHistory(); break;
                        case 5: await ChangePassword(); break;
                        case 0: break;
                        case -1: break;
                        default: WriteLine("Invalid Choice"); break;
                    }
                }
                else
                {
                    choice = -2;
                }
            } while (choice != 0 && choice != -1);
            return choice;
        }



        /// <summary>
        /// Uploads offline orders of SalesPerson
        /// </summary>
        /// <returns></returns>
        public static async Task UploadOfflineOrder()
        {
            try
            {
                using (ISalesPersonBL salesPersonBL = new SalesPersonBL())
                {
                    Order newOrder = new Order();

                    RetailerBL retailerBL = new RetailerBL();
                    List<Retailer> retailers = await retailerBL.GetAllRetailersBL();

                    WriteLine("Select from the list of retailers");
                    if (retailers != null && retailers?.Count > 0)
                    {
                        WriteLine("#\tRetailer Name\tEmail ID");
                        int sno = 0;
                        foreach (var retailer in retailers)
                        {
                            sno++;
                            WriteLine($"{sno}\t{retailer.RetailerName}\t{retailer.Email}");
                        }
                    }


                    //Read Sl.No
                    Write("Retailer #: ");
                    bool isNumberValid = int.TryParse(ReadLine(), out int serial);
                    if (isNumberValid)
                    {
                        if (serial <= retailers.Count - 1)
                        {
                            newOrder.RetailerID = retailers[serial - 1].RetailerID;

                        }
                        else
                        {
                            WriteLine($"Invalid Retailer #.\nPlease enter a number between 1 to {retailers.Count}");
                        }
                    }
                    else
                    {
                        WriteLine($"Invalid number.");
                    }


                    List<OrderDetail> orderDetails = new List<OrderDetail>();

                    OrderDetailsBL orderDetailsBL = new OrderDetailsBL();
                    ProductBL productBL = new ProductBL();
                    List<Product> products = await productBL.GetAllProductsBL();
                    WriteLine("Select Product from list");

                    //Get and display list of products.

                    if (products != null && products?.Count > 0)
                    {
                        WriteLine("#\tProduct Name\tColour\tPrice\tSpecifications");
                        int sn = 0;
                        foreach (var product in products)
                        {
                            sn++;
                            WriteLine($"{sn}\t{product.ProductName}\t{product.ProductColour}\t{product.SellingPrice}\t{product.ProductTechSpecs}");
                        }
                    }


                    string isContinue = "y";
                    do
                    {
                        //accept product #

                        //Read Sl.No
                        Write("Product #: ");
                        bool isNumValid = int.TryParse(ReadLine(), out int snum);
                        if (isNumValid)
                        {
                            OrderDetail orderDetail = new OrderDetail(); // create object for order detail
                            if (snum <= products.Count - 1)
                            {
                                orderDetail.ProductID = products[snum - 1].ProductID;
                                // Get unit price after discount, if any
                                orderDetail.UnitPrice = await orderDetailsBL.CalculateDiscountPriceBL(orderDetail.ProductID);
                                WriteLine($"Unit Price: {orderDetail.UnitPrice}");

                                // Accepting quantity of each product
                                WriteLine("Enter quantity: ");
                                bool isValid = int.TryParse(ReadLine(), out int quantity);
                                orderDetail.Quantity = quantity;

                                //Showing total amount
                                double totalPrice = orderDetailsBL.CalculateTotalPriceBL(orderDetail);
                                orderDetail.TotalPrice = totalPrice;


                                // Adding to list of order details
                                orderDetails.Add(orderDetail);

                            }
                            else
                            {
                                WriteLine($"Invalid Product #.\nPlease enter a number between 1 to {products.Count}");
                            }
                        }
                        else
                        {
                            WriteLine($"Invalid number.");
                        }

                        WriteLine("Do you want to add another product: Y/N");
                        isContinue = ReadLine();

                    } while (isContinue.Equals("y", StringComparison.OrdinalIgnoreCase));



                    newOrder.TotalQuantity = await orderDetailsBL.TotalQuantity(orderDetails);
                    newOrder.TotalAmount = await orderDetailsBL.AmountPayable(orderDetails);


                    //add address
                    WriteLine("Enter Retailer Address: ");
                    newOrder.ShippingAddress = ReadLine();
                    newOrder.SalesPersonID = (await salesPersonBL.GetSalesPersonByEmailBL(CommonData.CurrentUser.Email)).SalesPersonID;
                    newOrder.CurrentStatus = Status.Delivered;
                    newOrder.OrderDateTime = DateTime.Now;
                    newOrder.ChannelOfSale = Channel.Offline;

                    //AddOrder(order);
                    Guid orderID = default(Guid);
                    bool orderAdded = false;
                    OrderBL orderBL = new OrderBL();
                    (orderAdded, orderID) = await orderBL.AddOrderBL(newOrder);

                    if (orderAdded)
                    {
                        WriteLine("Order uploaded successfully!");
                        foreach (OrderDetail orderDetail in orderDetails)
                        {
                            orderDetail.OrderID = orderID;
                            await orderDetailsBL.AddOrderDetailsBL(orderDetail);
                        }
                    }

                }
            }
            catch (GreatOutdoorsException ex)
            {
                ExceptionLogger.LogException(ex);
                WriteLine(ex.Message);
            }
        }

        /// <summary>
        /// View Salesperson profile.
        /// </summary>
        public static async Task ViewProfile()
        {
            try
            {
                using (ISalesPersonBL salesPersonBL = new SalesPersonBL())
                {

                    SalesPerson currentSalesPerson = await salesPersonBL.GetSalesPersonByEmailAndPasswordBL(CommonData.CurrentUser.Email, CommonData.CurrentUser.Password);

                    WriteLine($"Name : {currentSalesPerson.SalesPersonName}");
                    WriteLine($"Mobile : {currentSalesPerson.SalesPersonMobile}");
                    WriteLine($"Email : {currentSalesPerson.Email}");
                    WriteLine($"Salary : {currentSalesPerson.SalesPersonSalary}");
                    WriteLine($"Bonus : {currentSalesPerson.SalesPersonBonus}");

                }
            }
            catch (Exception ex)
            {
                ExceptionLogger.LogException(ex);
                WriteLine(ex.Message);
            }
        }


        ///<summary>
        /// Update salesperson's profile
        ///</summary>
        public static async Task UpdateProfile()
        {
            try
            {
                using (ISalesPersonBL salesPersonBL = new SalesPersonBL())
                {
                    // Get current salesperson
                    SalesPerson existingSalesPerson = await salesPersonBL.GetSalesPersonByEmailAndPasswordBL(CommonData.CurrentUser.Email, CommonData.CurrentUser.Password);


                    WriteLine("Enter detail to be updated: ");
                    WriteLine("1.Name");
                    WriteLine("2.Email");
                    WriteLine("3.Mobile");
                    bool isvalidChoice = int.TryParse(ReadLine(), out int choice);

                    if (isvalidChoice)
                    {
                        switch (choice)
                        {
                            case 1:
                                WriteLine("Enter new name:");
                                string newName = ReadLine();
                                existingSalesPerson.SalesPersonName = newName;
                                bool isNameUpdated = await salesPersonBL.UpdateSalesPersonBL(existingSalesPerson);
                                if (isNameUpdated)
                                {
                                    WriteLine("Your name is updated");
                                }

                                break;
                            case 2:
                                WriteLine("Enter new email:");
                                string newEmail = ReadLine();
                                existingSalesPerson.Email = newEmail;
                                bool isEmailUpdated = await salesPersonBL.UpdateSalesPersonBL(existingSalesPerson);
                                if (isEmailUpdated)
                                {
                                    WriteLine("Your email is updated");
                                }

                                break;
                            case 3:
                                WriteLine("Enter new mobile:");
                                string newMobile = ReadLine();
                                existingSalesPerson.Email = newMobile;
                                bool isMobileUpdated = await salesPersonBL.UpdateSalesPersonBL(existingSalesPerson);
                                if (isMobileUpdated)
                                {
                                    WriteLine("Your mobile number is updated");
                                }

                                break;



                        }
                    }

                    else
                        WriteLine("Invalid Choice");

                }
            }

            catch (GreatOutdoorsException ex)
            {
                ExceptionLogger.LogException(ex);
                WriteLine(ex.Message);
            }
        }


        /// <summary> 
        /// View sales history of salesperson
        /// </summary>
        /// 
        public static async Task ViewSalesHistory()
        {
            try
            {
                using (SalesPersonBL salesPersonBL = new SalesPersonBL())
                {
                    //Get and display list of orders of salesperson

                    //Get current sales person
                    SalesPerson existingSalesPerson = await salesPersonBL.GetSalesPersonByEmailAndPasswordBL(CommonData.CurrentUser.Email, CommonData.CurrentUser.Password);

                    List<Order> orders = new List<Order>();
                    orders = await salesPersonBL.GetSalesHistoryBL(existingSalesPerson.SalesPersonID);
                    ProductBL productBL = new ProductBL();
                    RetailerBL retailerBL = new RetailerBL();
                    OrderDetailsBL orderDetailsBL = new OrderDetailsBL();

                    foreach (Order order in orders)
                    {
                        List<OrderDetail> orderDetails = await orderDetailsBL.GetOrderDetailsByOrderIDBL(order.OrderID);
                        WriteLine($"OrderID : {order.OrderID}");
                        string retailerName = (await retailerBL.GetRetailerByRetailerIDBL(order.RetailerID)).RetailerName;
                        WriteLine($"Retailer Name: {retailerName}");
                        foreach (OrderDetail orderDetail in orderDetails)
                        {
                            string productName = (await productBL.GetProductByProductIDBL(orderDetail.ProductID)).ProductName;

                            Write($"Product: {productName}");
                            Write($"Quantity: {orderDetail.Quantity}\n");
                        }

                        WriteLine($"Total Amount: {order.TotalAmount}");
                    }


                }
            }
            catch (GreatOutdoorsException ex)
            {
                ExceptionLogger.LogException(ex);
                WriteLine(ex.Message);
            }
        }
        /// <summary>
        /// Updates SalesPerson's Password.
        /// </summary>
        /// <returns></returns>
        public static async Task ChangePassword()
        {
            try
            {
                using (ISalesPersonBL salesPersonBL = new SalesPersonBL())
                {
                    //Read Current Password
                    Write("Current Password: ");
                    string currentPassword = ReadLine();

                    SalesPerson existingSalesPerson = await salesPersonBL.GetSalesPersonByEmailAndPasswordBL(CommonData.CurrentUser.Email, currentPassword);

                    if (existingSalesPerson != null)
                    {
                        //Read inputs
                        Write("New Password: ");
                        string newPassword = ReadLine();
                        Write("Confirm Password: ");
                        string confirmPassword = ReadLine();

                        if (newPassword.Equals(confirmPassword))
                        {
                            existingSalesPerson.Password = newPassword;

                            //Invoke UpdateSystemUserBL method to update
                            bool isUpdated = await salesPersonBL.UpdateSalesPersonPasswordBL(existingSalesPerson);
                            if (isUpdated)
                            {
                                WriteLine("Your Password Updated");
                            }
                        }
                        else
                        {
                            WriteLine($"New Password and Confirm Password doesn't match");
                        }
                    }
                    else
                    {
                        WriteLine($"Current Password doesn't match.");
                    }
                }
            }
            catch (GreatOutdoorsException ex)
            {
                ExceptionLogger.LogException(ex);
                WriteLine(ex.Message);
            }
        }
    }
}


