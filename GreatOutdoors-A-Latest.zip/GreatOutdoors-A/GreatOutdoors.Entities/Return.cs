﻿using Capgemini.GreatOutdoors.Helpers.ValidationAttributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capgemini.GreatOutdoors.Entities
{
    /// <summary>
    /// Reason of Return i.e. Wrong or Incomplete
    /// </summary>
    public enum ReasonOfReturn { Wrong, Incomplete }

    /// <summary>
    /// Interface for Return Entity
    /// </summary>
    public interface IReturn
    {
        Guid ReturnID { get; set; }
        ReasonOfReturn ReasonOfReturn { get; set; }
        Guid ProductID { get; set; }
        double ReturnAmount { get; set; }
        int ReturnQuantity { get; set; }
        double UnitPrice { get; set; }
        DateTime CreationDateTime { get; set; }
        DateTime LastModifiedDateTime { get; set; }
    }

    /// <summary>
    /// Represents Return
    /// </summary>
    public class Return : IReturn
    {
        [Required("Return ID can't be blank.")]
        public Guid ReturnID { get; set; }

        [Required("Reason of return cannot be blank")]
        public ReasonOfReturn ReasonOfReturn { get; set; }

        [Required("Product ID cannot be blank")]
        public Guid ProductID { get; set; }

        [Required("Return amount cannot be blank")]
        public double ReturnAmount { get; set; }

        [Required("Return quantity cannot be blank")]
        public int ReturnQuantity { get; set; }

        [Required("Unit Price cannot be blank")]
        public double UnitPrice { get; set; }

        public DateTime CreationDateTime { get; set; }
        public DateTime LastModifiedDateTime { get; set; }

        /*Constructor*/
        public Return()
        {
            ReturnID = default(Guid);
            ProductID = default(Guid);
            ReasonOfReturn = ReasonOfReturn.Wrong;
            ReturnAmount = default(double);
            ReturnQuantity = default(int);
            CreationDateTime = default(DateTime);
            LastModifiedDateTime = default(DateTime);
        }


    }

}


