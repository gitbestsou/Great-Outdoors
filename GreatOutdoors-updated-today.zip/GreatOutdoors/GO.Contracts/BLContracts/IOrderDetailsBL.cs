﻿using Capgemini.GreatOutdoors.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capgemini.GreatOutdoors.Contracts.BLContracts
{
    public interface IOrderDetailsBL : IDisposable
    {
        Task<bool> AddOrderDetailsBL(OrderDetails newOrderDetails);
        
        Task<List<OrderDetails>> GetOrderDetailsByOrderIDBL(Guid searchOrderID);
        Task<List<OrderDetails>> GetOrderDetailsByProductIDBL(Guid searchProductID);
        
       
        Task<bool> DeleteOrderDetailsBL(Guid deleteOrderID, Guid deleteProductID);
    }
}
