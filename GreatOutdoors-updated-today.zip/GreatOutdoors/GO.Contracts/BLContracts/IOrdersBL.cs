﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GreatOutdoors.Entities;

namespace GreatOutdoors.Contracts.BLContracts
{
    public interface IOrdersBL : IDisposable
    {
        
        Task<bool> AddOrderBL(Order newOrder);
        Task<List<Order>> GetAllOrdersBL();
        Task<Order> SearchOrderBL(int searchOrderID);
        Task<List<Order>> SearcOrderbyRetailerIDBL(int retailerID);
        Task<List<Order>> SearchOrderByCategoryIDBL(int categoryID);
        Task<List<Order>> SearchOrderBySalesmanIDBL(int salesmanID);
        Task<List<Order>> SearchOrderByOfflineBL(string channelofsale);
        Task<List<Order>> SearchOrderForOfflineBL();
        Task<List<Order>> SearchOrderByOnlineBL(string channelofsale);
        Task<List<Order>> GetOrderByStatusBL(string status);
        Task<bool> UpdateOrderBL(Order updateOrder);



    }
}
