﻿using System;
using System.Collections.Generic;
using System.IO;
using Capgemini.GreatOutdoors.Entities;
using Newtonsoft.Json;

namespace Capgemini.GreatOutdoors.Contracts.DALContracts
{
    /// <summary>
    /// This abstract class acts as a base for OrderDetailsDAL class
    /// </summary>
    public abstract class OrderDetailsDALBase
    {
        //Collection of OrderDetails
        protected static List<OrderDetails> OrderDetailsList = new List<OrderDetails>();
        private static string fileName = "OrderDetails.json";

        //Methods for CRUD operations
        public abstract bool AddOrderDetailsDAL(OrderDetails newOrderDetails);
        
        public abstract List<OrderDetails> GetOrderDetailsByOrderIDDAL(Guid searchOrderID);
        public abstract List<OrderDetails> GetOrderDetailsByProductIDDAL(Guid searchProductID);
        
        public abstract bool DeleteOrderDetailsDAL(Guid deleteOrderID, Guid deleteProductID);

        /// <summary>
        /// Writes collection to the file in JSON format.
        /// </summary>
        public static void Serialize()
        {
            string serializedJson = JsonConvert.SerializeObject(OrderDetailsList);
            using (StreamWriter streamWriter = new StreamWriter(fileName))
            {
                streamWriter.Write(serializedJson);
                streamWriter.Close();
            }
        }

        /// <summary>
        /// Reads collection from the file in JSON format.
        /// </summary>
        public static void Deserialize()
        {
            string fileContent = string.Empty;
            if (!File.Exists(fileName))
                File.Create(fileName).Close();

            using (StreamReader streamReader = new StreamReader(fileName))
            {
                fileContent = streamReader.ReadToEnd();
                streamReader.Close();
                var systemUserListFromFile = JsonConvert.DeserializeObject<List<OrderDetails>>(fileContent);
                if (systemUserListFromFile != null)
                {
                    OrderDetailsList = systemUserListFromFile;
                }
            }
        }

     
    }
}


