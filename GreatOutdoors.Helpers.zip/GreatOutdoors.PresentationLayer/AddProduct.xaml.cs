﻿using Capgemini.GreatOutdoors.BusinessLayer;
using GreatOutdoors.Entities;
using System;
using System.Threading.Tasks;
using System.Windows;

namespace GreatOutdoors.PresentationLayer
{
    /// <summary>
    /// Interaction logic for AddProduct.xaml
    /// </summary>
    public partial class AddProduct : Window
    {
        ProductBL productBL = new ProductBL();
        public AddProduct()
        {
            InitializeComponent();
        }

        private async void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            Product product = new Product();
            product.Name = txtName.Text;
            product.Category = cmbCategory.Text;
            product.Colour = txtColour.Text;
            product.Size = txtSize.Text;
            product.Stock = Convert.ToInt32(txtStock.Text);
            product.CostPrice = Convert.ToDecimal(txtCostPrice.Text);
            product.SellingPrice = Convert.ToDecimal(txtSellingPrice.Text);
            product.DiscountPercentage = Convert.ToDecimal(txtDiscountPercentage.Text);
            product.TechnicalSpecifications = txtTechSpecs.Text;
            bool isAdded = await productBL.AddProductBL(product);
            if (isAdded)
            {
                MessageBox.Show("Product added successfully!");
                Window window = new Products();
                window.Show();
                this.Close();
            }
               
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
