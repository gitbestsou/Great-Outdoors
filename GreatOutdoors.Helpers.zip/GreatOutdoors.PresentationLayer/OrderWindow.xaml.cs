﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Capgemini.GreatOutdoors.BusinessLayer;
using Capgemini.GreatOutdoors.Contracts;
using Capgemini.GreatOutdoors.Contracts.BLContracts;
using GreatOutdoors.Entities;

namespace GreatOutdoors.PresentationLayer
{
    /// <summary>
    /// Interaction logic for OrderWindow.xaml
    /// </summary>
    public partial class OrderWindow : Window
    {
        List<Product> products = new List<Product>();
        string currProdName;
        decimal currUnitPrice;
        int count;
        Guid orderID = default(Guid);
        bool orderAdded;
        OrderDetail currOrderDetail = new OrderDetail();
        decimal totalCartValue;
        int totalCartQuantity;
        List<OrderDetail> cartList = new List<OrderDetail>();
        int delRowIndex;
        Guid delOrderID;



        public OrderWindow()
        {
            InitializeComponent();
            count = 0;
            totalCartValue = 0;
            totalCartQuantity = 0;
            delRowIndex = 0;
        }



        private async void Window_Loaded(object sender, RoutedEventArgs e)
        {
            //campTab.IsSelected = true;
            string tabHeader;
            tabHeader = "Camping";
            using (IProductBL productBL = new ProductBL())
            {
                products = await productBL.GetProductByCategoryBL(tabHeader);
                campData.ItemsSource = products;
            }
            tabHeader = "Mountaineering";
            using (IProductBL productBL = new ProductBL())
            {
                products = await productBL.GetProductByCategoryBL(tabHeader);
                mountData.ItemsSource = products;
            }
            tabHeader = "Outdoor Protection";
            using (IProductBL productBL = new ProductBL())
            {
                products = await productBL.GetProductByCategoryBL(tabHeader);
                outdoorData.ItemsSource = products;
            }
            tabHeader = "Personal Accessories";
            using (IProductBL productBL = new ProductBL())
            {
                products = await productBL.GetProductByCategoryBL(tabHeader);
                personalData.ItemsSource = products;
            }
            tabHeader = "Golf";
            using (IProductBL productBL = new ProductBL())
            {
                products = await productBL.GetProductByCategoryBL(tabHeader);
                golfData.ItemsSource = products;
            }

        }



        private void TabItem_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void Grid_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void TabItem_Loaded_1(object sender, RoutedEventArgs e)
        {

        }
        //getting the selected row data
        private string getCellData(DataGrid dgv, int rowindex, int cellindex)
        {
            DataGridRow drow = dgv.ItemContainerGenerator.ContainerFromIndex(rowindex) as DataGridRow;
            var cellContent = dgv.Columns[cellindex].GetCellContent(drow) as TextBlock;
            return cellContent.Text;
        }


        //Selecting the category
        private async void TabControl_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int cartEmpty = 0;

            if (campTab.IsSelected)
            {
                cancelOrder.IsEnabled = false;
                placeOrder.IsEnabled = false; addToCart.IsEnabled = true;
                //selectedTab = "Camping";
                //using (IProductBL productBL = new ProductBL())
                //{
                //    products = await productBL.GetProductByCategoryBL(selectedTab);
                //    campData.ItemsSource = products;

                //}

            }
            if (mountTab.IsSelected)
            {
                cancelOrder.IsEnabled = false;
                placeOrder.IsEnabled = false; addToCart.IsEnabled = true;
                //selectedTab = "Mountaineering";
                //using (IProductBL productBL = new ProductBL())
                //{
                //    products = await productBL.GetProductByCategoryBL(selectedTab);
                //    mountData.ItemsSource = products;
                //}

            }
            if (outTab.IsSelected)
            {
                cancelOrder.IsEnabled = false;
                placeOrder.IsEnabled = false; addToCart.IsEnabled = true;
                //selectedTab = "Outdoor Protection";
                //using (IProductBL productBL = new ProductBL())
                //{
                //    products = await productBL.GetProductByCategoryBL(selectedTab);
                //    outdoorData.ItemsSource = products;
                //}

            }
            if (personalTab.IsSelected)
            {
                cancelOrder.IsEnabled = false;
                placeOrder.IsEnabled = false; addToCart.IsEnabled = true;
                //selectedTab = "Personal Accessories";
                //using (IProductBL productBL = new ProductBL())
                //{
                //    products = await productBL.GetProductByCategoryBL(selectedTab);
                //    personalData.ItemsSource = products;
                //}

            }
            if (golfTab.IsSelected)
            {
                cancelOrder.IsEnabled = false;
                placeOrder.IsEnabled = false;
                addToCart.IsEnabled = true;
                //selectedTab = "Golf";
                //using (IProductBL productBL = new ProductBL())
                //{
                //    products = await productBL.GetProductByCategoryBL(selectedTab);
                //    golfData.ItemsSource = products;
                //}


            }
            if (cartTab.IsSelected)
            {
                if (count == 0)
                    MessageBox.Show("Cart is Empty");
                else
                {

                    addToCart.IsEnabled = false;
                    placeOrder.IsEnabled = true;
                    cancelOrder.IsEnabled = true;
                    //using (IOrderDetailsBL orderDetails = new OrderDetailsBL())
                    //{
                    //    var cartProducts = await orderDetails.GetOrderDetailsByOrderIDBL(orderID);
                    //    cartData.ItemsSource = cartProducts;
                    //}
                }
            }

        }


        private void CrProdTxt_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private async void Button_Click(object sender, RoutedEventArgs e)
        {

            placeOrder.IsEnabled = true;

            List<Product> currentProduct = new List<Product>();
            using (IProductBL productBL = new ProductBL())
            {
                currentProduct = await productBL.GetProductByNameBL(Convert.ToString(crProdTxt.Text));
            }
            if (count == 0)
            {
                Order newOrder = new Order();
                newOrder.OrderID = default(Guid);
                newOrder.RetailerID = Guid.Parse("ABB2533A-6A44-4C06-8FF1-A17CD059B221");
                newOrder.SalespersonID = null;
                newOrder.TotalQuantity = 1;
                newOrder.TotalAmount = 1;
                newOrder.ChannelOfSale = "Online";
                using (IOrdersBL order = new OrderBL())
                {
                    (orderAdded, orderID) = await order.AddOrderBL(newOrder);
                }
                currOrderDetail.OrderID = orderID;
                currOrderDetail.ProductID = currentProduct[0].ProductID;
                currOrderDetail.Quantity = Convert.ToInt32(crQtyTxt.Text);
                totalCartQuantity = totalCartQuantity + currOrderDetail.Quantity;
                currOrderDetail.TotalPrice = Convert.ToDecimal(crTotValTxt.Text);
                totalCartValue = totalCartValue + currOrderDetail.TotalPrice;
                currOrderDetail.GiftPacking = false;
                currOrderDetail.AddressID = Guid.Parse("9AE73E73-DAB6-4BC8-831A-766B8749A064");
                currOrderDetail.CurrentStatus = "In Cart";
                currOrderDetail.DiscountedUnitPrice = Convert.ToDecimal(crPriceTxt.Text);
                using (IOrderDetailsBL orderDetail = new OrderDetailsBL())
                {
                    await orderDetail.AddOrderDetailsBL(currOrderDetail);
                }
                count = 1;
                totCartValueTxt.Text = Convert.ToString(totalCartValue);
                MessageBox.Show("Product Added To Cart");
            }
            else
            {
                currOrderDetail.OrderID = orderID;
                currOrderDetail.ProductID = currentProduct[0].ProductID;
                currOrderDetail.Quantity = Convert.ToInt32(crQtyTxt.Text);
                totalCartQuantity = totalCartQuantity + currOrderDetail.Quantity;
                currOrderDetail.TotalPrice = Convert.ToDecimal(crTotValTxt.Text);
                totalCartValue = totalCartValue + currOrderDetail.TotalPrice;
                currOrderDetail.GiftPacking = false;
                currOrderDetail.AddressID = Guid.Parse("9AE73E73-DAB6-4BC8-831A-766B8749A064");
                currOrderDetail.CurrentStatus = "In Cart";
                currOrderDetail.DiscountedUnitPrice = Convert.ToDecimal(crPriceTxt.Text);
                using (IOrderDetailsBL orderDetail = new OrderDetailsBL())
                {
                    await orderDetail.AddOrderDetailsBL(currOrderDetail);
                }
                totCartValueTxt.Text = Convert.ToString(totalCartValue);
                MessageBox.Show("Product Added To Cart");
            }
            using (IOrderDetailsBL orderDetails = new OrderDetailsBL())
            {
                var cartProducts = await orderDetails.GetOrderDetailsByOrderIDBL(orderID);
                cartData.ItemsSource = cartProducts;
            }
        }

        private void CampData_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int rowindex = campData.SelectedIndex;
            decimal price = 0;

            if (rowindex < 0)
            {
                return;
            }
            crProdTxt.Text = getCellData(campData, rowindex, 0);
            currProdName = Convert.ToString(crProdTxt.Text);
            price = (Convert.ToDecimal(getCellData(campData, rowindex, 1))) * ((100 - Convert.ToDecimal(getCellData(campData, rowindex, 5))) / 100);
            crPriceTxt.Text = Convert.ToString(price);
            crSizeTxt.Text = getCellData(campData, rowindex, 2);
            crColourTxt.Text = getCellData(campData, rowindex, 3);
            crTchTxt.Text = getCellData(campData, rowindex, 4);
            currUnitPrice = price;

        }

        private void MountData_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int rowindex = mountData.SelectedIndex;
            decimal price = 0;

            if (rowindex < 0)
            {
                return;
            }
            crProdTxt.Text = getCellData(mountData, rowindex, 0);
            currProdName = Convert.ToString(crProdTxt.Text);
            price = (Convert.ToDecimal(getCellData(mountData, rowindex, 1))) * ((100 - Convert.ToDecimal(getCellData(mountData, rowindex, 5))) / 100);
            crPriceTxt.Text = Convert.ToString(price);
            crSizeTxt.Text = getCellData(mountData, rowindex, 2);
            crColourTxt.Text = getCellData(mountData, rowindex, 3);
            crTchTxt.Text = getCellData(mountData, rowindex, 4);
            currUnitPrice = price;
        }
        private void GolfData_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int rowindex = golfData.SelectedIndex;
            decimal price = 0;

            if (rowindex < 0)
            {
                return;
            }
            crProdTxt.Text = getCellData(golfData, rowindex, 0);
            currProdName = Convert.ToString(crProdTxt.Text);
            price = (Convert.ToDecimal(getCellData(golfData, rowindex, 1))) * ((100 - Convert.ToDecimal(getCellData(golfData, rowindex, 5))) / 100);
            crPriceTxt.Text = Convert.ToString(price);
            crSizeTxt.Text = getCellData(golfData, rowindex, 2);
            crColourTxt.Text = getCellData(golfData, rowindex, 3);
            crTchTxt.Text = getCellData(golfData, rowindex, 4);
            currUnitPrice = price;
        }
        private void PersonalData_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int rowindex = personalData.SelectedIndex;
            decimal price = 0;

            if (rowindex < 0)
            {
                return;
            }
            crProdTxt.Text = getCellData(personalData, rowindex, 0);
            currProdName = Convert.ToString(crProdTxt.Text);
            price = (Convert.ToDecimal(getCellData(personalData, rowindex, 1))) * ((100 - Convert.ToDecimal(getCellData(personalData, rowindex, 5))) / 100);
            crPriceTxt.Text = Convert.ToString(price);
            crSizeTxt.Text = getCellData(personalData, rowindex, 2);
            crColourTxt.Text = getCellData(personalData, rowindex, 3);
            crTchTxt.Text = getCellData(personalData, rowindex, 4);
            currUnitPrice = price;

        }

        private void OutdoorData_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int rowindex = outdoorData.SelectedIndex;
            decimal price = 0;

            if (rowindex < 0)
            {
                return;
            }
            crProdTxt.Text = getCellData(outdoorData, rowindex, 0);
            currProdName = Convert.ToString(crProdTxt.Text);
            price = (Convert.ToDecimal(getCellData(outdoorData, rowindex, 1))) * ((100 - Convert.ToDecimal(getCellData(outdoorData, rowindex, 5))) / 100);
            crPriceTxt.Text = Convert.ToString(price);
            crSizeTxt.Text = getCellData(outdoorData, rowindex, 2);
            crColourTxt.Text = getCellData(outdoorData, rowindex, 3);
            crTchTxt.Text = getCellData(outdoorData, rowindex, 4);
            currUnitPrice = price;
        }

        private void NumericOnly(object sender, TextCompositionEventArgs e)
        {
            e.Handled = !IsValid(((TextBox)sender).Text + e.Text);
        }
        public static bool IsValid(string str)
        {
            int i;
            return (int.TryParse(str, out i) && i >= 1 && i <= 170);
        }
        public async Task<int> MaxStock(string productName)
        {
            int stock = 0;
            using (IProductBL productBL = new ProductBL())
            {
                List<Product> pr = await productBL.GetProductByNameBL(productName);
                stock = (int)pr[0].Stock;
            }
            return stock;

        }

        private async void CrQtyTxt_TextChanged(object sender, TextChangedEventArgs e)
        {

            decimal totalPrice = 0;
            int maxStock = await MaxStock(currProdName);
            if (crQtyTxt.Text == "")
            {
                crQtyTxt.Text = Convert.ToString(1);
                MessageBox.Show("Enter a valid quantity");

            }
            if (Convert.ToInt32(crQtyTxt.Text) <= maxStock)
            {
                totalPrice = currUnitPrice * Convert.ToInt32(crQtyTxt.Text);
                crTotValTxt.Text = Convert.ToString(totalPrice);
            }
            if (Convert.ToInt32(crQtyTxt.Text) > maxStock)
                MessageBox.Show("Only " + maxStock + " available.");
        }

        //private async void CartData_SelectionChanged(object sender, SelectionChangedEventArgs e)
        //{
        //    if (MessageBox.Show("Do you want to delete the product from cart?", "My Cart", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
        //    {
        //        delRowIndex = 0;

        //        delRowIndex = cartData.SelectedIndex;
        //        int i = delRowIndex;

        //        using (IOrderDetailsBL orderDetailAccess = new OrderDetailsBL())
        //        {
        //            cartList = await orderDetailAccess.GetOrderDetailsByOrderIDBL(orderID);
        //            totalCartQuantity = totalCartQuantity - cartList[delRowIndex].Quantity;
        //            totalCartValue = totalCartValue - cartList[delRowIndex].TotalPrice;
        //            totCartValueTxt.Text = Convert.ToString(totalCartValue);


        //            delOrderID = cartList[i].OrderDetailID;
        //            await orderDetailAccess.DeleteOrderDetailsBL(delOrderID);
        //        }

        //    }

        //}
        private async void PlaceOrder_Click(object sender, RoutedEventArgs e)
        {

            using (IOrdersBL accessOrder = new OrderBL())
            {
                Order updateOrder = await accessOrder.GetOrderByOrderIDBL(orderID);
                updateOrder.TotalQuantity = totalCartQuantity;
                updateOrder.TotalAmount = totalCartValue;
                await accessOrder.UpdateOrderBL(updateOrder);
                MessageBox.Show("Order Added Succesfully.");
                count = 0;
                placeOrder.IsEnabled = false;
                cartTab.IsSelected = true;
                totalCartValue = 0;
                totalCartQuantity = 0;
                totCartValueTxt.Text = Convert.ToString(totalCartValue);
                cartData.ItemsSource = null;
                crProdTxt.Text = "";
                crPriceTxt.Text = "";
                crColourTxt.Text = "";

                crSizeTxt.Text = "";
                crTchTxt.Text = "";


            }
        }


        private async void CartData_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (MessageBox.Show("Do you want to delete the product from cart?", "My Cart", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                delRowIndex = 0;

                delRowIndex = cartData.SelectedIndex;
                int i = delRowIndex;

                using (IOrderDetailsBL orderDetailAccess = new OrderDetailsBL())
                {
                    cartList = await orderDetailAccess.GetOrderDetailsByOrderIDBL(orderID);
                    totalCartQuantity = totalCartQuantity - cartList[delRowIndex].Quantity;
                    totalCartValue = totalCartValue - cartList[delRowIndex].TotalPrice;
                    totCartValueTxt.Text = Convert.ToString(totalCartValue);


                    delOrderID = cartList[i].OrderDetailID;
                    await orderDetailAccess.DeleteOrderDetailsBL(delOrderID);
                }
                using (IOrderDetailsBL orderDetails = new OrderDetailsBL())
                {
                    var cartProducts = await orderDetails.GetOrderDetailsByOrderIDBL(orderID);
                    cartData.ItemsSource = cartProducts;
                }
            }

        }

        private async void CancelOrder_Click(object sender, RoutedEventArgs e)
        {
            using (IOrderDetailsBL orderDetails = new OrderDetailsBL())
            {
                var cartProducts = await orderDetails.GetOrderDetailsByOrderIDBL(orderID);
                foreach (var item in cartProducts)
                {
                    await orderDetails.DeleteOrderDetailsBL(item.OrderDetailID);

                }
                cartData.ItemsSource = "";
                totalCartQuantity = 0;
                totalCartValue = 0;
                totCartValueTxt.Text = "0";
            }
            using (IOrdersBL orders = new OrderBL())
            {
                await orders.DeleteOrderByOrderID(orderID);
                count = 0;
            }
        }
    }
}
