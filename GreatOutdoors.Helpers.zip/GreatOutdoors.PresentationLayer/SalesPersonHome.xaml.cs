﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using GreatOutdoors.Entities;
using Capgemini.GreatOutdoors.BusinessLayer;
using GreatOutdoors.PresentationLayer;

namespace Capgemini.GreatOutdoors.PresentationLayer
{
    /// <summary>
    /// Interaction logic for SalesPersonHome.xaml
    /// </summary>
    public partial class SalesPersonHome : Window
    {
        public static SalesPerson currentSalesPerson = new SalesPerson();
        SalesPersonBL salesperonBL = new SalesPersonBL();
        public SalesPersonHome()
        {
            InitializeComponent();
        }

        private async void Window_Loaded(object sender, RoutedEventArgs e)
        {
            currentSalesPerson = await salesperonBL.GetSalesPersonByEmailAndPasswordBL(UserType.Email, UserType.Password);
            txtName.Text = currentSalesPerson.Name;
            txtBirthDate.Text = Convert.ToString(currentSalesPerson.Birthdate);
            txtMobile.Text = currentSalesPerson.Mobile;
            txtSalary.Text = Convert.ToString(currentSalesPerson.Salary);
            txtBonus.Text = Convert.ToString(currentSalesPerson.Bonus);
            txtTarget.Text = Convert.ToString(currentSalesPerson.Target);


        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            Window window = new EditSalesPerson();
            window.Show();
            this.Close();

        }

        private void BtnUpload_Click(object sender, RoutedEventArgs e)
        {

        }

        private void BtnHistory_Click(object sender, RoutedEventArgs e)
        {
            Window window = new ViewSalesHistory();
            window.Show();
            this.Close();
        }
    }
}
