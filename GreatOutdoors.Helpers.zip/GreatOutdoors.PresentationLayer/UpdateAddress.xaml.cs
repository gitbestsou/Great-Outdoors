﻿using Capgemini.GreatOutdoors.BusinessLayer;
using GreatOutdoors.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Capgemini.GreatOutdoors.PresentationLayer
{
    /// <summary>
    /// Interaction logic for UpdateAddress.xaml
    /// </summary>
    public partial class UpdateAddress : Window
    {
        Guid id;
        Address address = new Address();
        AddressBL addressBL = new AddressBL();
        public UpdateAddress(Guid id)
        {
            InitializeComponent();
            this.id = id;
            Run();
        }

        private async void Button_Click_UpdateAddress(object sender, RoutedEventArgs e)
        {
            if (address.AddressID == id)
            {
                address.Line1 = txtLine1.Text;
                address.Line2 = txtLine2.Text;
                address.Pincode = txtPincode.Text;
                address.MobileNo = txtMobileNo.Text;
                address.State = txtState.Text;
                address.City = txtCity.Text;

            }
            bool x = await addressBL.UpdateAddressBL(address);
            if(x == true)
            {
                MessageBox.Show("Address Updated Succusfully");
                AddressHome addressHome = new AddressHome();
                addressHome.Show();
            }
        }

        private async void Run()
        {
            address = await addressBL.GetAddressByAddressIDBL(id);
            txtLine1.Text = address.Line1;
            txtLine2.Text = address.Line2;
            txtCity.Text = address.City;
            txtPincode.Text = address.Pincode;
            txtState.Text = address.State;
            txtMobileNo.Text = address.MobileNo;
        }
    }
}
