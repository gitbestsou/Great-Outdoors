﻿using Capgemini.GreatOutdoors.BusinessLayer;
using Capgemini.GreatOutdoors.Contracts.BLContracts;
using GreatOutdoors.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GreatOutdoors.PresentationLayer
{
    /// <summary>
    /// Interaction logic for ViewOrderDetails.xaml
    /// </summary>
    public partial class ViewOrderDetails : Window
    {
        Guid OrderID_here;
        public ViewOrderDetails(Guid OrderID)
        {
            InitializeComponent();
            OrderID_here = OrderID;
            FillData(OrderID);
        }

        private async void FillData(Guid OrderID)
        {
            List<OrderDetail> orderDetails = new List<OrderDetail>();
            using (IOrderDetailsBL orderDetailAccess = new OrderDetailsBL())
            {
                orderDetails = await orderDetailAccess.GetOrderDetailsByOrderIDBL(OrderID);
            }

            OrderDetailHistory.ItemsSource = orderDetails;


        }
        private string getCellData(DataGrid dg, int rowindex, int cellindex)
        {
            DataGridRow drow = dg.ItemContainerGenerator.ContainerFromIndex(rowindex) as DataGridRow;
            var cellContent = dg.Columns[cellindex].GetCellContent(drow) as TextBlock;
            return cellContent.Text;

        }
        Guid ProductID;
        Guid OrderDetailID_here;
        int TotalProducts;
        decimal TotalAmount;
        string channelOfOrder;
        private async void clickOrderDetail(object sender, SelectionChangedEventArgs e)
        {
            int rowindex = OrderDetailHistory.SelectedIndex;
            if (rowindex < 0) { return; }
            OrderDetailID_here = Guid.Parse(getCellData(OrderDetailHistory, rowindex, 0));
            ProductID = Guid.Parse(getCellData(OrderDetailHistory, rowindex, 1));
            TotalProducts = Convert.ToInt32(getCellData(OrderDetailHistory, rowindex, 2));
            TotalAmount = Convert.ToDecimal(getCellData(OrderDetailHistory, rowindex, 3));
            channelOfOrder = getCellData(OrderDetailHistory, rowindex, 4);

            Product product = new Product();
            using (IProductBL productAccess = new ProductBL())
            {
                product = await productAccess.GetProductByProductIDBL(ProductID);
            }


            Window nt = new PlaceReturnCancel(OrderID_here, OrderDetailID_here, ProductID, TotalProducts, TotalAmount, channelOfOrder);
            nt.Show();
            this.Close();
        }

        private void BackToOrders(object sender, RoutedEventArgs e)
        {
            Window nt = new OrderHistory();
            nt.Show();
            this.Close();
        }
    }
}
