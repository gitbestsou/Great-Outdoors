﻿/* Javascript file to populate the data in the tables - Products, Retailers, SalesPersons
 * has Methods to get data from WebAPI - Products,Sales persons, Retailers
 Project name : Great Outdoors
Developed by: Team A
Use cases : Product, Salesperson, Retailer
Creation date : 13/11/2019
Last modified : 14/11/2019
 */


//Consuming web API in HTML using jQuery
function Products() {
    // Call Web API to get a list of Products
    $.ajax({
        url: 'api/ProductsAPI',
        type: 'GET',
        dataType: 'json',
        success: function (products) {

            ProductsTable(products);
            $('#products').DataTable();

        },
        error: function (request, message, error) {
            handleException(request, message, error);
        }
    });
}

// Handling any exception that may occur and displaying the same
function handleException(request, message,
    error) {
    var msg = "";
    msg += "Code: " + request.status + "\n";
    msg += "Text: " + request.statusText + "\n";
    if (request.responseJSON != null) {
        msg += "Message" +
            request.responseJSON.Message + "\n";
    }
    alert(msg);
}

//Using $.each for iterating over each data
function ProductsTable(products) {
    // Iterate over the collection of data
    $.each(products, function (index, product) {
        // Add a row to the Products table
        ProductAddRow(product);
    });
}

//Adding a row to the tbody of the html table
function ProductAddRow(product) {
    // Append row to <table>
    $("#products tbody").append("<tr><td>" + product.Name + "</td><td>" + product.Category + "</td><td>" + product.Stock + "</td><td>" + product.CostPrice +
            "</td><td>" + product.SellingPrice + "</td><td>" + product.DiscountPercentage + "</td></tr>");
}

// Call Product List once the page has loaded
$(document).ready(function () {

    Products();

});


//Consuming web API in HTML using jQuery
function SalesPersons() {
    // Call Web API to get a list of SalesPersons
    $.ajax({
        url: 'api/SalesPersonsAPI',
        type: 'GET',
        dataType: 'json',
        success: function (salesPersons) {

            SalesPersonsTable(salesPersons);
            $('#salesPersons').DataTable();

        },
        error: function (request, message, error) {
            handleException(request, message, error);
        }
    });
}


//Using $.each for iterating over each data
function SalesPersonsTable(salesPersons) {
    // Iterate over the collection of data
    $.each(salesPersons, function (index, salesPerson) {
        // Add a row to the SalesPersons table
        SalesPersonAddRow(salesPerson);
    });
}

//Adding a row to the tbody of the html table
function SalesPersonAddRow(salesPerson) {
    // Append row to <table>
    $("#salesPersons tbody").append("<tr><td>" + salesPerson.Name + "</td><td>" + salesPerson.JoiningDate + "</td><td>" + salesPerson.Salary +
        "</td><td>" + salesPerson.Bonus + "</td><td>" + salesPerson.Target + "</td></tr>");
}


// Call SalesPerson List once the page has loaded
$(document).ready(function () {

    SalesPersons();

});


//Consuming web API in HTML using jQuery
function Retailers() {
    // Call Web API to get a list of Retailers
    $.ajax({
        url: 'api/RetailersAPI',
        type: 'GET',
        dataType: 'json',
        success: function (retailers) {

            RetailersTable(retailers);
            $('#retailers').DataTable();

        },
        error: function (request, message, error) {
            handleException(request, message, error);
        }
    });
}


//Using $.each for iterating over each data
function RetailersTable(retailers) {
    // Iterate over the collection of data
    $.each(retailers, function (index, retailer) {
        // Add a row to the Retailers table
        RetailerAddRow(retailer);
    });
}

//Adding a row to the tbody of the html table
function RetailerAddRow(retailer) {
    // Append row to <table>
    $("#retailers tbody").append("<tr><td>" + retailer.RetailerName + "</td><td>" + retailer.Email + "</td><td>" + retailer.RetailerMobile +
        "</td></tr>");
}

// Call Retailer List once the page has loaded
$(document).ready(function () {

    Retailers();

});