﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;

namespace WpfApp2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnTest_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show(txtName.Text);

            SqlConnection sqlConn = new SqlConnection(Properties.Settings.Default.dbCon);
            
            try
            {
                sqlConn.Open();
                MessageBox.Show("Connected to database server");
            }
            catch(Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
         
            //string query;
            //query = "select * from products";

            //DataSet dtSet = new DataSet();

            //SqlDataAdapter sqlAdp = new SqlDataAdapter(query, sqlConn);
            //SqlCommandBuilder sqlbld = new SqlCommandBuilder(sqlAdp);
            //try
            //{
            //    sqlAdp.Fill(dtSet);
            //    dtSet.Tables[0].Rows[0]["ProductName"] = txtName.Text;
            //    sqlAdp.Update(dtSet);
            //    dtSet.Tables[0].AcceptChanges();
            //    MessageBox.Show("Data saved");
            //}
            //catch(Exception exp)
            //{
            //    MessageBox.Show(exp.Message);
            //}
            string query = "insert into products values(5, @name, @type, getdate(), 'Y')";
            SqlCommand sqlCmd = new SqlCommand(query);
            sqlCmd.CommandType = CommandType.Text;
            sqlCmd.Parameters.AddWithValue("@name", txtName.Text);
            sqlCmd.Parameters.AddWithValue("@type", cmbType.Text);
            sqlCmd.Connection = sqlConn;
            try
            {
                sqlCmd.ExecuteNonQuery();
                MessageBox.Show("Data saved");
            }
            catch(Exception exp)
            {
                MessageBox.Show(exp.Message);

            }
        }

        private void DgvData_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int rowindex = dgvData.SelectedIndex;
            if (rowindex < 0)
                return;
            txtID.Text = getCellData(dgvData, rowindex, 0);
            txtName.Text = getCellData(dgvData, rowindex, 1);
            cmbTypeType.Text getCellData(dgvData, rowindex, 2);
            dtEntryDate.SelectedDate = Convert.ToDateTime(getCellData(dgvData, rowindex, 3));
            chkActive.IsChecked = (getCellData(dgvData, rowindex, 4) == "Y");
        }

        private string getCellData(DataGrid dgv, int rowindex, int cellindex)
        {
            DataGridRow drow = dgv.ItemContainerGenerator.ContainerFormIndex(rowindex) as DataGridRow;
            var cellContent = dgv.Columns[cellindex].GetCellContent(drow) as TextBlock;
            return xellContent.Text;
        }
    
        {

    
            string query;
            query = "select * from products";

            DataSet dtSet = new DataSet();
            SqlConnection sqlConn = new SqlConnection(Properties.Settings.Default.dbCon);

            try
            {
                sqlConn.Open();
                MessageBox.Show("Connected to database server");
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }

            SqlDataAdapter sqlAdp = new SqlDataAdapter(query, sqlConn);
            SqlCommandBuilder sqlbld = new SqlCommandBuilder(sqlAdp);
            try
            {
                sqlAdp.Fill(dtSet);
                dtSet.Tables[0].Rows[0]["ProductName"] = txtName.Text;
                sqlAdp.Update(dtSet);
                dtSet.Tables[0].AcceptChanges();
                MessageBox.Show("Data saved");
            }
            catch(Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
        }

        private void BtnRefresh_Click(object sender, RoutedEventArgs e)
        {
            loaddata();
        }
    }
}
