import { Component, OnInit } from '@angular/core';
import { SalesPersonsService } from 'src/app/Services/salespersons.service';
import { FormGroup, FormControl, Validators, FormArray } from '@angular/forms';
import * as $ from "jquery";
import { Retailer } from 'src/app/Models/retailer';
import { RetailersService } from 'src/app/Services/retailers.service';
import { Product } from 'src/app/Models/Product';
import { Order } from 'src/app/Models/Order';
import { ProductsService } from 'src/app/Services/products.service';

/* Component of sales person home page
 *
 * Developer name: Madhuri Vemulapaty
   Use case : Sales person
   Creation date : 11/10/2019
   Last modified : 15/10/2019

*/

@Component({
  selector: 'app-uploadorder',
  templateUrl: './uploadorder.component.html',
  styleUrls: ['./uploadorder.component.scss']
})

export class UploadOrderComponent implements OnInit {
  retailers: Retailer[] = null;
  products: Product[] = [];
  order: Order;

  newOrderForm: FormGroup;
  newOrderFormErrorMessages: any;

  stepOne: boolean = true;
  stepTwo: boolean = false;
  stepThree: boolean = false;

  constructor(private retailerService: RetailersService, private salesPersonsService: SalesPersonsService,
            private productsService: ProductsService) {

    this.newOrderForm = new FormGroup({
      orderDate: new FormControl(null, [Validators.required, Validators.pattern(/^(0?[1-9]|[12][0-9]|3[01])[\/\-](0?[1-9]|1[012])[\/\-]\d{4}$/)]),
      retailerID: new FormControl(null),
     
      salesPersonID: new FormControl(this.salesPersonsService.currentSalesPerson.salesPersonID),
      totalQuantity: new FormControl(0),
      totalAmount: new FormControl(0),
      channelOfSale: new FormControl("Offline"),
      orderDetails: new FormArray([
        new FormGroup({
          orderID: new FormControl(null),
          productCode: new FormControl(null, [Validators.required]),
          productName: new FormControl(null),
          sellingPrice: new FormControl(0),
          quantity: new FormControl(1, [Validators.required, Validators.pattern(/^[0-9]*$/)]),
          totalAmount: new FormControl(null)
        })
      ])
    });

   


    //Declaring error messages for the form
    this.newOrderFormErrorMessages = {
      
      orderDate: { required: "Date can't be blank", pattern: "Enter in DD/MM/YYYY or DD-MM-YYYY" },
      quantity: { required: "Quantity cannot be blank", pattern: "Enter only positive numbers" },
      productCode: {required: "Product Code is required"}
    };
       
  }



  ngOnInit() {

    this.retailerService.GetAllRetailers().subscribe((response) => {
      this.retailers = response;
      console.log(response);
      }, (error) => {
      console.log(error);
      })
    
  }

  onNextClick() {
    $("#showRetailer").toggleClass('d-none');
    $("#showForm").toggleClass('d-none');

    this.stepOne = false;
    this.stepTwo = true;
  }



  // Checking for form control validation errors 
  getFormControlCssClass(formControl: FormControl, formGroup: FormGroup): any {
    return {
      'is-invalid': formControl.invalid && (formControl.dirty || formControl.touched || formGroup["submitted"]),
      'is-valid': formControl.valid && (formControl.dirty || formControl.touched || formGroup["submitted"])
    };
  }

  getFormControlErrorMessage(formControlName: string, validationProperty: string): string {
    return this.newOrderFormErrorMessages[formControlName][validationProperty];
  }

  getCanShowFormControlErrorMessage(formControlName: string, validationProperty: string, formGroup: FormGroup): boolean {
    return formGroup.get(formControlName).invalid && (formGroup.get(formControlName).dirty || formGroup.get(formControlName).touched || formGroup['submitted']) && formGroup.get(formControlName).errors[validationProperty];
  }





}
