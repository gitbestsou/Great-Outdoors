import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SalesPersonHomeComponent } from './salesperson-home/salesperson-home.component';
import { UploadOrderComponent } from './UploadOrder/uploadorder.component';
import { SalesHistoryComponent } from './SalesHistory/salesperson-saleshistory.component';


const routes: Routes = [
  { path: "home", component: SalesPersonHomeComponent },
  { path: "uploadorder", component: UploadOrderComponent },
  { path: "saleshistory", component: SalesHistoryComponent },
  { path: "**", redirectTo: '/home', pathMatch: 'full' },
 
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SalesPersonRoutingModule { }
