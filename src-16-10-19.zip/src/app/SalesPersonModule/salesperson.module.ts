import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { SalesPersonHomeComponent } from './salesperson-home/salesperson-home.component';
import { SalesPersonRoutingModule } from './salesperson-routing.module';
import { UploadOrderComponent } from './UploadOrder/uploadorder.component';
import { SalesHistoryComponent } from './SalesHistory/salesperson-saleshistory.component';

@NgModule({
  declarations: [
    SalesPersonHomeComponent,
    UploadOrderComponent,
    SalesHistoryComponent
   
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    SalesPersonRoutingModule
  ],
  exports: [
    SalesPersonRoutingModule,
    SalesPersonHomeComponent,
    UploadOrderComponent,
    SalesHistoryComponent
  ]
})
export class SalesPersonModule { }
