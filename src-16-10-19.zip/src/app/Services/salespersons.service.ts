import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { SalesPerson } from '../Models/SalesPerson';

@Injectable({
  providedIn: 'root'
})
 export class SalesPersonsService {

  constructor(private httpClient: HttpClient) {
  }

  currentSalesPerson: SalesPerson = null;

  AddSalesPerson(salesPerson: SalesPerson): Observable<boolean> {
    salesPerson.lastModifiedDateTime = new Date().toLocaleDateString();
    salesPerson.joiningDate = new Date().toLocaleDateString();
    salesPerson.salesPersonID = this.uuidv4();
    return this.httpClient.post<boolean>(`/api/salespersons`, salesPerson);
  }

  UpdateSalesPerson(salesPerson: SalesPerson): Observable<boolean> {
    salesPerson.lastModifiedDateTime = new Date().toLocaleDateString();
    return this.httpClient.put<boolean>(`/api/salespersons`, salesPerson);
  }

  DeleteSalesPerson(salesPersonID: string, id: number): Observable<boolean> {
    return this.httpClient.delete<boolean>(`/api/salespersons/${id}`);
  }

  GetAllSalesPersons(): Observable<SalesPerson[]> {
    return this.httpClient.get<SalesPerson[]>(`/api/salespersons`);
  }

  GetSalesPersonBySalesPersonID(SalesPersonID: number): Observable<SalesPerson> {
    return this.httpClient.get<SalesPerson>(`/api/salespersons?salesPersonID=${SalesPersonID}`);
  }

  GetSalesPersonsBySalesPersonName(SalesPersonName: string): Observable<SalesPerson[]> {
    return this.httpClient.get<SalesPerson[]>(`/api/salespersons?salesPersonName=${SalesPersonName}`);
  }

  GetSalesPersonByEmail(Email: string): Observable<SalesPerson> {
    return this.httpClient.get<SalesPerson>(`/api/salespersons?email=${Email}`);
  }

  GetSalesPersonByEmailAndPassword(Email: string, Password: string): Observable<SalesPerson> {
    return this.httpClient.get<SalesPerson>(`/api/salespersons?password=${Password}`);
  }

  uuidv4() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
      var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  }
}



