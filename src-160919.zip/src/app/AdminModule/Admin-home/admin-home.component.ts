import { Component, OnInit } from '@angular/core';
import { Admin } from '../../Models/admin';
import { AdminService } from '../../Services/admin.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import * as $ from "jquery";
import { UserAccountService } from 'src/app/Services/user-account.service';

@Component({
  selector: 'app-admin-home',
  templateUrl: './admin-home.component.html',
  styleUrls: ['./admin-home.component.scss']
})

export class AdminHomeComponent implements OnInit {
  admins: Admin[] = [];
  showAdminSpinner: boolean = false;
  viewAdminCheckBoxes: any;
  editAdminForm: FormGroup;
  editAdminDisabled: boolean = false;
  editAdminFormErrorMessages: any;

  ngOnInit() {
    this.adminService.GetAdminByAdminId(this.adminService.currentAdmin.adminID).subscribe((response) => {
      console.log(response);
      this.admins = response;

      console.log(this.adminService.currentAdmin.adminID);
    }, (error) => {
      console.log(error);
    })
  }

  constructor(private adminService: AdminService, private userAccountService: UserAccountService) {
    this.editAdminForm = new FormGroup({
      id: new FormControl(null),
      adminID: new FormControl(null),
      adminName: new FormControl(null, [Validators.required, Validators.minLength(2), Validators.maxLength(40)]),
      email: new FormControl(null, [Validators.required, Validators.email]),
      password: new FormControl(null)
    });

    this.editAdminFormErrorMessages = {
      adminName: { required: "Employee Name can't be blank", minlength: "Employee Name should contain at least 2 characters", maxlength: "Employee Name can't be longer than 40 characters" },
      email: { required: "Email can't be blank", pattern: "Email is invalid" }
    };

  }

  getFormControlCssClass(formControl: FormControl, formGroup: FormGroup): any {
    return {
      'is-invalid': formControl.invalid && (formControl.dirty || formControl.touched || formGroup["submitted"]),
      'is-valid': formControl.valid && (formControl.dirty || formControl.touched || formGroup["submitted"])
    };
  }

  getCanShowFormControlErrorMessage(formControlName: string, validationProperty: string, formGroup: FormGroup): boolean {
    return formGroup.get(formControlName).invalid && (formGroup.get(formControlName).dirty || formGroup.get(formControlName).touched || formGroup['submitted']) && formGroup.get(formControlName).errors[validationProperty];
  }

  getFormControlErrorMessage(formControlName: string, validationProperty: string): string {
    return this.editAdminFormErrorMessages[formControlName][validationProperty];
  }

  onEditAdminClick(index) {
    this.editAdminForm.reset();
    this.editAdminForm["submitted"] = false;
    this.editAdminForm.patchValue({
      id: this.admins[0].id,
      adminID: this.admins[0].adminID,
      adminName: this.admins[0].adminName,
      email: this.admins[0].email,
      password: this.admins[0].password
    });
  }

  onUpdateAdminClick() {
    this.editAdminForm["submitted"] = true;
    if (this.editAdminForm.valid) {
      this.editAdminDisabled = true;
      var admin: Admin = this.editAdminForm.value;

      this.adminService.UpdateAdmin(admin).subscribe((updateResponse) => {
        this.editAdminForm.reset();
        $("#btnUpdateEmployeeCancel").trigger("click");
        this.editAdminDisabled = false;
        this.showAdminSpinner = true;
        this.adminService.GetAdminByAdminId(this.adminService.currentAdmin.adminID).subscribe((response) => { this.admins=response });
        
      },
        (error) => {
          console.log(error);
          this.editAdminDisabled = false;
        });
    }
    
  }


}
