import { Component, OnInit } from '@angular/core';
import { Product } from '../../Models/Product';
import { ProductsService } from '../../Services/products.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import * as $ from "jquery";
import { GreatOutdoorsComponentBase } from '../../greatoutdoors-component';


/* Component of product page in Admin
 *
 * Developer name: Madhuri Vemulapaty
   Use case : Product
   Creation date : 10/10/2019
   Last modified : 13/10/2019

*/

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.scss']
})
export class ProductsComponent extends GreatOutdoorsComponentBase implements OnInit {

  // Declaring and initialising properties used
  products: Product[] = [];
  showProductsSpinner: boolean = false;
  viewProductCheckBoxes: any;

 
  newProductForm: FormGroup;
  newProductDisabled: boolean = false;
  newProductFormErrorMessages: any;

  editProductForm: FormGroup;
  editProductDisabled: boolean = false;
  editProductFormErrorMessages: any;

  deleteProductForm: FormGroup;
  deleteProductDisabled: boolean = false;

  constructor(private productsService: ProductsService) {
    super();
     // Initialising from controls in new Product form group
    this.newProductForm = new FormGroup({
      productName: new FormControl(null, [Validators.required, Validators.minLength(2), Validators.maxLength(40)]),
      productCode: new FormControl(null, [Validators.required]),
      category: new FormControl(null, [Validators.required]),
      
      stock: new FormControl(null, [Validators.pattern(/^[0-9]*$/)]),
      size: new FormControl(null),
      colour: new FormControl(null),
      techSpecs: new FormControl(null),
      costPrice: new FormControl(null, [Validators.pattern(/[+-]?([0-9]*[.])?[0-9]+/)]),
      sellingPrice: new FormControl(null, [Validators.pattern(/[+-]?([0-9]*[.])?[0-9]+/)]),
      discount: new FormControl(null, [Validators.pattern(/[+-]?([0-9]*[.])?[0-9]+/)])
    });

    //Declaring error messages for the form
    this.newProductFormErrorMessages = {
      productName: { required: "Product Name can't be blank", minlength: "Product Name should contain at least 2 characters", maxlength: "Product Name can't be longer than 40 characters" },
      productCode: { required: "Product Code can't be blank" },
      category: { required: "Category can't be blank" },
      
      stock: { pattern: "Enter only numeric values" },
      costPrice: { pattern: "Enter only numeric values" },
      sellingPrice: { pattern: "Enter only numeric values" },
      discount: { pattern: "Enter only numeric values" }
     };


    // Initialising from controls in edit Product form group
    this.editProductForm = new FormGroup({
      id: new FormControl(null),
      productName: new FormControl(null, [Validators.required, Validators.minLength(2), Validators.maxLength(40)]),
      category: new FormControl(null, [Validators.required]),
     
      stock: new FormControl(null, [Validators.pattern(/^[0-9]*$/)]),
      size: new FormControl(null),
      colour: new FormControl(null),
      techSpecs: new FormControl(null),
      costPrice: new FormControl(null, [Validators.pattern(/[+-]?([0-9]*[.])?[0-9]+/)]),
      sellingPrice: new FormControl(null, [Validators.pattern(/[+-]?([0-9]*[.])?[0-9]+/)]),
      discount: new FormControl(null, [Validators.pattern(/[+-]?([0-9]*[.])?[0-9]+/)])
    });

    //Declaring error messages for the form
    this.editProductFormErrorMessages = {
      productName: { required: "Product Name can't be blank", minlength: "Product Name should contain at least 2 characters", maxlength: "Product Name can't be longer than 40 characters" },
      productCode: { required: "Product Code can't be blank" },
      category: { required: "Category can't be blank" },
     
      stock: { pattern: "Enter only numeric values" },
      costPrice: { pattern: "Enter only numeric values" },
      sellingPrice: { pattern: "Enter only numeric values" },
      discount: { pattern: "Enter only numeric values" }
    };

    // Initialising checkboxes as checked
    this.viewProductCheckBoxes = {
      productName: true,
      category: true,
      costPrice: true,
      sellingPrice: true,
      };

    // Initialising from controls in delete Product form group
    this.deleteProductForm = new FormGroup({
      id: new FormControl(null),
      productID: new FormControl(null),
      productName: new FormControl(null)
    });
  }

  ngOnInit() {
    this.showProductsSpinner = true;
     //Displaying the existing products
    this.productsService.GetAllProducts().subscribe((response) => {
      this.products = response;
      console.log(response);
      this.showProductsSpinner = false;
    }, (error) => {
      console.log(error);
    })
  }

    // Resetting the form when Add product is clicked
  onCreateProductClick() {
    this.newProductForm.reset();
    this.newProductForm["submitted"] = false;
  }

   // Adding the product when Save is clicked
  onAddProductClick(event) {
    this.newProductForm["submitted"] = true;
    if (this.newProductForm.valid) {
      this.newProductDisabled = true;
      var product: Product = this.newProductForm.value;

      this.productsService.AddProduct(product).subscribe((addResponse) => {
        this.newProductForm.reset();
        $("#btnAddProductCancel").trigger("click");
        this.newProductDisabled = false;
        this.showProductsSpinner = true;

        // Displaying the list of products to show newly added data
        this.productsService.GetAllProducts().subscribe((getResponse) => {
          this.showProductsSpinner = false;
          this.products = getResponse;
        }, (error) => {
          console.log(error);
        });
      },
        (error) => {
          console.log(error);
          this.newProductDisabled = false;
        });
    }
    else {
      super.getFormGroupErrors(this.newProductForm);
    }
  }


    // Checking for form control validation errors

  getFormControlCssClass(formControl: FormControl, formGroup: FormGroup): any {
    return {
      'is-invalid': formControl.invalid && (formControl.dirty || formControl.touched || formGroup["submitted"]),
      'is-valid': formControl.valid && (formControl.dirty || formControl.touched || formGroup["submitted"])
    };
  }

  getFormControlErrorMessage(formControlName: string, validationProperty: string): string {
    return this.newProductFormErrorMessages[formControlName][validationProperty];
  }

  getCanShowFormControlErrorMessage(formControlName: string, validationProperty: string, formGroup: FormGroup): boolean {
    return formGroup.get(formControlName).invalid && (formGroup.get(formControlName).dirty || formGroup.get(formControlName).touched || formGroup['submitted']) && formGroup.get(formControlName).errors[validationProperty];
  }


   // Patching existing values when Edit button is clicked
  onEditProductClick(index) {
    this.editProductForm.reset();
    this.editProductForm["submitted"] = false;
    this.editProductForm.patchValue({
      id: this.products[index].id,
      productID: this.products[index].productID,
      productName: this.products[index].productName,
      category: this.products[index].category,
     
      stock: this.products[index].stock,
      size: this.products[index].size,
      colour: this.products[index].colour,
      techspecs: this.products[index].techSpecs,
      costPrice: this.products[index].costPrice,
      sellingPrice: this.products[index].sellingPrice,
      discount: this.products[index].discountPercentage
    });
  }

  // Saving the new details when Save is clicked
  onUpdateProductClick(event) {
    this.editProductForm["submitted"] = true;
    if (this.editProductForm.valid) {
      this.editProductDisabled = true;
      var product: Product = this.editProductForm.value;

      this.productsService.UpdateProduct(product).subscribe((updateResponse) => {
        this.editProductForm.reset();
        $("#btnUpdateProductCancel").trigger("click");
        this.editProductDisabled = false;
        this.showProductsSpinner = true;

        // Displaying the list of products to show newly added data
        this.productsService.GetAllProducts().subscribe((getResponse) => {
          this.showProductsSpinner = false;
          this.products = getResponse;
        }, (error) => {
          console.log(error);
        });
      },
        (error) => {
          console.log(error);
          this.editProductDisabled = false;
        });
    }
    else {
      super.getFormGroupErrors(this.editProductForm);
    }
  }


  // Displaying product details to confirm deletion when Delete is clicked
  onDeleteProductClick(index) {
    this.deleteProductForm.reset();
    this.deleteProductForm["submitted"] = false;
    this.deleteProductForm.patchValue({
      id: this.products[index].id,
      productID: this.products[index].productID,
      productName: this.products[index].productName
    });
  }

  // Removing product when Confirm is clicked
  onDeleteProductConfirmClick(event) {
    this.deleteProductForm["submitted"] = true;
    if (this.deleteProductForm.valid) {
      this.deleteProductDisabled = true;
      var product: Product = this.deleteProductForm.value;

      this.productsService.DeleteProduct(product.productID, product.id).subscribe((deleteResponse) => {
        this.deleteProductForm.reset();
        $("#btnDeleteProductCancel").trigger("click");
        this.deleteProductDisabled = false;
        this.showProductsSpinner = true;

        // Displaying the list of products to show the refreshed data
        this.productsService.GetAllProducts().subscribe((getResponse) => {
          this.showProductsSpinner = false;
          this.products = getResponse;
        }, (error) => {
          console.log(error);
        });
      },
        (error) => {
          console.log(error);
          this.deleteProductDisabled = false;
        });
    }
    else {
      super.getFormGroupErrors(this.deleteProductForm);
    }
  }


   // Displaying the product details when select all is checked
  onViewSelectAllClick() {
    for (let propertyName of Object.keys(this.viewProductCheckBoxes)) {
      this.viewProductCheckBoxes[propertyName] = true;
    }
  }

   // Hiding the product details when deselect all is checked
  onViewDeselectAllClick() {
    for (let propertyName of Object.keys(this.viewProductCheckBoxes)) {
      this.viewProductCheckBoxes[propertyName] = false;
    }
  }

 
}
