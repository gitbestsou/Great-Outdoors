import { Component, OnInit } from '@angular/core';
import { SalesPerson } from '../../Models/SalesPerson';
import { SalesPersonsService } from '../../Services/salespersons.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import * as $ from "jquery";
import { GreatOutdoorsComponentBase } from '../../greatoutdoors-component';


/* Component of sales person page in Admin
 *
 * Developer name: Madhuri Vemulapaty
   Use case : Sales person
   Creation date : 10/10/2019
   Last modified : 13/10/2019

*/

@Component({
  selector: 'app-salesPersons',
  templateUrl: './salesPersons.component.html',
  styleUrls: ['./salesPersons.component.scss']
})
export class SalesPersonsComponent extends GreatOutdoorsComponentBase implements OnInit {

  // Declaring and initialising properties used
  salesPersons: SalesPerson[] = [];
  showSalesPersonsSpinner: boolean = false;
  viewSalesPersonCheckBoxes: any;

  
  
  newSalesPersonForm: FormGroup;
  newSalesPersonDisabled: boolean = false;
  newSalesPersonFormErrorMessages: any;

  editSalesPersonForm: FormGroup;
  editSalesPersonDisabled: boolean = false;
  editSalesPersonFormErrorMessages: any;

  deleteSalesPersonForm: FormGroup;
  deleteSalesPersonDisabled: boolean = false;

  constructor(private salesPersonsService: SalesPersonsService) {
    super();

    // Initialising from controls in new Sales Person form group
    this.newSalesPersonForm = new FormGroup({
      salesPersonName: new FormControl(null, [Validators.required, Validators.minLength(2), Validators.maxLength(40)]),
      salesPersonMobile: new FormControl(null, [Validators.required, Validators.pattern(/^[6789]\d{9}$/)]),
      email: new FormControl(null, [Validators.required, Validators.email]),
      address: new FormControl(null, [Validators.required]),
      birthDate: new FormControl(null, [Validators.required, Validators.pattern(/^(0?[1-9]|[12][0-9]|3[01])[\/\-](0?[1-9]|1[012])[\/\-]\d{4}$/)]),
      salary: new FormControl(null, [Validators.required]),
      password: new FormControl(null, [Validators.required, Validators.pattern(/((?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,15})/)]),
      bonus: new FormControl(null),
      target: new FormControl(null)
    });

    //Declaring error messages for the form
    this.newSalesPersonFormErrorMessages = {
      salesPersonName: { required: "Sales Person Name can't be blank", minlength: "Sales Person Name should contain at least 2 characters", maxlength: "SalesPerson Name can't be longer than 40 characters" },
      salesPersonMobile: { required: "Mobile number can't be blank", pattern: "10 digit Mobile number is required" },
      email: { required: "Email can't be blank", pattern: "Email is invalid" },
      password: { required: "Password can't be blank", pattern: "Password should contain should be between 6 to 15 characters long, with at least one uppercase letter, one lowercase letter and one digit" },
      address: { required: "Address can't be blank" },
      salary: { required: "Salary can't be blank" },
    };


   // Initialising from controls in edit Sales Person form group
    this.editSalesPersonForm = new FormGroup({
      id: new FormControl(null),
      salesPersonID: new FormControl(null),
      salesPersonName: new FormControl(null, [Validators.required, Validators.minLength(2), Validators.maxLength(40)]), 
      salesPersonMobile: new FormControl(null, [Validators.required, Validators.pattern(/^[6789]\d{9}$/)]),
      email: new FormControl(null, [Validators.required, Validators.email]),
      password: new FormControl(null),
      address: new FormControl(null, [Validators.required]),
      salary: new FormControl(null, [Validators.required]),
      bonus: new FormControl(null),
      target: new FormControl(null)
    });

    //Declaring error messages for the form
    this.editSalesPersonFormErrorMessages = {
      salesPersonName: { required: "SalesPerson Name can't be blank", minlength: "SalesPerson Name should contain at least 2 characters", maxlength: "SalesPerson Name can't be longer than 40 characters" },
      salesPersonMobile: { required: "Mobile number can't be blank", pattern: "10 digit Mobile number is required" },
      email: { required: "Email can't be blank", pattern: "Email is invalid" },
      address: { required: "Address can't be blank" },
      salary: { required: "Salary can't be blank" }
    };

    // Initialising checkboxes as checked
    this.viewSalesPersonCheckBoxes = {
      salesPersonName: true,
      mobile: true,
      email: true,
      joiningDate: true,
      lastModifiedOn: true
    };

    // Initialising from controls in delete Sales Person form group
    this.deleteSalesPersonForm = new FormGroup({
      id: new FormControl(null),
      salesPersonID: new FormControl(null),
      salesPersonName: new FormControl(null)
    });
  }

  ngOnInit() {
    // To show loading
    this.showSalesPersonsSpinner = true;
    //Displaying the existing sales people
    this.salesPersonsService.GetAllSalesPersons().subscribe((response) => {
      this.salesPersons = response;
      console.log(response);
      this.showSalesPersonsSpinner = false;
    }, (error) => {
        console.log(error);
      })
  }


  // Resetting the form when Add Sales Person is clicked
  onCreateSalesPersonClick() {
    this.newSalesPersonForm.reset();
    this.newSalesPersonForm["submitted"] = false;
  }

  // Adding the sales person when Save is clicked
  onAddSalesPersonClick(event) {
    this.newSalesPersonForm["submitted"] = true;
    if (this.newSalesPersonForm.valid) {
      this.newSalesPersonDisabled = true;
      var salesPerson: SalesPerson = this.newSalesPersonForm.value;

      this.salesPersonsService.AddSalesPerson(salesPerson).subscribe((addResponse) => {
        this.newSalesPersonForm.reset();
        $("#btnAddSalesPersonCancel").trigger("click");
        this.newSalesPersonDisabled = false;
        this.showSalesPersonsSpinner = true;

        // Displaying the list of sales people to show newly added data
        this.salesPersonsService.GetAllSalesPersons().subscribe((getResponse) => {
          this.showSalesPersonsSpinner = false;
          this.salesPersons = getResponse;
        }, (error) => {
            console.log(error);
          });
      },
        (error) => {
          console.log(error);
          this.newSalesPersonDisabled = false;
        });
    }
    else {
      super.getFormGroupErrors(this.newSalesPersonForm);
    }
  }


  
  // Checking for form control validation errors

  getFormControlCssClass(formControl: FormControl, formGroup: FormGroup): any {
    return {
      'is-invalid': formControl.invalid && (formControl.dirty || formControl.touched || formGroup["submitted"]),
      'is-valid': formControl.valid && (formControl.dirty || formControl.touched || formGroup["submitted"])
    };
  }

  getFormControlErrorMessage(formControlName: string, validationProperty: string): string {
    return this.newSalesPersonFormErrorMessages[formControlName][validationProperty];
  }

  getCanShowFormControlErrorMessage(formControlName: string, validationProperty: string, formGroup: FormGroup): boolean {
    return formGroup.get(formControlName).invalid && (formGroup.get(formControlName).dirty || formGroup.get(formControlName).touched || formGroup['submitted']) && formGroup.get(formControlName).errors[validationProperty];
  }


  // Patching existing values when Edit button is clicked
  onEditSalesPersonClick(index) {
    this.editSalesPersonForm.reset();
    this.editSalesPersonForm["submitted"] = false;
    this.editSalesPersonForm.patchValue({
      id: this.salesPersons[index].id,
      salesPersonID: this.salesPersons[index].salesPersonID,
      salesPersonName: this.salesPersons[index].salesPersonName,
      salesPersonMobile: this.salesPersons[index].salesPersonMobile,
      email: this.salesPersons[index].email,
      password: this.salesPersons[index].password,
      salary: this.salesPersons[index].salary,
      bonus: this.salesPersons[index].bonus,
      target: this.salesPersons[index].target,

      
    });
  }

  // Saving the new details when Save is clicked
  onUpdateSalesPersonClick(event) {
    this.editSalesPersonForm["submitted"] = true;
    if (this.editSalesPersonForm.valid) {
      this.editSalesPersonDisabled = true;
      var salesPerson: SalesPerson = this.editSalesPersonForm.value;

      this.salesPersonsService.UpdateSalesPerson(salesPerson).subscribe((updateResponse) => {
        this.editSalesPersonForm.reset();
        $("#btnUpdateSalesPersonCancel").trigger("click");
        this.editSalesPersonDisabled = false;
        this.showSalesPersonsSpinner = true;

        // Displaying the list of sales people to show newly added data
        this.salesPersonsService.GetAllSalesPersons().subscribe((getResponse) => {
          this.showSalesPersonsSpinner = false;
          this.salesPersons = getResponse;
        }, (error) => {
            console.log(error);
          });
      },
        (error) => {
          console.log(error);
          this.editSalesPersonDisabled = false;
        });
    }
    else {
      super.getFormGroupErrors(this.editSalesPersonForm);
    }
  }


  // Displaying sales person details to confirm deletion when Delete is clicked
  onDeleteSalesPersonClick(index) {
    this.deleteSalesPersonForm.reset();
    this.deleteSalesPersonForm["submitted"] = false;
    this.deleteSalesPersonForm.patchValue({
      id: this.salesPersons[index].id,
      salesPersonID: this.salesPersons[index].salesPersonID,
      salesPersonName: this.salesPersons[index].salesPersonName
    });
  }

  // Removing sales person when Confirm is clicked
  onDeleteSalesPersonConfirmClick(event) {
    this.deleteSalesPersonForm["submitted"] = true;
    if (this.deleteSalesPersonForm.valid) {
      this.deleteSalesPersonDisabled = true;
      var salesPerson: SalesPerson = this.deleteSalesPersonForm.value;

      // deleting sales person
      this.salesPersonsService.DeleteSalesPerson(salesPerson.salesPersonID, salesPerson.id).subscribe((deleteResponse) => {
        this.deleteSalesPersonForm.reset();
        $("#btnDeleteSalesPersonCancel").trigger("click");
        this.deleteSalesPersonDisabled = false;
        this.showSalesPersonsSpinner = true;

        // Displaying the list of sales people to show the refreshed data
        this.salesPersonsService.GetAllSalesPersons().subscribe((getResponse) => {
          this.showSalesPersonsSpinner = false;
          this.salesPersons = getResponse;
        }, (error) => {
            console.log(error);
          });
      },
        (error) => {
          console.log(error);
          this.deleteSalesPersonDisabled = false;
        });
    }
    else {
      super.getFormGroupErrors(this.deleteSalesPersonForm);
    }
  }


  // Displaying the sales person details when select all is checked
  onViewSelectAllClick() {
    for (let propertyName of Object.keys(this.viewSalesPersonCheckBoxes)) {
      this.viewSalesPersonCheckBoxes[propertyName] = true;
    }
  }
  // Hiding the sales person details when deselect all is checked
  onViewDeselectAllClick() {
    for (let propertyName of Object.keys(this.viewSalesPersonCheckBoxes)) {
      this.viewSalesPersonCheckBoxes[propertyName] = false;
    }
  }

  
}
