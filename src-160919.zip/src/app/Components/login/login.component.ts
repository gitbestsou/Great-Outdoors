import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { UserAccountService } from '../../Services/user-account.service';
import { User } from '../../Models/user';
import { SalesPerson } from 'src/app/Models/SalesPerson';
import { SalesPersonsService } from 'src/app/Services/salespersons.service';
import { RetailersService } from 'src/app/Services/retailers.service'
import { AdminService } from 'src/app/Services/admin.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  

  constructor(private userAccountService: UserAccountService, private router: Router, private salesPersonsService: SalesPersonsService,
    private retailerService: RetailersService, private adminService: AdminService) {
    this.loginForm = new FormGroup(
      {
        email: new FormControl(null),
        password: new FormControl(null),
        userType: new FormControl("")
      });
  }

  ngOnInit() {
  }

  onLoginClick() {
    this.userAccountService.authenticate(this.loginForm.value.email, this.loginForm.value.password, this.loginForm.value.userType).subscribe((response) => {
      if (response != null && response.length > 0) {
        if (this.loginForm.value.userType == "Admin") {

          this.userAccountService.currentUser = new User(this.loginForm.value.email, this.loginForm.value.password);
          this.userAccountService.currentUserType = "Admin";
          this.userAccountService.isLoggedIn = true;
          this.adminService.currentAdmin = response[0];
          this.router.navigate(["/admin", "home"]);
        }

        else if (this.loginForm.value.userType == "SalesPerson") {

          this.userAccountService.currentUser = new User(this.loginForm.value.email, this.loginForm.value.password);
          console.log(this.userAccountService.currentUser);
          this.userAccountService.currentUserType = "SalesPerson";
          this.userAccountService.isLoggedIn = true;
          console.log(response);
          this.salesPersonsService.currentSalesPerson = response[0];
          this.router.navigate(["/salesperson", "home"]);
        }

        else if (this.loginForm.value.userType == "Retailer") {

          this.userAccountService.currentUser = new User(this.loginForm.value.email, this.loginForm.value.password);
          this.userAccountService.currentUserType = "Retailer";
          this.retailerService.currentRetailer = response[0];
          this.userAccountService.isLoggedIn = true;
          this.router.navigate(["/retailer", "home"]);
        }

      }
    }, (error) => {
      console.log(error);
    });
  }


 
}





