import { Injectable } from '@angular/core';
import { InMemoryDbService } from 'angular-in-memory-web-api';
import { SalesPerson } from '../Models/SalesPerson';
import { Admin } from '../Models/Admin';
import { Product } from '../Models/Product';
import { Retailer } from '../Models/retailer';
import { Order, OrderDetail } from '../Models/Order';
import { Address } from '../Models/Address';


@Injectable({
  providedIn: 'root'
})
export class GreatOutdoorsDataService implements InMemoryDbService {
  constructor() { }

  createDb() {
    let admins = [
      new Admin(1, '101', 'Admin', 'admin@capgemini.com', 'manager', "10/04/2019")
    ];

    let salespersons = [
      new SalesPerson(1, "401476EE-0A3B-482E-BD5B-B94A32355959", "Anoop", "9876543210", "anoop@greatoutdoors.com", "Anoop123", 20000, 5000,50000,"10/10/2013",
        "5-23-4,Sector 12,Mumbai,Maharashtra-400503", "23/06/1985", "10/04/2019"),

      new SalesPerson(2, "C628855C-FE7A-4D94-A1BB-167157D3F4EA", "John", "9988776655", "john@greatoutdoors.com", "John123",
        20000, 5000, 5000, "03/03/2015", "2-20-7,Gandhi Road, Mumbai, Maharashtra-400701", "09/06/1992", "05/07/2019"),

      new SalesPerson(3, "7A401864-684A-4691-8E9D-0D86EDEFCBBD", "Kamal", "9888776653", "kamal@greatoutdoors.com", "Kamal123",
        20000, 5000, 5000, "03/03/2015", "D.No - 4-54-6, Mumbai, Maharashtra-400701", "23/12/1982", "05/07/2019"),
    ];

    let products = [
      new Product(1, "D3C8F8E6-6545-4DC3-8524-4E5FD9027481", "BCKPCK", "Back Pack", "Camping Equipment", "assets/images/1.jpg",10, "Small", "Black", "Material - Polyester, Strap - Adjustable",
        1000, 1200, 10),
      new Product(2, "A4932913-A0C1-49E9-873F-93BF318A08FC", "GSTCK", "Golf Stick", "Golf Equipment", "assets/images/2.jpg", 20, "Small", "White", "Hand Orientation - Right",
        500, 700, 5),
      new Product(3, "3421A484-9E1C-4B40-8142-9F4D06F70660", "GBLL", "Ball", "Golf Equipment", "assets/images/3.jpg", 10, "Small", "White", "Material Type-polypropylene, Weight - 170 grams",
        200, 250, 5),
      new Product(4, "272522E4-34CE-45A0-BDC7-141767B50A3D", "MMTS", "Momentum Traction Spike", "Mountaineering Equipment", "assets/images/2.jpg", 15, "Small", "Blue", "Materials - Thermoplastic, Brand - Add Gear",
        800, 1000, 10),

    ];

    let retailers = [
      new Retailer(1, "0FC17C1D-484B-4455-98B0-C0A26B0B6917", "Scott", "9876543210", "scott@capgemini.com", "Scott123#", "10/3/2019", "10/4/2019"),
      new Retailer(2, "91C91DFE-3257-40E3-BD52-6C51E47D1364", "Smith", "9988776655", "smith@capgemini.com", "Smith123#", "9/6/2019", "5/7/2019"),
      new Retailer(3, "6D68849C-8FA8-4049-A111-B431C76C6548", "Arun", "7781994834", "arun@capgemini.com", "Arun123#", "1/5/2017", "15/11/2018"),
      new Retailer(4, "53E8748F-61D6-494B-BF72-E18B27511EFA", "Jones", "6989493491", "jones@capgemini.com", "Jones123#", "2/7/2019", "12/1/2019")
    ];

    let orders = [
      new Order(1, "9EEFF6AD-4923-4B39-A388-3ED27CA2934A", "01/01/2018", "0FC17C1D-484B-4455-98B0-C0A26B0B6917", "Scott", "401476EE-0A3B-482E-BD5B-B94A32355959",
        3, "Online", 2600, "01/01/2018", "01/01/2018"),
      new Order(2, "1011", "01/02/2018", "Scott","1020", null, 9, "Online", 900, "01/02/2018", "02/02/2018"),
      new Order(3, "1012", "01/03/2018", "Scott", "1020", null, 11, "Online", 1300, "01/03/2018", "02/03/2018"),
      new Order(4, "9EEFF6AD-4923-4B39-A388-3ED27CA2934A", "10/12/2017", "0FC17C1D-484B-4455-98B0-C0A26B0B6917", "Scott", "401476EE-0A3B-482E-BD5B-B94A32355959",
        3, "Offline", 2600, "10/12/2017", "10/12/2017"),
      new Order(5, "546B3665-22CD-4D33-AC63-05BA1568CC77", "10/11/2018", "0FC17C1D-484B-4455-98B0-C0A26B0B6917", "Scott","401476EE-0A3B-482E-BD5B-B94A32355959",
        6, "Offline", 2400, "10/12/2018", "10/12/2018"),
      new Order(6, "C628855C-FE7A-4D94-A1BB-167157D3F4EA", "15/01/2016", "6D68849C-8FA8-4049-A111-B431C76C6548", "Arun","401476EE-0A3B-482E-BD5B-B94A32355959",
        2, "Offline", 2000, "15/01/2016", "15/01/2016"),
    ];


    let addresses = [
      new Address(1, "C628855C-FE7A-4D94-A1BB-167157D3F4EA", "CKP", "Airoli", "Thane", "Mumbai", "Maharastra", "407008", "0FC17C1D-484B-4455-98B0-C0A26B0B6917", "10/3/2019", "10/4/2019"),
      new Address(2, "6D68849C-8FA8-4049-A111-B431C76C6548", "Yesomite", "Airoli", "Thane", "Mumbai", "Maharastra", "407008", "0FC17C1D-484B-4455-98B0-C0A26B0B6917", "10/3/2019", "10/4/2019"),
      new Address(3, "53E8748F-61D6-494B-BF72-E18B27511EFA", "Andheri", "Airoli", "Thane", "Mumbai", "Maharastra", "407008", "0FC17C1D-484B-4455-98B0-C0A26B0B6917", "10/3/2019", "10/4/2019"),

    ];

    let orderDetails = [
      new OrderDetail(1, "101010", "1010", "2010", "A", 5, 1200, 6000, "InCart", "10", "01/01/2018", "02/01/2018"),
      new OrderDetail(2, "101011", "1010", "2011", "A", 5, 700, 3500, "InCart", "10", "01/01/2018", "02/01/2018"),
      new OrderDetail(3, "101012", "1010", "2010", "A", 5, 1200, 6000, "InCart", "10", "01/01/2018", "02/01/2018"),
      new OrderDetail(4, "8FBD440B-BC4A-482A-A560-A8C371B60D91", "9EEFF6AD-4923-4B39-A388-3ED27CA2934A", "D3C8F8E6-6545-4DC3-8524-4E5FD9027481", "Back Pack",
        1, 1200, 1200, "Delivered", null, "10/12/2017", "10/12/2017"),
      new OrderDetail(5, "7189E110-64DC-41C1-8DE5-D15D7ACEA5D7", "9EEFF6AD-4923-4B39-A388-3ED27CA2934A", "A4932913-A0C1-49E9-873F-93BF318A08FC", "Golf Stick",
        2, 700, 1400, "Delivered", null, "10/12/2017", "10/12/2017"),
      new OrderDetail(6, "D96E18E0-A968-4E31-8549-749B0714CD05", "546B3665-22CD-4D33-AC63-05BA1568CC77", "A4932913-A0C1-49E9-873F-93BF318A08FC", "Golf Stick",
        2, 700, 1400, "Delivered", null, "10/11/2018", "10/11/2018"),
      new OrderDetail(7, "1BEE715C-7E49-4C0E-8C6A-D0E57CBCBC52", "546B3665-22CD-4D33-AC63-05BA1568CC77", "3421A484-9E1C-4B40-8142-9F4D06F70660", "Ball",
        4, 250, 1000, "Delivered", null, "10/11/2018", "10/11/2018"),

      new OrderDetail(8, "B023E693-1AA6-4F6C-94B4-DCDF3671E2B1", "C628855C-FE7A-4D94-A1BB-167157D3F4EA", "272522E4-34CE-45A0-BDC7-141767B50A3D", "Momentum Traction Spike",
        2, 1000, 2000, "Delivered", null, "15/01/2016", "15/01/2016"),



    ];
    let returns = [];
    let returndetails = [];


   
    return { admins, salespersons, products,retailers,orders,orderDetails,addresses,returns,returndetails};
  }
}


