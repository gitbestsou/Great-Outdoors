import { Component, OnInit } from '@angular/core';
import { Order, OrderDetail } from '../../Models/Order';
import { OrdersService } from '../../Services/orders.service';
import { OrderDetailsService } from '../../Services/orders.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import * as $ from "jquery";
import { GreatOutdoorsComponentBase } from '../../greatoutdoors-component';
import { ProductsService } from '../../Services/products.service';
import { Product } from '../../Models/Product';
import { Address } from '../../Models/Address';
import { AddressesService } from '../../Services/addresses.service'
import { RetailersService } from 'src/app/Services/retailers.service';

@Component({
  selector: 'app-neworder',
  templateUrl: './neworder.component.html',
  styleUrls: ['./neworder.component.scss']
})
export class NewOrdersComponent extends GreatOutdoorsComponentBase implements OnInit {

  currentRetailerId: string;
  //Using this for storing current retailer

  //view Details of Products
  viewProductForm: FormGroup;

  //if discount available
  viewDiscountedPrice: boolean = false;

  //if discount not available
  viewOriginalPrice: boolean = true;
  discountAv: number = 0;
  //using for price for patching value to product details form.
  price: number;
  currentProduct: OrderDetail;
  currentCartObject: OrderDetail;
  //Order which is being prepared
  currentOrder: Order;
  currentIndex: number;
  currentQuantity: number = 1;
  maxStock: number = 0;
  actualSellingPrice: number = 0;
  orderDetails: OrderDetail[] = [];
  products: Product[] = [];
  orderDetailsForId: OrderDetail[] = [];
  orderID: string;

  //For the current order, total value of cart.
  totalCartValue: number;

  //Always keep the track of the cart.
  cartDetails: OrderDetail[] = [];
  cartEmpty: boolean = true;
  cartNotEmpty: boolean = false;
  totalCartQuantity: number;

  //Message to be shown when order is placed succesfully.
  thankMessage: boolean = false;

  //Stores address list specific to certain retailer.
  currentRetailerAddreses: Address[] = [];

  //Used for fetching retailer selected address.
  selectedCartProduct: number;
  selectedCartProductAddress: number;
  orderDetailWithAddress: OrderDetail;



  //if Address not taken in any product
  loop: boolean;

  //Shows error message that address wasn selected.
  addressErrorMessage: string;
  showAddressErrorMessage: boolean;





  showCampingDiv: boolean = false;
  showGolfDiv: boolean = false;
  showMountaineeringDiv: boolean = false;
  showOutdoorDiv: boolean = false;
  showPersonalDiv: boolean = false;
  categorySelected: string;
  //product response

  ngOnInit() { };

  constructor(private retailerService: RetailersService, private addressesService: AddressesService, private productsService: ProductsService, private orderDetailService: OrderDetailsService, private orderService: OrdersService) {

    super();
    this.currentRetailerId = this.retailerService.currentRetailer.retailerID;

    //constructor for viewing product specific details
    this.viewProductForm = new FormGroup({
      id: new FormControl(0),
      productID: new FormControl(null),
      productName: new FormControl(null),
      image: new FormControl(null),
      size: new FormControl(null),
      colour: new FormControl(null),
      techSpecs: new FormControl(null),
      sellingPrice: new FormControl(0),
      quantity: new FormControl(0),
      discountAvailable: new FormControl(false),
      discount: new FormControl(0),
      originalPrice: new FormControl(0)
    });

    this.orderDetailWithAddress = new OrderDetail(0, null, null, null, null, 0, 0, 0, null, null, null, null);
    this.currentCartObject = new OrderDetail(0, null, null, null, null, 0, 0, 0, null, null, null, null);
    this.orderID = this.orderService.uuidv4();
    this.totalCartValue = 0;
    this.totalCartQuantity = 0;
    this.currentOrder = new Order(0, null, null, null,null, null, 0, null, 0, null, null);
    this.addressErrorMessage = null;
  }


  //Products of Camping Equipments are made visible.
  onClickCamping() {

    this.productsService.GetAllProducts().subscribe((response) => {
      this.products = response;
      console.log(this.products);
    }, (error) => {
      console.log(error);
    })

    this.showCampingDiv = true;
    this.showGolfDiv = false;
    this.showMountaineeringDiv = false;
    this.showOutdoorDiv = false;
    this.showPersonalDiv = false;
    this.categorySelected = "Camping Equipment";
    console.log(this.categorySelected);
    this.productsService.GetProductsByCategory(this.categorySelected).subscribe((response) => {
      this.products = response;
      console.log(this.products);
    }, (error) => {
      console.log(error);
    })
  }


  //Products of Golf Equipments
  onClickGolf() {
    this.showCampingDiv = false;
    this.showGolfDiv = true;
    this.showMountaineeringDiv = false;
    this.showOutdoorDiv = false;
    this.showPersonalDiv = false;
    this.categorySelected = "Golf Equipment";

    this.productsService.GetProductsByCategory(this.categorySelected).subscribe((response) => {
      this.products = response;
    }, (error) => {
      console.log(error);
    })
  }


  //Products of Mountaineering Equipments
  onClickMountaineering() {
    this.showCampingDiv = false;
    this.showGolfDiv = false;
    this.showMountaineeringDiv = true;
    this.showOutdoorDiv = false;
    this.showPersonalDiv = false;
    this.categorySelected = "Mountaineering Equipment";

    this.productsService.GetProductsByCategory(this.categorySelected).subscribe((response) => {
      this.products = response;
    }, (error) => {
      console.log(error);
    })
  }


  //Products of Outdoor Protection
  onClickOutdoor() {
    this.showCampingDiv = false;
    this.showGolfDiv = false;
    this.showMountaineeringDiv = false;
    this.showOutdoorDiv = true;
    this.showPersonalDiv = false;
    this.categorySelected = "Outdoor Protection";

    this.productsService.GetProductsByCategory(this.categorySelected).subscribe((response) => {
      this.products = response;
    }, (error) => {
      console.log(error);
    })
  }


  //Products of Personal Accessories
  onClickPersonal() {
    this.showCampingDiv = false;
    this.showGolfDiv = false;
    this.showMountaineeringDiv = false;
    this.showOutdoorDiv = false;
    this.showPersonalDiv = true;
    this.categorySelected = "Personal Accessories";

    this.productsService.GetProductsByCategory(this.categorySelected).subscribe((response) => {
      this.products = response;
    }, (error) => {
      console.log(error);
    })
  }

  //When address dropdown is Selected in Cart
  onClickSelectAddress(index) {
    this.selectedCartProduct = index;
  }


  //When address is selected from dropdown list.
  onSelectAddress(i) {
    this.selectedCartProductAddress = i;
    this.cartDetails[this.selectedCartProduct].addressID = this.currentRetailerAddreses[this.selectedCartProductAddress].addressID;
  }


  //When the cart is clicked.
  onClickCart() {
    //Load the current cart products.
    this.orderDetailService.GetOrderDetailsByOrderID(this.orderID).subscribe((getDetails) => {
      //Setting div for Thank You message to false.
      this.thankMessage = false;
      //If there are products in the cart.
      if (getDetails.length != 0) {
        this.cartEmpty = false;
        this.cartNotEmpty = true;
      }
      //No products in Cart
      else {
        this.cartEmpty = true;
        this.cartNotEmpty = false;
        this.showAddressErrorMessage = false;
      }

      this.cartDetails = getDetails;


    }, (error) => {
      console.log(error);
    });


    //Fetching the address by retailer Id to be shown in dropdown.
    this.addressesService.GetAddressByRetailerID(this.currentRetailerId).subscribe((addressResponse) => {
      this.currentRetailerAddreses = addressResponse;
    });
  }


  //Select quantity decrement button.
  onQuantityDecrementClick() {
    if (this.viewProductForm.get('quantity').value != 1) {
      this.currentQuantity = Number(this.viewProductForm.get('quantity').value) - 1;
      this.viewProductForm.patchValue({
        quantity: this.currentQuantity
      });
    }
  }


  //Select quantity increment button.
  onQuantityIncrementClick() {
    if (this.viewProductForm.get('quantity').value < this.maxStock) {
      this.currentQuantity = Number(this.viewProductForm.get('quantity').value) + 1;
      this.viewProductForm.patchValue({
        quantity: this.currentQuantity
      });
    }
  }


  //Remove from cart a certain product.
  onRemoveFromCart(index) {
    //Decrease the cart value.
    this.totalCartValue = this.totalCartValue - this.cartDetails[index].totalPrice;
    this.totalCartQuantity = this.totalCartQuantity - this.cartDetails[index].quantity;
    this.orderDetailService.DeleteOrderDetail(this.cartDetails[index].orderDetailID, this.cartDetails[index].id).subscribe((deletedResponse) => {

      this.orderDetailService.GetOrderDetailsByOrderID(this.orderID).subscribe((getDetails) => {
        if (getDetails.length == 0) {
          this.cartEmpty = true;
          this.cartNotEmpty = false;
        }
        this.cartDetails = getDetails;
        console.log(this.cartDetails);

      }, (error) => {
        console.log(error);
      });


    }, (error) => {
      console.log(error);
    });

  }



  //Views product Details in a modal.
  onClickViewDetails(index) {
    this.discountAv = this.products[index].discountPercentage;
    if (this.discountAv != 0) {
      this.viewDiscountedPrice = true;

      this.price = this.products[index].sellingPrice * (1 - this.discountAv / 100);
    }
    if (this.discountAv == 0) {
      this.viewDiscountedPrice = false;

      this.price = this.products[index].sellingPrice;

    }
    this.viewProductForm.reset();
    this.currentIndex = index;
    this.maxStock = this.products[index].stock;
    this.actualSellingPrice = this.price;

    //this.currentCartObject.productID = this.products[index].productID;
    //this.currentCartObject.productName = this.products[index].productName;



    this.viewProductForm.patchValue({
      //id: this.products[index].id,
      //productID: this.products[index].productID,
      productName: this.products[index].productName,
      size: this.products[index].size,
      colour: this.products[index].colour,
      techSpecs: this.products[index].techSpecs,
      discount: this.products[index].discountPercentage,
      sellingPrice: this.price,
      originalPrice: this.products[index].sellingPrice,
      quantity: 1
      //quantity :
    });



  }

  //on Clicking Add to Cart.
  onClickAddToCart() {

    this.orderDetailService.GetAllOrderDetails().subscribe((getResponse) => {

      this.orderDetailsForId = getResponse;

      console.log(this.orderDetailsForId);
    }, (error) => {
      console.log(error);
    });
    this.currentCartObject.id = (this.orderDetailsForId.length) + 2000;
    console.log(this.currentCartObject.id);
    this.currentCartObject.orderID = this.orderID;
    this.currentCartObject.productID = this.products[this.currentIndex].productID;
    console.log(this.currentCartObject.productID);
    this.currentCartObject.productName = this.products[this.currentIndex].productName;
    console.log(this.currentCartObject.productName);
    this.currentCartObject.quantity = this.viewProductForm.get('quantity').value;
    console.log(this.currentCartObject.quantity);
    this.currentCartObject.unitPrice = this.actualSellingPrice;
    console.log(this.currentCartObject.unitPrice);
    this.currentCartObject.totalPrice = this.currentCartObject.quantity * this.currentCartObject.unitPrice;
    console.log(this.currentCartObject.totalPrice);
    this.currentCartObject.status = "In Cart";




    this.orderDetailService.AddOrderDetail(this.currentCartObject).subscribe((addResponse) => {
      this.orderDetailService.GetAllOrderDetails().subscribe((getResponse) => {

        this.orderDetails = getResponse;
        console.log(this.orderDetails);
      }, (error) => {
        console.log(error);
      });
      $("#closeDetailModal").trigger("click");
      this.totalCartValue = this.totalCartValue + this.currentCartObject.totalPrice;
      this.totalCartQuantity = this.totalCartQuantity = this.currentCartObject.quantity;
    },
      (error) => {
        console.log(error);

      });

  }





  //When payment is confirmed.
  onClickProceedToPayment() {
    this.orderService.GetAllOrders().subscribe((response) => {
      //Generate a order ID against which all order details will be stored.
      this.currentOrder.id = 1000 + response.length;
    });
    this.loop = true;
    this.showAddressErrorMessage = false;
    this.currentOrder.orderID = this.orderID;
    this.currentOrder.totalAmount = this.totalCartValue;
    this.currentOrder.totalQuantity = this.totalCartQuantity;
    this.currentOrder.channelOfSale = "Online";
    this.currentOrder.retailerID = this.currentRetailerId;

    let x: number;
    for (x = 0; x < this.cartDetails.length; x++) {


      if (this.cartDetails[x].addressID != null) {
        this.showAddressErrorMessage = false;
        this.cartDetails[x].status = "Under Processing";
        this.orderDetailService.UpdateOrderDetail(this.cartDetails[x]).subscribe((response) => {
          this.loop = response;
          console.log(this.cartDetails[x]);
          console.log("Order Detail Added Succesfully");
          this.orderDetailService.GetAllOrderDetails().subscribe((responseAll) => {

            console.log(responseAll);
          });
        });
      }
      else {
        this.cartDetails[x].addressID = this.currentRetailerAddreses[0].addressID;
        this.orderDetailService.UpdateOrderDetail(this.cartDetails[x]).subscribe((response) => {
          this.loop = response;
          console.log(this.cartDetails[x]);
          console.log("Order Detail Added Succesfully");
          this.orderDetailService.GetAllOrderDetails().subscribe((responseAll) => {

            console.log(responseAll);
          });
        });
      }
    }




    this.orderService.AddOrder(this.currentOrder).subscribe((addResponse) => {
      console.log(this.currentOrder);
      console.log("Order Succesfully Added");
      this.orderService.GetAllOrders().subscribe((responseAll) => {

        console.log(responseAll);
      });
      this.orderID = this.orderService.uuidv4();
      this.thankMessage = true;
      this.cartNotEmpty = false;
      this.totalCartQuantity = 0;
      this.totalCartValue = 0;
    });
  }
    
  



  //On making cart empty.
  onEmptyCart() {

    let i: number;
    for (i = 0; i < this.cartDetails.length; i++) {
      console.log(this.cartDetails[i]);
      this.orderDetailService.DeleteOrderDetail(this.cartDetails[i].orderDetailID, this.cartDetails[i].id).subscribe((delResponse) => {

        this.cartEmpty = true;
        this.cartNotEmpty = false;

      });
    }
    this.totalCartValue = 0;
    this.totalCartQuantity = 0;


  }


}
