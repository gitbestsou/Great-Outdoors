import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { NewOrdersComponent } from './NewOrder/neworder.component';
import { ReturnComponent } from './Returns/returns.component';

const routes: Routes = [
  { path: "neworder", component: NewOrdersComponent },
  { path: "return", component: ReturnComponent },
  
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class OrderRoutingModule { }
