import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { NewOrdersComponent } from './NewOrder/neworder.component';
import { OrderRoutingModule } from './order-routing.module';
import { ReturnComponent } from './Returns/returns.component';


@NgModule({
  declarations: [
    NewOrdersComponent,
    ReturnComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    OrderRoutingModule
  ],
  exports: [
    OrderRoutingModule,
    NewOrdersComponent,
    ReturnComponent

  ]
})
export class OrderModule { }
