import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RetailerHomeComponent } from './retailer-home/retailer-home.component';
import { AddressComponent } from './Retailer-Address/retailer-address.component';

const routes: Routes = [
  { path: "home", component: RetailerHomeComponent },
  { path: "addresses", component: AddressComponent }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RetailerRoutingModule { }
