import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { RetailerHomeComponent } from './retailer-home/retailer-home.component';
import { RetailerRoutingModule } from './retailer-routing.module';
import { AddressComponent } from './Retailer-Address/retailer-address.component';

@NgModule({
  declarations: [
    RetailerHomeComponent,
    AddressComponent

  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RetailerRoutingModule
  ],
  exports: [
    RetailerRoutingModule,
    RetailerHomeComponent,
    AddressComponent
  ]
})
export class RetailerModule { }
