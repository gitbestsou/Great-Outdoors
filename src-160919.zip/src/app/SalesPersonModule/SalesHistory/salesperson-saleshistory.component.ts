import { Component, OnInit } from '@angular/core';
import { SalesPersonsService } from 'src/app/Services/salespersons.service';
import { Order, OrderDetail } from 'src/app/Models/Order';
import { OrdersService, OrderDetailsService } from 'src/app/Services/orders.service';
import { RetailersService } from 'src/app/Services/retailers.service';

/* Component of sales person sales history
 *
 * Developer name: Madhuri Vemulapaty
   Use case : Sales person
   Creation date : 10/10/2019
   Last modified : 13/10/2019
*/

@Component({
  selector: 'app-salesperson-saleshistory',
  templateUrl: './salesperson-saleshistory.component.html',
  styleUrls: ['./salesperson-saleshistory.component.scss']
})

export class SalesHistoryComponent implements OnInit {

  orders: Order[] = null;
  orderDetails: OrderDetail[]

 
  selectedOrderID: string;

  constructor(private ordersService: OrdersService, private salesPersonService: SalesPersonsService,
    private orderDetailsService: OrderDetailsService, private retailerService: RetailersService) {

  }



  ngOnInit() {
    this.ordersService.GetOrderBySalesPersonID(this.salesPersonService.currentSalesPerson.salesPersonID).subscribe((response) => {
      this.orders = response;
      console.log(response);

    }, (error) => {
      console.log(error);
    })

  }




  onviewOrderDetailsClick(index) {
  
    this.selectedOrderID = this.orders[index].orderID;
    this.orderDetailsService.GetOrderDetailsByOrderID(this.selectedOrderID).subscribe((response) => {
      this.orderDetails = response;
      console.log(response);

    }, (error) => {
      console.log(error);
    })

}
}
