import { Component, OnInit } from '@angular/core';
import { SalesPerson } from 'src/app/Models/SalesPerson';
import { SalesPersonsService } from 'src/app/Services/salespersons.service';
import { UserAccountService } from 'src/app/Services/user-account.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import * as $ from "jquery";


/* Component of sales person home page
 *
 * Developer name: Madhuri Vemulapaty
   Use case : Sales person
   Creation date : 10/10/2019
   Last modified : 13/10/2019
*/

@Component({
  selector: 'app-salesperson-home',
  templateUrl: './salesperson-home.component.html',
  styleUrls: ['./salesperson-home.component.scss']
})

export class SalesPersonHomeComponent implements OnInit {


  // Declaring the properties used

  salesperson: SalesPerson = null;
     
  // Declaring form group for edit password form
  editSalesPersonForm: FormGroup;
  editSalesPersonDisabled: boolean = false;
  editSalesPersonFormErrorMessages: any;
  currentSalesPerson = this.userAccountService.currentUser;

  constructor(private userAccountService: UserAccountService, private salesPersonsService: SalesPersonsService) {

    
    // Initialising form controls of edit sales person form group
    this.editSalesPersonForm = new FormGroup({
      id: new FormControl(null),
      salesPersonID: new FormControl(null),
      salesPersonName: new FormControl(null),
      salesPersonMobile: new FormControl(null, [Validators.required, Validators.pattern(/^[6789]\d{9}$/)]),
      email: new FormControl(null),
      password: new FormControl(null),
      address: new FormControl(null, [Validators.required]),
      salary: new FormControl(null),
      bonus: new FormControl(null),
      target: new FormControl(null),
      birthDate: new FormControl(null),
      joiningDate: new FormControl(null)
    });

    // Declaring error messages for edit sales person form group
    this.editSalesPersonFormErrorMessages = {
      salesPersonMobile: { required: "Mobile number can't be blank", pattern: "10 digit Mobile number is required" },
      address: { required: "Address can't be blank" },

    };
  }

  ngOnInit() {
    // Get the current sales person who logged in 
    this.salesperson = this.salesPersonsService.currentSalesPerson;
    console.log(this.salesperson);


  }

  


  

  // Patching values of sales person when edit button is clicked
  onEditSalesPersonClick(index) {
    this.editSalesPersonForm.reset();
    this.editSalesPersonForm["submitted"] = false;
    this.editSalesPersonForm.patchValue({
      id: this.salesperson.id,
      salesPersonID: this.salesperson.salesPersonID,
      salesPersonName: this.salesperson.salesPersonName,
      salesPersonMobile: this.salesperson.salesPersonMobile,
      email: this.salesperson.email,
      password: this.salesperson.password,
      salary: this.salesperson.salary,
      bonus: this.salesperson.bonus,
      target: this.salesperson.target,
      joiningDate: this.salesperson.joiningDate,
      address: this.salesperson.address,
      birthDate: this.salesperson.birthDate

    });
  }

  // Updating the details when the save button is clicked
  onUpdateSalesPersonClick(event) {
    this.editSalesPersonForm["submitted"] = true;
    if (this.editSalesPersonForm.valid) {
      this.editSalesPersonDisabled = true;
      var salesPerson: SalesPerson = this.editSalesPersonForm.value;

      this.salesPersonsService.UpdateSalesPerson(salesPerson).subscribe((updateResponse) => {
        this.editSalesPersonForm.reset();
        $("#btnUpdateSalesPersonCancel").trigger("click");
        this.editSalesPersonDisabled = false;

        console.log(this.salesperson.email, this.salesperson.password);
        this.salesPersonsService.GetSalesPersonByEmailAndPassword(salesPerson.email, salesPerson.password).subscribe((getResponse: any) => {

          if (getResponse.length > 0)
            this.salesperson = getResponse[0];


        }, (error) => {
          console.log(error);
        });
      },
        (error) => {
          console.log(error);
          this.editSalesPersonDisabled = false;
        });
    }

  }

}
