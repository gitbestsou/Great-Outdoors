import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { SalesPersonHomeComponent } from './salesperson-home/salesperson-home.component';
import { SalesPersonRoutingModule } from './salesperson-routing.module';
import { SalesHistoryComponent } from './SalesHistory/salesperson-saleshistory.component';

@NgModule({
  declarations: [
    SalesPersonHomeComponent,
    SalesHistoryComponent
   
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    SalesPersonRoutingModule
  ],
  exports: [
    SalesPersonRoutingModule,
    SalesPersonHomeComponent,
    SalesHistoryComponent
  ]
})
export class SalesPersonModule { }
