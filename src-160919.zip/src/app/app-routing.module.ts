import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './Components/login/login.component';
import { AboutComponent } from './Components/about/about.component';
import { RegisterComponent } from './Components/register/register.component';

const routes: Routes = [
  { path: "", redirectTo: "login", pathMatch: "full" },
  { path: "login", component: LoginComponent },
  { path: "register", component: RegisterComponent },
  { path: "about", component: AboutComponent },
  { path: "admin", loadChildren: () => import("./AdminModule/admin.module").then(m => m.AdminModule) },
  { path: "salesperson", loadChildren: () => import("./SalesPersonModule/salesperson.module").then(m => m.SalesPersonModule) },
  { path: "retailer", loadChildren: () => import("./RetailerModule/retailer.module").then(m => m.RetailerModule) },
  { path: "orderplace", loadChildren: () => import("./OrdersModule/order.module").then(m => m.OrderModule) },
  { path: "**", redirectTo: '/login', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
